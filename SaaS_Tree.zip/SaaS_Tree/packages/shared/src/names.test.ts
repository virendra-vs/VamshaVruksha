import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { FamilySchema, type Family } from './schemas.js';
import { applyCommand, type Command } from './commands.js';
import { validateFamilyGraph } from './graph/validate.js';
import { birthNameNote, birthSurnameOf, fullName, knownAs } from './names.js';

const seed = () => FamilySchema.parse(JSON.parse(readFileSync(new URL('../../../apps/api/test-fixtures/family.json', import.meta.url), 'utf8')));
const run = (family: Family, ...commands: Command[]) => commands.reduce((current, command) => applyCommand(current, command).family, family);
const find = (family: Family, id: string) => family.people.find((p) => p.id === id)!;

describe('names', () => {
  it('shows the full name, birth surname, pet names and Kannada name', () => {
    const family = run(seed(), { type: 'updatePerson', personId: 'P0011', patch: { surname: 'Hanumareddy', birthSurname: 'Shankaragulli', nickname: 'Shivi', aliases: ['Shivakka', 'Shivi', 'Amma'], localName: 'ಶಿವಮ್ಮ' } });
    const shivamma = find(family, 'P0011');
    expect(fullName(shivamma)).toBe('Shivamma Hanumareddy');
    expect(birthNameNote(shivamma)).toBe('née Shankaragulli');
    expect(knownAs(shivamma)).toEqual(['Shivi', 'Shivakka', 'Amma']);
    expect(shivamma.name.localScript?.kn).toBe('ಶಿವಮ್ಮ');
    expect(birthSurnameOf(shivamma)).toBe('Shankaragulli');
  });

  it('keeps her birth surname when she takes her husband\'s surname on marriage', () => {
    const family = run(seed(), { type: 'addSpouse', personId: 'P0020', anchorSurname: 'Gowda', person: { given: 'Appaji', surname: 'Gowda', gender: 'M' } });
    const padma = find(family, 'P0020');
    expect(padma.name.surname).toBe('Gowda');
    expect(padma.name.birthSurname).toBe('Shankaragulli');
    const again = run(family, { type: 'addSpouse', personId: 'P0020', anchorSurname: 'Patil', person: { given: 'Second', gender: 'M' } });
    expect(find(again, 'P0020').name.birthSurname).toBe('Shankaragulli');
  });
});

describe('gallery commands', () => {
  const withPhoto = () => {
    const family = seed();
    family.media.push({ id: 'm_0123456789abcdef', kind: 'photo', eventType: 'birthday', personIds: ['P0018'], caption: null, date: null });
    return family;
  };

  it('edits caption, event, date and people, and can set a profile photo', () => {
    const family = run(withPhoto(),
      { type: 'updateMedia', mediaId: 'm_0123456789abcdef', caption: 'First birthday', eventType: 'birthday', date: '1991-05-12', personIds: ['P0018', 'P0019'] },
      { type: 'setProfilePhoto', personId: 'P0018', mediaId: 'm_0123456789abcdef' });
    const item = family.media[0];
    expect(item.caption).toBe('First birthday');
    expect(item.date?.value).toBe('1991-05-12');
    expect(item.personIds).toEqual(['P0018', 'P0019']);
    expect(find(family, 'P0018').profile?.photoMediaId).toBe('m_0123456789abcdef');
  });

  it('removes a deleted person from photo tags, and rejects tags for unknown people', () => {
    const family = run(withPhoto(), { type: 'updateMedia', mediaId: 'm_0123456789abcdef', personIds: ['P0018', 'P0019'] }, { type: 'deletePerson', personId: 'P0019' });
    expect(family.media[0].personIds).toEqual(['P0018']);
    expect(() => applyCommand(withPhoto(), { type: 'updateMedia', mediaId: 'm_0123456789abcdef', personIds: ['nobody'] })).toThrow(/no longer exists/);
    const bad = withPhoto();
    bad.media[0].personIds = ['nobody'];
    expect(validateFamilyGraph(bad).errors.map((e) => e.code)).toContain('MISSING_PERSON');
  });

  it('deletes a photo', () => {
    expect(run(withPhoto(), { type: 'deleteMedia', mediaId: 'm_0123456789abcdef' }).media).toEqual([]);
  });
});
