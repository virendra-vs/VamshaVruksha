import type { FamilyUnion } from '../schemas.js';

type ChildLink = FamilyUnion['children'][number];

/** Children of one marriage, eldest first. `birthOrder` is the source of truth. */
export function orderedChildren(union: FamilyUnion): ChildLink[] {
  return union.children
    .map((link, index) => ({ link, index }))
    .sort((a, b) => a.link.birthOrder - b.link.birthOrder || a.index - b.index)
    .map((entry) => entry.link);
}

/** 1 -> "1st", 2 -> "2nd", 11 -> "11th", 22 -> "22nd". */
export function ordinal(n: number): string {
  const tens = n % 100;
  if (tens >= 11 && tens <= 13) return `${n}th`;
  return `${n}${({ 1: 'st', 2: 'nd', 3: 'rd' } as Record<number, string>)[n % 10] ?? 'th'}`;
}

/** Position of a child among the children of one marriage. */
export function birthRankIn(union: FamilyUnion, personId: string): { rank: number; of: number } | null {
  const list = orderedChildren(union);
  const index = list.findIndex((link) => link.personId === personId);
  return index < 0 ? null : { rank: index + 1, of: list.length };
}

/** "2nd born", or null for an only child. */
export function birthOrderLabel(rank: { rank: number; of: number } | null | undefined): string | null {
  return rank && rank.of > 1 ? `${ordinal(rank.rank)} born` : null;
}

/** Puts the given people first (in that order) and renumbers birthOrder 1..n. */
export function applyChildOrder(union: FamilyUnion, personIds: string[]): void {
  const byId = new Map(union.children.map((link) => [link.personId, link]));
  const next = personIds.flatMap((id) => (byId.has(id) ? [byId.get(id)!] : []));
  for (const link of union.children) if (!personIds.includes(link.personId)) next.push(link);
  next.forEach((link, index) => { link.birthOrder = index + 1; });
  union.children = next;
}
