import type { ChildRelation, Family, FamilyUnion, Person } from '../schemas.js';
import { orderedChildren } from './order.js';

export interface Relatives {
  parentUnion: FamilyUnion | null;
  parentRelation: ChildRelation | null;
  parents: Person[];
  spouses: { person: Person | null; union: FamilyUnion }[];
  children: { person: Person; relation: ChildRelation; union: FamilyUnion }[];
  siblings: Person[];
}

export function birthYear(person: Person | undefined): number | null {
  const value = person?.vitals?.birth?.date?.value;
  const match = value ? /^\d{4}/.exec(value) : null;
  return match ? Number(match[0]) : null;
}

export function deathYear(person: Person | undefined): number | null {
  const value = person?.vitals?.death?.date?.value;
  const match = value ? /^\d{4}/.exec(value) : null;
  return match ? Number(match[0]) : null;
}

export function findParentUnion(family: Family, personId: string): { union: FamilyUnion; relation: ChildRelation } | null {
  let fallback: { union: FamilyUnion; relation: ChildRelation } | null = null;
  for (const union of family.unions) {
    const link = union.children.find((child) => child.personId === personId);
    if (!link) continue;
    if (link.relation === 'biological') return { union, relation: link.relation };
    fallback ??= { union, relation: link.relation };
  }
  return fallback;
}

export function getRelatives(family: Family, personId: string): Relatives {
  const byId = new Map(family.people.map((person) => [person.id, person]));
  const parent = findParentUnion(family, personId);
  const parents = parent ? parent.union.partners.flatMap((id) => (id && byId.get(id) ? [byId.get(id)!] : [])) : [];
  const spouses: Relatives['spouses'] = [];
  const children: Relatives['children'] = [];
  for (const union of family.unions) {
    if (!union.partners.includes(personId)) continue;
    const otherId = union.partners.find((id) => id !== personId) ?? null;
    spouses.push({ person: otherId ? byId.get(otherId) ?? null : null, union });
    for (const link of orderedChildren(union)) {
      const child = byId.get(link.personId);
      if (child) children.push({ person: child, relation: link.relation, union });
    }
  }
  spouses.sort((a, b) => (a.union.order?.[personId] ?? 1) - (b.union.order?.[personId] ?? 1));
  const siblings = parent
    ? orderedChildren(parent.union).flatMap((link) => (link.personId !== personId && byId.get(link.personId) ? [byId.get(link.personId)!] : []))
    : [];
  return { parentUnion: parent?.union ?? null, parentRelation: parent?.relation ?? null, parents, spouses, children, siblings };
}

export function displayName(person: Person): string {
  return person.name.nickname ? `${person.name.given} (${person.name.nickname})` : person.name.given;
}

/** Everyone above this person, through any parent link. */
export function ancestorIds(family: Family, personId: string): Set<string> {
  const seen = new Set<string>();
  const queue = [personId];
  while (queue.length) {
    const id = queue.pop()!;
    for (const union of family.unions) {
      if (!union.children.some((child) => child.personId === id)) continue;
      for (const partner of union.partners) {
        if (partner && partner !== personId && !seen.has(partner)) { seen.add(partner); queue.push(partner); }
      }
    }
  }
  return seen;
}

/** Everyone below this person, through any child link. */
export function descendantIds(family: Family, personId: string): Set<string> {
  const seen = new Set<string>();
  const queue = [personId];
  while (queue.length) {
    const id = queue.pop()!;
    for (const union of family.unions) {
      if (!union.partners.includes(id)) continue;
      for (const child of union.children) {
        if (child.personId !== personId && !seen.has(child.personId)) { seen.add(child.personId); queue.push(child.personId); }
      }
    }
  }
  return seen;
}
