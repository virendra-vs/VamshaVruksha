import type { Family, ValidationIssue } from '../schemas.js';

export function validateFamilyGraph(family: Family): { errors: ValidationIssue[]; warnings: ValidationIssue[] } {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];
  const people = new Set(family.people.map((person) => person.id));
  const seenPeople = new Set<string>();
  const seenUnions = new Set<string>();
  const biologicalParent = new Map<string, string>();
  const parentOf = new Map<string, string[]>();

  for (const person of family.people) {
    if (seenPeople.has(person.id)) errors.push({ code: 'DUPLICATE_PERSON_ID', message: `Person ID ${person.id} is duplicated.`, entityType: 'person', entityId: person.id, path: '/people' });
    seenPeople.add(person.id);
  }

  for (const union of family.unions) {
    if (seenUnions.has(union.id)) errors.push({ code: 'DUPLICATE_UNION_ID', message: `Union ID ${union.id} is duplicated.`, entityType: 'union', entityId: union.id, path: '/unions' });
    seenUnions.add(union.id);
    const [first, second] = union.partners;
    if (first && second && first === second) errors.push({ code: 'SELF_UNION', message: 'A person cannot be partnered with themself.', entityType: 'union', entityId: union.id, path: '/partners' });
    for (const partnerId of union.partners) {
      if (partnerId && !people.has(partnerId)) errors.push({ code: 'MISSING_PERSON', message: `Partner ${partnerId} does not exist.`, entityType: 'union', entityId: union.id, path: '/partners' });
    }
    const partnerIds = new Set(union.partners.filter((id): id is string => id !== null));
    for (const child of union.children) {
      if (!people.has(child.personId)) errors.push({ code: 'MISSING_PERSON', message: `Child ${child.personId} does not exist.`, entityType: 'union', entityId: union.id, path: '/children' });
      if (partnerIds.has(child.personId)) errors.push({ code: 'CHILD_IS_PARTNER', message: 'A union partner cannot also be its child.', entityType: 'union', entityId: union.id, path: '/children' });
      if (child.relation === 'biological') {
        if (biologicalParent.has(child.personId)) errors.push({ code: 'MULTIPLE_BIOLOGICAL_UNIONS', message: `Person ${child.personId} is a biological child in more than one union.`, entityType: 'person', entityId: child.personId, path: '/unions' });
        biologicalParent.set(child.personId, union.id);
        parentOf.set(child.personId, [...(parentOf.get(child.personId) ?? []), ...union.partners.filter((id): id is string => id !== null)]);
      }
    }
    if (union.status === 'active' && first && second) {
      const duplicate = family.unions.find((other) => other.id !== union.id && other.status === 'active' && other.partners.includes(first) && other.partners.includes(second));
      if (duplicate) errors.push({ code: 'DUPLICATE_ACTIVE_UNION', message: `The same partners already have active union ${duplicate.id}.`, entityType: 'union', entityId: union.id, path: '/partners' });
    }
  }

  for (const item of family.media ?? []) {
    for (const personId of item.personIds) {
      if (!people.has(personId)) errors.push({ code: 'MISSING_PERSON', message: `Photo ${item.id} is tagged with a person who does not exist.`, entityType: 'media', entityId: item.id, path: '/media' });
    }
  }

  const active = new Set<string>();
  const complete = new Set<string>();
  const visit = (personId: string): boolean => {
    if (active.has(personId)) return false;
    if (complete.has(personId)) return true;
    active.add(personId);
    for (const parentId of parentOf.get(personId) ?? []) if (!visit(parentId)) return false;
    active.delete(personId);
    complete.add(personId);
    return true;
  };
  for (const person of family.people) {
    if (!visit(person.id)) {
      errors.push({ code: 'ANCESTRY_CYCLE', message: 'This relationship would make a person their own ancestor.', entityType: 'person', entityId: person.id, path: '/unions' });
      break;
    }
  }

  for (const person of family.people) {
    if (person.id !== family.meta.rootPersonId && !family.unions.some((union) => union.partners.includes(person.id) || union.children.some((child) => child.personId === person.id))) {
      warnings.push({ code: 'ORPHAN_PERSON', message: `${person.name.given} is not connected to a union.`, entityType: 'person', entityId: person.id, path: '/people' });
    }
  }
  return { errors, warnings };
}