import { describe, expect, it } from 'vitest';
import { FamilySchema } from '../schemas.js';
import { validateFamilyGraph } from './validate.js';

const family = (people: unknown[], unions: unknown[]) => FamilySchema.parse({
  schemaVersion: '1.0.0',
  meta: { id: 'fam-test', tenantId: 't-test', name: 'Test', surname: 'Test', rootPersonId: 'p1', dataVersion: 1, updatedAt: new Date().toISOString() },
  people, unions,
});

const person = (id: string) => ({ id, name: { given: id }, gender: 'U', isLiving: false });
const union = (id: string, partners: [string | null, string | null], children: { personId: string; relation: 'biological' | 'adopted' | 'step' | 'foster' | 'guardian'; birthOrder: number }[]) => ({ id, type: 'marriage', status: 'active', partners, children });

describe('validateFamilyGraph', () => {
  it('accepts a valid parent-child graph', () => {
    const result = validateFamilyGraph(family([person('p1'), person('p2'), person('p3')], [union('u1', ['p1', 'p2'], [{ personId: 'p3', relation: 'biological', birthOrder: 1 }])]));
    expect(result.errors).toEqual([]);
  });

  it('rejects missing people, self-unions and children who are partners', () => {
    const result = validateFamilyGraph(family([person('p1')], [union('u1', ['p1', 'p1'], [{ personId: 'p1', relation: 'biological', birthOrder: 1 }, { personId: 'missing', relation: 'adopted', birthOrder: 2 }])]));
    expect(result.errors.map((issue) => issue.code)).toEqual(expect.arrayContaining(['SELF_UNION', 'CHILD_IS_PARTNER', 'MISSING_PERSON']));
  });

  it('rejects multiple biological unions and ancestry cycles', () => {
    const result = validateFamilyGraph(family([person('p1'), person('p2'), person('p3')], [
      union('u1', ['p1', null], [{ personId: 'p2', relation: 'biological', birthOrder: 1 }]),
      union('u2', ['p2', null], [{ personId: 'p1', relation: 'biological', birthOrder: 1 }]),
      union('u3', ['p3', null], [{ personId: 'p2', relation: 'biological', birthOrder: 1 }]),
    ]));
    expect(result.errors.map((issue) => issue.code)).toEqual(expect.arrayContaining(['MULTIPLE_BIOLOGICAL_UNIONS', 'ANCESTRY_CYCLE']));
  });
});