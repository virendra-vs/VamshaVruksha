import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { FamilySchema, type Family } from '../schemas.js';
import { applyCommand, type Command } from '../commands.js';
import { birthRankIn, orderedChildren, ordinal } from './order.js';
import { getRelatives } from './relatives.js';
import { validateFamilyGraph } from './validate.js';
import { layoutFamily } from '../layout/layout.js';

const seed = () => FamilySchema.parse(JSON.parse(readFileSync(new URL('../../../../apps/api/test-fixtures/family.json', import.meta.url), 'utf8')));
const run = (family: Family, ...commands: Command[]) => commands.reduce((current, command) => applyCommand(current, command).family, family);
const added = (family: Family, command: Command) => { const r = applyCommand(family, command); return { family: r.family, id: r.focusId! }; };
const order = (family: Family, unionId: string) => orderedChildren(family.unions.find((u) => u.id === unionId)!).map((c) => c.personId);
const byX = (family: Family, ids: string[]) => { const l = layoutFamily(family); return [...ids].sort((a, b) => l.nodes.find((n) => n.id === a)!.x - l.nodes.find((n) => n.id === b)!.x); };

describe('ordinals', () => {
  it('writes 1st, 2nd, 3rd, 4th and the teens correctly', () => {
    expect([1, 2, 3, 4, 11, 12, 13, 21, 22, 23, 101, 112].map(ordinal)).toEqual(['1st', '2nd', '3rd', '4th', '11th', '12th', '13th', '21st', '22nd', '23rd', '101st', '112th']);
  });
});

describe('birth order of children', () => {
  it('reports each child\'s rank among their brothers and sisters', () => {
    const family = seed();
    const union = family.unions.find((u) => u.id === 'U0007')!;
    expect(birthRankIn(union, 'P0005')).toEqual({ rank: 1, of: 5 });
    expect(birthRankIn(union, 'P0026')).toEqual({ rank: 5, of: 5 });
    expect(getRelatives(family, 'P0016').siblings.map((p) => p.id)).toEqual(['P0005', 'P0011', 'P0021', 'P0026']);
  });

  it('draws the children in birth order even when a later child has an earlier birth year', () => {
    const family = run(seed(), { type: 'updatePerson', personId: 'P0026', patch: { birthDate: '1950' } });
    expect(byX(family, ['P0005', 'P0011', 'P0016', 'P0021', 'P0026'])).toEqual(order(family, 'U0007'));
  });

  it('adds a child at the chosen position and renumbers the others', () => {
    const eldest = added(seed(), { type: 'addChild', parentId: 'P0016', person: { given: 'Eldest', gender: 'M' }, position: 1 });
    expect(order(eldest.family, 'U0004')).toEqual([eldest.id, 'P0018', 'P0019', 'P0020']);
    const middle = added(seed(), { type: 'addChild', parentId: 'P0016', person: { given: 'Middle', gender: 'F' }, position: 3 });
    expect(order(middle.family, 'U0004')).toEqual(['P0018', 'P0019', middle.id, 'P0020']);
    expect(middle.family.unions.find((u) => u.id === 'U0004')!.children.map((c) => c.birthOrder).sort()).toEqual([1, 2, 3, 4]);
    const youngest = added(seed(), { type: 'addChild', parentId: 'P0016', person: { given: 'Last', gender: 'F' } });
    expect(order(youngest.family, 'U0004').at(-1)).toBe(youngest.id);
  });

  it('places a new child by birth year when siblings have birth years', () => {
    const dated = run(seed(),
      { type: 'updatePerson', personId: 'P0018', patch: { birthDate: '1990' } },
      { type: 'updatePerson', personId: 'P0019', patch: { birthDate: '1993' } },
      { type: 'updatePerson', personId: 'P0020', patch: { birthDate: '1997' } });
    const between = added(dated, { type: 'addChild', parentId: 'P0016', person: { given: 'Between', gender: 'M', birthYear: '1995' } });
    expect(order(between.family, 'U0004')).toEqual(['P0018', 'P0019', between.id, 'P0020']);
    const first = added(dated, { type: 'addChild', parentId: 'P0016', person: { given: 'Firstborn', gender: 'F', birthYear: '1988' } });
    expect(order(first.family, 'U0004')[0]).toBe(first.id);
    const noDate = added(dated, { type: 'addChild', parentId: 'P0016', person: { given: 'Undated', gender: 'F' } });
    expect(order(noDate.family, 'U0004').at(-1)).toBe(noDate.id);
  });

  it('moves a child when their birth year is entered later', () => {
    const family = run(seed(),
      { type: 'updatePerson', personId: 'P0018', patch: { birthDate: '1990' } },
      { type: 'updatePerson', personId: 'P0020', patch: { birthDate: '1985' } });
    expect(order(family, 'U0004')).toEqual(['P0020', 'P0018', 'P0019']);
  });

  it('reorders children explicitly and rejects incomplete lists', () => {
    const family = run(seed(), { type: 'reorderChildren', unionId: 'U0004', personIds: ['P0020', 'P0018', 'P0019'] });
    expect(order(family, 'U0004')).toEqual(['P0020', 'P0018', 'P0019']);
    expect(birthRankIn(family.unions.find((u) => u.id === 'U0004')!, 'P0020')).toEqual({ rank: 1, of: 3 });
    expect(() => applyCommand(seed(), { type: 'reorderChildren', unionId: 'U0004', personIds: ['P0018'] })).toThrow(/exactly the children/);
    expect(validateFamilyGraph(family).errors).toEqual([]);
  });

  it('carries the rank onto the tree cards', () => {
    const layout = layoutFamily(seed());
    const node = (id: string) => layout.nodes.find((n) => n.id === id)!;
    expect(node('P0011')).toMatchObject({ birthRank: 2, siblingCount: 5 });
    expect(node('P0003').birthRank).toBe(1);
    expect(node('P0003').siblingCount).toBe(1);
  });

  it('links an existing child at a chosen position', () => {
    const lone = added(seed(), { type: 'addChild', parentId: 'P0016', person: { given: 'Stray', gender: 'M' } });
    const family = run(lone.family, { type: 'detachChild', unionId: 'U0004', personId: lone.id }, { type: 'linkChild', parentId: 'P0016', childId: lone.id, unionId: 'U0004', position: 2 });
    expect(order(family, 'U0004')).toEqual(['P0018', lone.id, 'P0019', 'P0020']);
  });
});
