import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { FamilySchema } from './schemas.js';
import { applyCommand } from './commands.js';
import { ageSummary, formatPartialDate, isValidPartialDate, redactForViewer } from './dates.js';

const seed = () => FamilySchema.parse(JSON.parse(readFileSync(new URL('../../../apps/api/test-fixtures/family.json', import.meta.url), 'utf8')));

describe('partial dates', () => {
  it('validates and formats year, month and full dates', () => {
    expect(isValidPartialDate('1950')).toBe(true);
    expect(isValidPartialDate('1950-02-30')).toBe(false);
    expect(isValidPartialDate('1950-13')).toBe(false);
    expect(formatPartialDate('1950-05-12')).toBe('12 May 1950');
    expect(formatPartialDate('1950-05')).toBe('May 1950');
    expect(formatPartialDate('1950')).toBe('1950');
  });

  it('describes age for living and late people', () => {
    const family = applyCommand(seed(), { type: 'updatePerson', personId: 'P0003', patch: { birthDate: '1928-03-01', deathDate: '2004-02-01' } }).family;
    expect(ageSummary(family.people.find((p) => p.id === 'P0003')!)).toBe('Lived 75 years');
  });
});

describe('rich profile', () => {
  it('stores the extra details and hides contacts from viewers', () => {
    const result = applyCommand(seed(), {
      type: 'updatePerson', personId: 'P0018',
      patch: { birthDate: '1990-05-12', birthPlace: 'Bengaluru', education: 'B.E.', gotra: 'Kashyapa', village: 'Shankaragulli', bloodGroup: 'O+', phone: '+91 90000 00000', bio: 'Loves stories.' },
    }).family;
    const person = result.people.find((p) => p.id === 'P0018')!;
    expect(person.vitals?.birth?.date).toEqual({ value: '1990-05-12', precision: 'exact' });
    expect(person.custom?.gotra).toBe('Kashyapa');
    expect(person.profile?.contacts?.phone).toBe('+91 90000 00000');
    const viewer = redactForViewer(result).people.find((p) => p.id === 'P0018')!;
    expect(viewer.profile?.contacts).toBeUndefined();
    expect(viewer.profile?.education).toBe('B.E.');
  });

  it('records marriage date and place', () => {
    const result = applyCommand(seed(), { type: 'updateUnion', unionId: 'U0004', startDate: '2015-11', place: 'Hubballi' }).family;
    const union = result.unions.find((u) => u.id === 'U0004')!;
    expect(union.startDate?.value).toBe('2015-11');
    expect(union.place?.text).toBe('Hubballi');
  });
});
