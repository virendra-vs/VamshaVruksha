import { z } from 'zod';
import { createId } from './ids.js';
import { isValidPartialDate } from './dates.js';
import { ancestorIds, descendantIds, findParentUnion } from './graph/relatives.js';
import { applyChildOrder, orderedChildren } from './graph/order.js';
import type { ChildRelation, Family, FamilyUnion, Person } from './schemas.js';
import { MEDIA_EVENT_TYPES } from './schemas.js';

export class CommandError extends Error {
  constructor(public readonly code: string, message: string) { super(message); }
}

const year = z.string().regex(/^\d{4}$/, 'Use a four digit year').nullish();
const text = (max: number) => z.string().trim().max(max).nullish();
const partialDate = z.string().refine(isValidPartialDate, 'Use a valid date such as 1950, 1950-05 or 1950-05-12').nullish();

export const NewPersonSchema = z.object({
  given: z.string().trim().min(1, 'Name is required').max(80),
  surname: text(80),
  birthSurname: text(80),
  gender: z.enum(['M', 'F', 'O', 'U']),
  isLiving: z.boolean().default(true),
  birthYear: year,
  deathYear: year,
});

export const PersonPatchSchema = NewPersonSchema.omit({ birthYear: true, deathYear: true }).partial().extend({
  birthDate: partialDate, deathDate: partialDate,
  nickname: text(80), occupation: text(120), education: text(200), bio: text(4000),
  aliases: z.array(z.string().trim().min(1).max(60)).max(12).optional(), localName: text(80),
  birthPlace: text(120), deathPlace: text(120), currentPlace: text(120),
  gotra: text(80), village: text(120), bloodGroup: text(8),
  phone: text(40), email: text(120), address: text(300),
});

const status = z.enum(['active', 'divorced', 'separated', 'widowed', 'annulled']);
const relation = z.enum(['biological', 'adopted', 'step', 'foster', 'guardian']);

const position = z.number().int().min(1).max(60).optional();

export const CommandSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('addPerson'), person: NewPersonSchema }),
  z.object({ type: z.literal('addSpouse'), personId: z.string(), person: NewPersonSchema, previousStatus: status.optional(), anchorSurname: text(80), unionId: z.string().optional() }),
  z.object({ type: z.literal('addChild'), parentId: z.string(), unionId: z.string().optional(), person: NewPersonSchema, relation: relation.optional(), position }),
  z.object({ type: z.literal('addParent'), childId: z.string(), person: NewPersonSchema }),
  z.object({ type: z.literal('addSibling'), personId: z.string(), person: NewPersonSchema, position }),
  z.object({ type: z.literal('updatePerson'), personId: z.string(), patch: PersonPatchSchema }),
  z.object({ type: z.literal('updateUnion'), unionId: z.string(), status: status.optional(), startDate: partialDate, place: text(120) }),
  z.object({ type: z.literal('setChildRelation'), unionId: z.string(), personId: z.string(), relation }),
  z.object({ type: z.literal('linkSpouse'), personId: z.string(), spouseId: z.string(), previousStatus: status.optional(), anchorSurname: text(80), unionId: z.string().optional() }),
  z.object({ type: z.literal('fillPartner'), unionId: z.string(), personId: z.string().optional(), person: NewPersonSchema.optional(), anchorSurname: text(80) }),
  z.object({ type: z.literal('mergePeople'), keepId: z.string(), removeId: z.string() }),
  z.object({ type: z.literal('linkChild'), parentId: z.string(), childId: z.string(), unionId: z.string().optional(), relation: relation.optional(), position }),
  z.object({ type: z.literal('linkParent'), childId: z.string(), parentId: z.string() }),
  z.object({ type: z.literal('linkSibling'), personId: z.string(), siblingId: z.string(), position }),
  z.object({ type: z.literal('reorderChildren'), unionId: z.string(), personIds: z.array(z.string()).min(1).max(60) }),
  z.object({ type: z.literal('removeUnion'), unionId: z.string() }),
  z.object({ type: z.literal('detachChild'), unionId: z.string(), personId: z.string() }),
  z.object({ type: z.literal('deletePerson'), personId: z.string() }),
  z.object({ type: z.literal('updateMedia'), mediaId: z.string(), caption: text(300), eventType: z.enum(MEDIA_EVENT_TYPES).optional(), date: partialDate, personIds: z.array(z.string()).min(1).max(60).optional() }),
  z.object({ type: z.literal('deleteMedia'), mediaId: z.string() }),
  z.object({ type: z.literal('setProfilePhoto'), personId: z.string(), mediaId: z.string() }),
]);

export type Command = z.input<typeof CommandSchema>;
export type NewPerson = z.input<typeof NewPersonSchema>;
export type PersonPatch = z.input<typeof PersonPatchSchema>;
export interface CommandResult { family: Family; focusId?: string }

const now = () => new Date().toISOString();
const precisionOf = (value: string) => (value.length === 4 ? 'year' : value.length === 7 ? 'month' : 'exact');

function setVital(person: Person, key: 'birth' | 'death', patch: { date?: string | null; place?: string | null }) {
  person.vitals ??= {};
  const current = person.vitals[key] ?? null;
  let date = current?.date ?? null;
  let place = current?.place ?? null;
  if (patch.date !== undefined) date = patch.date ? { value: patch.date, precision: precisionOf(patch.date) } : null;
  if (patch.place !== undefined) place = patch.place ? { text: patch.place } : null;
  person.vitals[key] = date || place ? { date, place } : null;
}

function makePerson(input: z.output<typeof NewPersonSchema>): Person {
  return {
    id: createId('p'),
    name: { given: input.given, middle: null, surname: input.surname || null, nickname: null, birthSurname: input.birthSurname || null, aliases: [] },
    gender: input.gender,
    isLiving: input.isLiving,
    status: 'confirmed',
    vitals: {
      birth: input.birthYear ? { date: { value: input.birthYear, precision: 'year' }, place: null } : null,
      death: !input.isLiving && input.deathYear ? { date: { value: input.deathYear, precision: 'year' }, place: null } : null,
    },
    profile: { occupation: null, bio: null },
    tags: [],
    privacy: 'family',
    audit: { createdAt: now(), version: 1 },
  } as Person;
}

const nextOrder = (union: FamilyUnion) => Math.max(0, ...union.children.map((child) => child.birthOrder)) + 1;
const fail = (code: string, message: string): never => { throw new CommandError(code, message); };

const isBlank = (value: unknown) => value === null || value === undefined || value === '' || (Array.isArray(value) && value.length === 0);

const birthKey = (family: Family, id: string): string | null => family.people.find((entry) => entry.id === id)?.vitals?.birth?.date?.value ?? null;

/**
 * Slots a child among their brothers and sisters by birth date. Children without a date keep their place,
 * and nothing moves when no sibling has a date to compare with.
 */
function placeByBirthDate(family: Family, personId: string, only?: FamilyUnion) {
  const mine = birthKey(family, personId);
  if (!mine) return;
  for (const union of only ? [only] : family.unions) {
    if (!union.children.some((link) => link.personId === personId)) continue;
    const others = orderedChildren(union).map((link) => link.personId).filter((id) => id !== personId);
    let index = others.findIndex((id) => { const date = birthKey(family, id); return date !== null && date > mine; });
    if (index < 0) {
      let lastDated = -1;
      others.forEach((id, i) => { if (birthKey(family, id) !== null) lastDated = i; });
      if (lastDated < 0) continue;
      index = lastDated + 1;
    }
    others.splice(index, 0, personId);
    applyChildOrder(union, others);
  }
}

/** When the same two people end up in two marriage records, keep one and move everything into it. */
function absorbDuplicateCouples(family: Family, keeper: FamilyUnion) {
  const [a, b] = keeper.partners;
  if (!a || !b) return;
  for (const other of [...family.unions]) {
    if (other.id === keeper.id || !other.partners.includes(a) || !other.partners.includes(b)) continue;
    if (other.children.length > 0 && other.status !== keeper.status) continue;
    for (const child of other.children) {
      if (!keeper.children.some((entry) => entry.personId === child.personId)) keeper.children.push({ ...child, birthOrder: nextOrder(keeper) });
    }
    if (!keeper.startDate?.value && other.startDate) keeper.startDate = other.startDate;
    if (!keeper.place?.text && other.place) keeper.place = other.place;
    family.unions = family.unions.filter((union) => union.id !== other.id);
  }
}

/** Copies details the kept person is missing from the duplicate. */
function fillBlanks(keep: Person, drop: Person) {
  for (const key of ['surname', 'birthSurname', 'nickname'] as const) {
    if (isBlank(keep.name[key]) && !isBlank(drop.name[key])) keep.name[key] = drop.name[key];
  }
  keep.name.aliases = [...new Set([...(keep.name.aliases ?? []), ...(drop.name.aliases ?? [])])];
  keep.name.localScript = { ...(drop.name.localScript ?? {}), ...(keep.name.localScript ?? {}) };
  if (keep.gender === 'U' && drop.gender !== 'U') keep.gender = drop.gender;
  keep.vitals ??= {};
  for (const key of ['birth', 'death'] as const) if (isBlank(keep.vitals[key]) && !isBlank(drop.vitals?.[key])) keep.vitals[key] = drop.vitals![key];
  const profile = (keep.profile ??= {}) as Record<string, unknown>;
  for (const [key, value] of Object.entries(drop.profile ?? {})) if (isBlank(profile[key]) && !isBlank(value)) profile[key] = value;
  keep.custom = { ...(drop.custom ?? {}), ...Object.fromEntries(Object.entries(keep.custom ?? {}).filter(([, value]) => !isBlank(value))) };
}

export function applyCommand(source: Family, raw: Command): CommandResult {
  const command = CommandSchema.parse(raw);
  const family: Family = structuredClone(source);
  const person = (id: string) => family.people.find((entry) => entry.id === id) ?? fail('NOT_FOUND', 'That person no longer exists.');
  const addChildTo = (union: FamilyUnion, childId: string, kind: ChildRelation) => {
    union.children.push({ personId: childId, relation: kind, birthOrder: nextOrder(union) });
  };
  const hasBiologicalParents = (id: string) => family.unions.some((u) => u.children.some((c) => c.personId === id && c.relation === 'biological'));
  const notSelf = (a: Person, b: Person) => { if (a.id === b.id) fail('SELF', 'A person cannot be linked to themselves.'); };

  /** Gives a woman her husband's surname while remembering the one she was born with. */
  const takeSurname = (target: Person, surname?: string | null) => {
    const next = surname?.trim();
    if (!next || next === target.name.surname?.trim()) return;
    if (!target.name.birthSurname && target.name.surname) target.name.birthSurname = target.name.surname;
    target.name.surname = next;
  };

  /** Joins two existing people as a couple, reusing an "unknown spouse" slot when the anchor has one. */
  const coupleUp = (anchor: Person, otherId: string, previousStatus?: FamilyUnion['status'], anchorSurname?: string | null, unionId?: string) => {
    takeSurname(anchor, anchorSurname);
    if (previousStatus && previousStatus !== 'active') {
      for (const union of family.unions) {
        if (union.partners.includes(anchor.id) && union.partners.every(Boolean) && union.status === 'active') union.status = previousStatus;
      }
    }
    const otherCount = family.unions.filter((union) => union.partners.includes(otherId)).length;
    let open: FamilyUnion | undefined;
    if (unionId && unionId !== 'new') {
      open = family.unions.find((union) => union.id === unionId && union.partners.includes(anchor.id) && union.partners.includes(null))
        ?? fail('NOT_FOUND', 'That marriage no longer has an unknown partner to fill.');
    } else if (!unionId) {
      open = family.unions.find((union) => union.status === 'active' && union.partners.includes(anchor.id) && union.partners.includes(null));
    }
    if (open) {
      open.partners = open.partners[0] === anchor.id ? [anchor.id, otherId] : [otherId, anchor.id];
      open.order = { ...(open.order ?? {}), [otherId]: otherCount + 1 };
      absorbDuplicateCouples(family, open);
    } else {
      const count = family.unions.filter((union) => union.partners.includes(anchor.id)).length;
      family.unions.push({
        id: createId('u'), type: 'marriage', status: 'active', partners: [anchor.id, otherId],
        order: { [anchor.id]: count + 1, [otherId]: otherCount + 1 }, children: [],
      });
    }
  };

  const attachChild = (parent: Person, childId: string, unionId: string | undefined, kind: ChildRelation) => {
    const mine = family.unions.filter((union) => union.partners.includes(parent.id));
    let union = unionId ? mine.find((entry) => entry.id === unionId) : mine.length === 1 ? mine[0] : undefined;
    if (!union && unionId) fail('NOT_FOUND', 'That marriage no longer exists.');
    if (!union && mine.length > 1) fail('CHOOSE_UNION', 'Choose which marriage this child belongs to.');
    if (!union) {
      union = { id: createId('u'), type: 'marriage', status: 'active', partners: [parent.id, null], order: { [parent.id]: 1 }, children: [] };
      family.unions.push(union);
    }
    addChildTo(union, childId, kind);
    return union;
  };

  /** Explicit position wins; otherwise a known birth date decides; otherwise the child is the youngest. */
  const arrangeChild = (union: FamilyUnion, childId: string, at?: number) => {
    if (at) {
      const ids = orderedChildren(union).map((link) => link.personId).filter((id) => id !== childId);
      ids.splice(Math.min(at, ids.length + 1) - 1, 0, childId);
      applyChildOrder(union, ids);
    } else placeByBirthDate(family, childId, union);
  };

  const attachParent = (child: Person, parent: Person) => {
    const existing = findParentUnion(family, child.id);
    const union = existing ? family.unions.find((entry) => entry.id === existing.union.id)! : undefined;
    if (union) {
      if (union.partners.includes(parent.id)) fail('ALREADY_LINKED', `${parent.name.given} is already a parent of ${child.name.given}.`);
      const slot = union.partners.indexOf(null);
      if (slot < 0) fail('PARENTS_FULL', `${child.name.given} already has two parents. Detach one first.`);
      union.partners[slot] = parent.id;
      union.order = { ...(union.order ?? {}), [parent.id]: family.unions.filter((u) => u.partners.includes(parent.id)).length + 1 };
    } else {
      family.unions.push({
        id: createId('u'), type: 'marriage', status: 'active',
        partners: parent.gender === 'F' ? [null, parent.id] : [parent.id, null],
        order: { [parent.id]: family.unions.filter((u) => u.partners.includes(parent.id)).length + 1 },
        children: [{ personId: child.id, relation: 'biological', birthOrder: 1 }],
      });
    }
  };

  const attachSibling = (anchor: Person, siblingId: string) => {
    const existing = findParentUnion(family, anchor.id) ?? fail('NO_PARENTS', 'Add or link a parent first, then add siblings.');
    const union = family.unions.find((entry) => entry.id === existing.union.id)!;
    addChildTo(union, siblingId, 'biological');
    return union;
  };

  switch (command.type) {
    case 'addPerson': {
      const created = makePerson(command.person);
      family.people.push(created);
      return { family, focusId: created.id };
    }
    case 'addSpouse': {
      const anchor = person(command.personId);
      const created = makePerson(command.person);
      family.people.push(created);
      coupleUp(anchor, created.id, command.previousStatus, command.anchorSurname, command.unionId);
      return { family, focusId: created.id };
    }
    case 'addChild': {
      const parent = person(command.parentId);
      const created = makePerson(command.person);
      family.people.push(created);
      arrangeChild(attachChild(parent, created.id, command.unionId, command.relation ?? 'biological'), created.id, command.position);
      return { family, focusId: created.id };
    }
    case 'addParent': {
      const child = person(command.childId);
      const created = makePerson(command.person);
      family.people.push(created);
      attachParent(child, created);
      return { family, focusId: created.id };
    }
    case 'addSibling': {
      const anchor = person(command.personId);
      const created = makePerson(command.person);
      family.people.push(created);
      arrangeChild(attachSibling(anchor, created.id), created.id, command.position);
      return { family, focusId: created.id };
    }
    case 'linkSpouse': {
      const anchor = person(command.personId);
      const other = person(command.spouseId);
      notSelf(anchor, other);
      if (family.unions.some((u) => u.status === 'active' && u.partners.includes(anchor.id) && u.partners.includes(other.id))) {
        fail('ALREADY_LINKED', `${anchor.name.given} and ${other.name.given} are already linked as a couple.`);
      }
      coupleUp(anchor, other.id, command.previousStatus, command.anchorSurname, command.unionId);
      return { family, focusId: anchor.id };
    }
    case 'fillPartner': {
      const union = family.unions.find((entry) => entry.id === command.unionId) ?? fail('NOT_FOUND', 'That marriage no longer exists.');
      const slot = union.partners.indexOf(null);
      if (slot < 0) fail('NO_UNKNOWN', 'This marriage already has both partners.');
      if (!command.personId && !command.person) fail('INVALID', 'Choose someone or enter a new person.');
      const known = union.partners[slot === 0 ? 1 : 0];
      let target: Person;
      if (command.personId) target = person(command.personId);
      else { target = makePerson(command.person!); family.people.push(target); }
      if (target.id === known) fail('SELF', 'A person cannot be married to themselves.');
      if (union.children.some((child) => child.personId === target.id)) fail('CHILD_IS_PARTNER', `${target.name.given} is a child in this marriage, so cannot also be a partner.`);
      if (known) takeSurname(person(known), command.anchorSurname);
      union.partners[slot] = target.id;
      union.order = { ...(union.order ?? {}), [target.id]: family.unions.filter((entry) => entry.id !== union.id && entry.partners.includes(target.id)).length + 1 };
      absorbDuplicateCouples(family, union);
      return { family, focusId: target.id };
    }
    case 'mergePeople': {
      const keep = person(command.keepId);
      const drop = person(command.removeId);
      notSelf(keep, drop);
      if (family.unions.some((u) => u.partners.includes(keep.id) && u.partners.includes(drop.id))) fail('MERGE_PARTNERS', 'They are married to each other, so they cannot be the same person.');
      if (ancestorIds(family, keep.id).has(drop.id) || descendantIds(family, keep.id).has(drop.id)) fail('MERGE_RELATED', 'One is an ancestor of the other, so they cannot be the same person.');
      if (hasBiologicalParents(keep.id) && hasBiologicalParents(drop.id)) fail('MERGE_PARENTS', 'Both have biological parents recorded. Detach one set of parents first, then merge.');
      for (const union of family.unions) {
        union.partners = union.partners.map((id) => (id === drop.id ? keep.id : id)) as FamilyUnion['partners'];
        for (const child of union.children) if (child.personId === drop.id) child.personId = keep.id;
        const seen = new Set<string>();
        union.children = union.children.filter((child) => !seen.has(child.personId) && !!seen.add(child.personId));
        if (union.order && drop.id in union.order) {
          union.order[keep.id] ??= union.order[drop.id];
          delete union.order[drop.id];
        }
      }
      for (const union of [...family.unions]) if (family.unions.includes(union)) absorbDuplicateCouples(family, union);
      for (const item of family.media) item.personIds = [...new Set(item.personIds.map((id) => (id === drop.id ? keep.id : id)))];
      fillBlanks(keep, drop);
      family.people = family.people.filter((entry) => entry.id !== drop.id);
      if (family.meta.rootPersonId === drop.id) family.meta.rootPersonId = keep.id;
      return { family, focusId: keep.id };
    }
    case 'linkChild': {
      const parent = person(command.parentId);
      const child = person(command.childId);
      notSelf(parent, child);
      if (ancestorIds(family, parent.id).has(child.id)) fail('CYCLE', `${child.name.given} is an ancestor of ${parent.name.given}, so cannot also be their child.`);
      const kind = command.relation ?? 'biological';
      if (family.unions.some((u) => u.partners.includes(parent.id) && u.children.some((c) => c.personId === child.id))) fail('ALREADY_LINKED', `${child.name.given} is already a child of ${parent.name.given}.`);
      if (family.unions.some((u) => u.partners.includes(parent.id) && u.partners.includes(child.id))) fail('CHILD_IS_PARTNER', `${child.name.given} is married to ${parent.name.given}, so cannot be their child.`);
      if (kind === 'biological' && hasBiologicalParents(child.id)) fail('HAS_PARENTS', `${child.name.given} already has biological parents. Detach them first, or link as an adopted, step or foster child.`);
      arrangeChild(attachChild(parent, child.id, command.unionId, kind), child.id, command.position);
      return { family, focusId: parent.id };
    }
    case 'linkParent': {
      const child = person(command.childId);
      const parent = person(command.parentId);
      notSelf(child, parent);
      if (descendantIds(family, child.id).has(parent.id)) fail('CYCLE', `${parent.name.given} is a descendant of ${child.name.given}, so cannot also be their parent.`);
      if (family.unions.some((u) => u.partners.includes(parent.id) && u.partners.includes(child.id))) fail('CHILD_IS_PARTNER', `${child.name.given} is married to ${parent.name.given}.`);
      attachParent(child, parent);
      return { family, focusId: child.id };
    }
    case 'linkSibling': {
      const anchor = person(command.personId);
      const sibling = person(command.siblingId);
      notSelf(anchor, sibling);
      if (ancestorIds(family, anchor.id).has(sibling.id) || descendantIds(family, anchor.id).has(sibling.id)) fail('CYCLE', `${sibling.name.given} is an ancestor or descendant of ${anchor.name.given}, so cannot be a sibling.`);
      const existing = findParentUnion(family, anchor.id);
      if (existing?.union.children.some((c) => c.personId === sibling.id)) fail('ALREADY_LINKED', `${sibling.name.given} is already a sibling of ${anchor.name.given}.`);
      if (hasBiologicalParents(sibling.id)) fail('HAS_PARENTS', `${sibling.name.given} already has parents. Link them as a child of the same parents instead, or detach them first.`);
      arrangeChild(attachSibling(anchor, sibling.id), sibling.id, command.position);
      return { family, focusId: anchor.id };
    }
    case 'reorderChildren': {
      const union = family.unions.find((entry) => entry.id === command.unionId) ?? fail('NOT_FOUND', 'That marriage no longer exists.');
      const current = new Set(union.children.map((link) => link.personId));
      if (command.personIds.length !== current.size || !command.personIds.every((id) => current.has(id))) fail('INVALID', 'The list must contain exactly the children of this marriage.');
      applyChildOrder(union, command.personIds);
      return { family };
    }
    case 'removeUnion': {
      if (!family.unions.some((u) => u.id === command.unionId)) fail('NOT_FOUND', 'That marriage no longer exists.');
      family.unions = family.unions.filter((u) => u.id !== command.unionId);
      return { family };
    }
    case 'detachChild': {
      const union = family.unions.find((u) => u.id === command.unionId) ?? fail('NOT_FOUND', 'That family link no longer exists.');
      if (!union.children.some((c) => c.personId === command.personId)) fail('NOT_FOUND', 'That child link no longer exists.');
      union.children = union.children.filter((c) => c.personId !== command.personId);
      if (union.children.length === 0 && union.partners.filter(Boolean).length < 2) family.unions = family.unions.filter((u) => u.id !== union.id);
      return { family };
    }
    case 'updatePerson': {
      const target = person(command.personId);
      const { patch } = command;
      if (patch.given !== undefined) target.name.given = patch.given;
      if (patch.surname !== undefined) target.name.surname = patch.surname || null;
      if (patch.nickname !== undefined) target.name.nickname = patch.nickname || null;
      if (patch.birthSurname !== undefined) target.name.birthSurname = patch.birthSurname || null;
      if (patch.aliases !== undefined) target.name.aliases = [...new Set(patch.aliases)];
      if (patch.localName !== undefined) {
        const script = { ...(target.name.localScript ?? {}) };
        if (patch.localName) script.kn = patch.localName; else delete script.kn;
        target.name.localScript = script;
      }
      if (patch.gender !== undefined) target.gender = patch.gender;
      if (patch.isLiving !== undefined) target.isLiving = patch.isLiving;
      target.status = target.status === 'placeholder' ? 'confirmed' : target.status;
      setVital(target, 'birth', { date: patch.birthDate, place: patch.birthPlace });
      if (patch.birthDate) placeByBirthDate(family, target.id);
      setVital(target, 'death', { date: patch.deathDate, place: patch.deathPlace });
      if (target.isLiving) target.vitals!.death = null;
      target.profile ??= {};
      const profile = target.profile;
      if (patch.occupation !== undefined) profile.occupation = patch.occupation || null;
      if (patch.education !== undefined) profile.education = patch.education || null;
      if (patch.bio !== undefined) profile.bio = patch.bio || null;
      if (patch.currentPlace !== undefined) profile.currentPlace = patch.currentPlace || null;
      if (patch.phone !== undefined || patch.email !== undefined || patch.address !== undefined) {
        const contacts = { phone: null, email: null, address: null, ...(profile.contacts ?? {}) };
        if (patch.phone !== undefined) contacts.phone = patch.phone || null;
        if (patch.email !== undefined) contacts.email = patch.email || null;
        if (patch.address !== undefined) contacts.address = patch.address || null;
        profile.contacts = contacts;
      }
      target.custom ??= {};
      if (patch.gotra !== undefined) target.custom.gotra = patch.gotra || null;
      if (patch.village !== undefined) target.custom.village = patch.village || null;
      if (patch.bloodGroup !== undefined) target.custom.bloodGroup = patch.bloodGroup || null;
      return { family, focusId: target.id };
    }
    case 'updateUnion': {
      const union = family.unions.find((entry) => entry.id === command.unionId) ?? fail('NOT_FOUND', 'That marriage no longer exists.');
      if (command.status) union.status = command.status;
      if (command.startDate !== undefined) union.startDate = command.startDate ? { value: command.startDate, precision: precisionOf(command.startDate) } : null;
      if (command.place !== undefined) union.place = command.place ? { text: command.place } : null;
      return { family };
    }
    case 'setChildRelation': {
      const union = family.unions.find((entry) => entry.id === command.unionId) ?? fail('NOT_FOUND', 'That family link no longer exists.');
      const link = union.children.find((entry) => entry.personId === command.personId) ?? fail('NOT_FOUND', 'That child link no longer exists.');
      link.relation = command.relation;
      return { family };
    }
    case 'updateMedia': {
      const item = family.media.find((entry) => entry.id === command.mediaId) ?? fail('NOT_FOUND', 'That photo no longer exists.');
      if (command.caption !== undefined) item.caption = command.caption || null;
      if (command.eventType) item.eventType = command.eventType;
      if (command.date !== undefined) item.date = command.date ? { value: command.date, precision: precisionOf(command.date) } : null;
      if (command.personIds) {
        for (const id of command.personIds) person(id);
        item.personIds = [...new Set(command.personIds)];
      }
      return { family };
    }
    case 'deleteMedia': {
      if (!family.media.some((entry) => entry.id === command.mediaId)) fail('NOT_FOUND', 'That photo no longer exists.');
      family.media = family.media.filter((entry) => entry.id !== command.mediaId);
      return { family };
    }
    case 'setProfilePhoto': {
      const target = person(command.personId);
      if (!family.media.some((entry) => entry.id === command.mediaId)) fail('NOT_FOUND', 'That photo no longer exists.');
      target.profile = { ...(target.profile ?? {}), photoMediaId: command.mediaId };
      return { family, focusId: target.id };
    }
    case 'deletePerson': {
      if (command.personId === family.meta.rootPersonId) fail('ROOT_PROTECTED', 'The family root person cannot be removed.');
      person(command.personId);
      for (const item of family.media) item.personIds = item.personIds.filter((id) => id !== command.personId);
      family.people = family.people.filter((entry) => entry.id !== command.personId);
      family.unions = family.unions.flatMap((union) => {
        union.children = union.children.filter((child) => child.personId !== command.personId);
        union.partners = union.partners.map((id) => (id === command.personId ? null : id)) as FamilyUnion['partners'];
        const known = union.partners.filter(Boolean).length;
        if (known === 0) return [];
        if (known === 1 && union.children.length === 0) return [];
        return [union];
      });
      return { family };
    }
  }
}
