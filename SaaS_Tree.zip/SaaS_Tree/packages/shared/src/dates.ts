import type { Family, Person } from './schemas.js';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export const PARTIAL_DATE = /^\d{4}(-\d{2}(-\d{2})?)?$/;

export function isValidPartialDate(value: string): boolean {
  if (!PARTIAL_DATE.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  if (month !== undefined && (month < 1 || month > 12)) return false;
  if (day !== undefined && month !== undefined) {
    const last = new Date(Date.UTC(year, month, 0)).getUTCDate();
    if (day < 1 || day > last) return false;
  }
  return true;
}

/** "1990", "May 1990" or "12 May 1990". */
export function formatPartialDate(value?: string | null): string {
  if (!value || !isValidPartialDate(value)) return '';
  const [year, month, day] = value.split('-');
  if (!month) return year;
  const name = MONTHS[Number(month) - 1];
  return day ? `${Number(day)} ${name} ${year}` : `${name} ${year}`;
}

function parts(value?: string | null) {
  if (!value || !isValidPartialDate(value)) return null;
  const [year, month, day] = value.split('-').map(Number);
  return { year, month, day };
}

/** "Age 34" for living people, "Lived 72 years" when both dates are known. */
export function ageSummary(person: Person, today = new Date()): string | null {
  const born = parts(person.vitals?.birth?.date?.value);
  if (!born) return null;
  const end = person.isLiving
    ? { year: today.getFullYear(), month: today.getMonth() + 1, day: today.getDate() }
    : parts(person.vitals?.death?.date?.value);
  if (!end) return null;
  let years = end.year - born.year;
  if (born.month && end.month && (end.month < born.month || (end.month === born.month && born.day && end.day && end.day < born.day))) years -= 1;
  if (years < 0) return null;
  return person.isLiving ? `Age ${years}` : `Lived ${years} years`;
}

/** Contact details are only for admins; everything else is safe to browse. */
export function redactForViewer(family: Family): Family {
  return {
    ...family,
    people: family.people.map((person) => {
      if (!person.profile?.contacts) return person;
      const { contacts: _removed, ...profile } = person.profile;
      return { ...person, profile };
    }),
  };
}
