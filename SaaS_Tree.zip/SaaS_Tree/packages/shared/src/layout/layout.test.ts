import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { FamilySchema } from '../schemas.js';
import { defaultLayoutOptions, layoutFamily } from './layout.js';
import { applyCommand } from '../commands.js';
import { validateFamilyGraph } from '../graph/validate.js';

const seed = () => FamilySchema.parse(JSON.parse(readFileSync(new URL('../../../../apps/api/test-fixtures/family.json', import.meta.url), 'utf8')));
const overlap = (a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) =>
  a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;

describe('layoutFamily', () => {
  it('places every person once without overlapping cards', () => {
    const family = seed();
    const layout = layoutFamily(family);
    const cards = layout.nodes.filter((node) => node.kind === 'person');
    expect(cards.map((node) => node.personId).sort()).toEqual(family.people.map((person) => person.id).sort());
    for (let i = 0; i < layout.nodes.length; i += 1) {
      for (let j = i + 1; j < layout.nodes.length; j += 1) {
        const a = layout.nodes[i]; const b = layout.nodes[j];
        if (a.kind === 'union' || b.kind === 'union') continue;
        expect(overlap(a, b), `${a.id} overlaps ${b.id}`).toBe(false);
      }
    }
  });

  it('keeps husbands and wives beside their partner and children under their own marriage', () => {
    const layout = layoutFamily(seed());
    const node = (id: string) => layout.nodes.find((entry) => entry.id === id)!;
    const gap = (a: string, b: string) => Math.abs(node(a).x - node(b).x);
    const pitch = defaultLayoutOptions.cardW + defaultLayoutOptions.spouseGap;
    expect(gap('P0011', 'P0012')).toBe(pitch); // daughter Shivamma and her husband
    expect(gap('P0026', 'P0027')).toBe(pitch); // son Shankarappa and his wife
    expect(node('P0005').y).toBe(node('P0006').y);
    expect(node('P0013').y).toBeGreaterThan(node('P0011').y);
    const ordered = ['P0005', 'P0011', 'P0016', 'P0021', 'P0026'].map((id) => node(id).x);
    expect([...ordered].sort((a, b) => a - b)).toEqual(ordered);
  });

  it('centres the founding couple over their five children and is deterministic', () => {
    const layout = layoutFamily(seed());
    const node = (id: string) => layout.nodes.find((entry) => entry.id === id)!;
    const union = node('U0007');
    const centres = ['P0005', 'P0011', 'P0016', 'P0021', 'P0026'].map((id) => node(id).x + node(id).w / 2);
    expect(union.x + union.w / 2).toBeCloseTo((centres[0] + centres[4]) / 2, 0);
    expect(JSON.stringify(layoutFamily(seed()))).toBe(JSON.stringify(layout));
  });

  it('draws only orthogonal edges', () => {
    for (const edge of layoutFamily(seed()).edges) expect(edge.path).toMatch(/^[MLQ0-9.,\- ]+$/);
  });
});

describe('applyCommand', () => {
  it('adds a daughter-in-law and a grandchild as a valid graph', () => {
    const family = seed();
    const spouse = applyCommand(family, { type: 'addSpouse', personId: 'P0018', person: { given: 'Ananya', gender: 'F' } });
    const child = applyCommand(spouse.family, { type: 'addChild', parentId: 'P0018', person: { given: 'Aarav', gender: 'M' } });
    expect(validateFamilyGraph(child.family).errors).toEqual([]);
    const layout = layoutFamily(child.family);
    const placed = layout.nodes.filter((node) => node.kind === 'person').length;
    expect(placed).toBe(family.people.length + 2);
  });

  it('removes a person and cleans their empty marriage', () => {
    const family = seed();
    const next = applyCommand(family, { type: 'deletePerson', personId: 'P0006' }).family;
    expect(next.people.some((person) => person.id === 'P0006')).toBe(false);
    expect(next.unions.find((union) => union.id === 'U0002')?.partners).toEqual(['P0005', null]);
    expect(validateFamilyGraph(next).errors).toEqual([]);
  });

  it('refuses to remove the root person', () => {
    expect(() => applyCommand(seed(), { type: 'deletePerson', personId: 'P0003' })).toThrow(/root/i);
  });
});
