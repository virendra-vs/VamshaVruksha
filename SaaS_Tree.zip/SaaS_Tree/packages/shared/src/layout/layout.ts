import type { ChildRelation, Family, FamilyUnion } from '../schemas.js';
import { ancestorIds, findParentUnion } from '../graph/relatives.js';
import { orderedChildren } from '../graph/order.js';

export interface LayoutOptions {
  cardW: number;
  cardH: number;
  siblingGap: number;
  spouseGap: number;
  groupGap: number;
  rowGap: number;
  componentGap: number;
  connector: number;
}

export const defaultLayoutOptions: LayoutOptions = {
  cardW: 204, cardH: 66, siblingGap: 28, spouseGap: 64, groupGap: 56, rowGap: 116, componentGap: 160, connector: 24,
};

export type LayoutNodeKind = 'person' | 'ref' | 'ghost' | 'union';

export interface LayoutNode {
  id: string;
  kind: LayoutNodeKind;
  personId?: string;
  unionId?: string;
  x: number; y: number; w: number; h: number;
  row: number;
  /** -1 = founders/ancestors, otherwise the index of the branch that started under the root couple. */
  branch: number;
  role?: 'bloodline' | 'spouse';
  relation?: ChildRelation;
  /** 1 for the eldest child of a marriage; set only on children. */
  birthRank?: number;
  siblingCount?: number;
  unionStatus?: FamilyUnion['status'];
}

export interface LayoutEdge {
  id: string;
  kind: 'marriage' | 'trunk' | 'drop';
  unionId: string;
  path: string;
  branch: number;
  dashed: boolean;
  involves: string[];
}

export interface LayoutRow { row: number; y: number; generation: number }

export interface FamilyLayout {
  nodes: LayoutNode[];
  edges: LayoutEdge[];
  rows: LayoutRow[];
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
}

/** One card in a couple block. */
interface Slot {
  key: string;
  kind: 'person' | 'ref' | 'ghost';
  personId: string | null;
  role: 'bloodline' | 'spouse';
}

interface Link {
  union: FamilyUnion;
  inner: Slot;
  outer: Slot;
  children: Unit[];
  width: number;
  /** Index of the left card of the pair, resolved once the cards are ordered. */
  leftIndex: number;
}

interface Unit {
  kind: 'person' | 'ref';
  personId: string;
  branch: number;
  relation?: ChildRelation;
  rank?: number;
  rankOf?: number;
  cards: Slot[];
  selfIndex: number;
  links: Link[];
  blockWidth: number;
  childrenWidth: number;
  width: number;
  /** Offsets relative to the unit's left edge. */
  blockOffset: number;
  childrenOffset: number;
  anchor: number;
}

const round = (value: number) => Math.round(value * 10) / 10;

/** Orthogonal polyline with rounded corners. */
function polyline(points: [number, number][], radius = 6): string {
  const clean = points.filter((point, index) => index === 0 || point[0] !== points[index - 1][0] || point[1] !== points[index - 1][1]);
  let d = `M${round(clean[0][0])},${round(clean[0][1])}`;
  for (let i = 1; i < clean.length - 1; i += 1) {
    const [px, py] = clean[i - 1];
    const [cx, cy] = clean[i];
    const [nx, ny] = clean[i + 1];
    const d1 = Math.hypot(cx - px, cy - py);
    const d2 = Math.hypot(nx - cx, ny - cy);
    const r = Math.min(radius, d1 / 2, d2 / 2);
    d += ` L${round(cx + ((px - cx) / d1) * r)},${round(cy + ((py - cy) / d1) * r)} Q${round(cx)},${round(cy)} ${round(cx + ((nx - cx) / d2) * r)},${round(cy + ((ny - cy) / d2) * r)}`;
  }
  const last = clean[clean.length - 1];
  return `${d} L${round(last[0])},${round(last[1])}`;
}

export function layoutFamily(family: Family, partial: Partial<LayoutOptions> = {}): FamilyLayout {
  const o = { ...defaultLayoutOptions, ...partial };
  const pitch = o.cardW + o.spouseGap;
  const people = new Map(family.people.map((person) => [person.id, person]));
  const rootId = people.has(family.meta.rootPersonId) ? family.meta.rootPersonId : family.people[0]?.id;
  const unionsByPartner = new Map<string, FamilyUnion[]>();
  for (const union of family.unions) {
    for (const id of union.partners) {
      if (id && people.has(id)) unionsByPartner.set(id, [...(unionsByPartner.get(id) ?? []), union]);
    }
  }
  for (const [id, list] of unionsByPartner) {
    unionsByPartner.set(id, list
      .map((union, index) => ({ union, index }))
      .sort((a, b) => (a.union.order?.[id] ?? a.index + 1) - (b.union.order?.[id] ?? b.index + 1) || a.index - b.index)
      .map((entry) => entry.union));
  }

  const placed = new Set<string>();
  const placedUnions = new Set<string>();
  let nextBranch = 0;
  /** The root person and their ancestors: their descendants get the real cards, relatives elsewhere get reference cards. */
  const lineage = new Set<string>(rootId ? [rootId, ...ancestorIds(family, rootId)] : []);

  const sortedChildren = (union: FamilyUnion) => orderedChildren(union).filter((link) => people.has(link.personId));

  const refUnit = (personId: string, branch: number, relation?: ChildRelation, rank?: number, rankOf?: number): Unit => ({
    kind: 'ref', personId, branch, relation, rank, rankOf, cards: [], selfIndex: 0, links: [], blockWidth: o.cardW, childrenWidth: 0,
    width: o.cardW, blockOffset: 0, childrenOffset: 0, anchor: o.cardW / 2,
  });

  /**
   * A couple block is a chain of cards: the bloodline person in the middle, first marriage to the right,
   * second to the left, and so on. A spouse's own later marriages continue outward from that spouse.
   * When a person has a third or later marriage, a small reference card of them sits beside the new spouse.
   */
  function build(personId: string, branch: number, relation?: ChildRelation, rank?: number, rankOf?: number): Unit {
    placed.add(personId);
    const self: Slot = { key: personId, kind: 'person', personId, role: 'bloodline' };
    const sides: Record<'L' | 'R', { slots: Slot[]; links: Link[] }> = { L: { slots: [], links: [] }, R: { slots: [], links: [] } };
    const mine = (unionsByPartner.get(personId) ?? []).filter((union) => !placedUnions.has(union.id));
    for (const union of mine) placedUnions.add(union.id);

    const spouseSlot = (union: FamilyUnion, otherId: string | null): Slot => {
      if (otherId && people.has(otherId)) {
        if (placed.has(otherId)) return { key: `ref:${otherId}:${union.id}`, kind: 'ref', personId: otherId, role: 'spouse' };
        placed.add(otherId);
        return { key: otherId, kind: 'person', personId: otherId, role: 'spouse' };
      }
      return { key: `ghost:${union.id}`, kind: 'ghost', personId: null, role: 'spouse' };
    };

    const addUnion = (inner: Slot, ownerId: string, union: FamilyUnion, side: 'L' | 'R'): Slot => {
      const otherId = union.partners.find((id) => id !== ownerId) ?? null;
      const outer = spouseSlot(union, otherId);
      sides[side].slots.push(outer);
      const startsBranch = union.partners.includes(rootId ?? '');
      const links = sortedChildren(union);
      const built = new Map<string, Unit>();
      const ranks = new Map(links.map((link, index) => [link.personId, index + 1]));
      const buildChild = (link: (typeof links)[number]): Unit => (placed.has(link.personId)
        ? refUnit(link.personId, branch, link.relation, ranks.get(link.personId), links.length)
        : build(link.personId, startsBranch ? nextBranch++ : branch, link.relation, ranks.get(link.personId), links.length));
      // Build the child on the root's line first, but keep the birth order for drawing.
      for (const link of links.filter((entry) => lineage.has(entry.personId))) built.set(link.personId, buildChild(link));
      for (const link of links) if (!built.has(link.personId)) built.set(link.personId, buildChild(link));
      const children = links.map((link) => built.get(link.personId)!);
      const width = children.reduce((sum, child) => sum + child.width, 0) + Math.max(0, children.length - 1) * o.siblingGap;
      sides[side].links.push({ union, inner, outer, children, width, leftIndex: 0 });
      return outer;
    };

    const extend = (slot: Slot, side: 'L' | 'R') => {
      if (slot.kind !== 'person' || !slot.personId) return;
      for (const union of (unionsByPartner.get(slot.personId) ?? []).filter((entry) => !placedUnions.has(entry.id))) {
        placedUnions.add(union.id);
        extend(addUnion(slot, slot.personId, union, side), side);
      }
    };

    mine.forEach((union, index) => {
      const side = index % 2 === 0 ? 'R' : 'L';
      let inner = self;
      if (sides[side].slots.length > 0) {
        inner = { key: `ref:${personId}:${union.id}`, kind: 'ref', personId, role: 'bloodline' };
        sides[side].slots.push(inner);
      }
      extend(addUnion(inner, personId, union, side), side);
    });

    const cards = [...sides.L.slots].reverse().concat(self, sides.R.slots);
    const selfIndex = sides.L.slots.length;
    const links = [...sides.L.links, ...sides.R.links];
    for (const link of links) link.leftIndex = Math.min(cards.indexOf(link.inner), cards.indexOf(link.outer));
    links.sort((a, b) => a.leftIndex - b.leftIndex);

    const blockWidth = cards.length * o.cardW + (cards.length - 1) * o.spouseGap;
    const groups = links.filter((link) => link.children.length > 0);
    const childrenWidth = groups.reduce((sum, link) => sum + link.width, 0) + Math.max(0, groups.length - 1) * o.groupGap;
    let width = Math.max(blockWidth, childrenWidth);
    let blockOffset = (width - blockWidth) / 2;
    let childrenOffset = (width - childrenWidth) / 2;
    if (groups.length === 1) {
      // Put the marriage connector over the midpoint of the first and last child card.
      const only = groups[0];
      const connectorOffset = only.leftIndex * pitch + o.cardW + o.spouseGap / 2;
      let start = 0;
      const anchors = only.children.map((child) => { const anchor = start + child.anchor; start += child.width + o.siblingGap; return anchor; });
      const blockLeft = (anchors[0] + anchors[anchors.length - 1]) / 2 - connectorOffset;
      const minX = Math.min(0, blockLeft);
      width = Math.max(childrenWidth, blockLeft + blockWidth) - minX;
      childrenOffset = -minX;
      blockOffset = blockLeft - minX;
    }
    return { kind: 'person', personId, branch, relation, rank, rankOf, cards, selfIndex, links, blockWidth, childrenWidth, width, blockOffset, childrenOffset, anchor: blockOffset + selfIndex * pitch + o.cardW / 2 };
  }

  const climb = (start: string): string => {
    const seen = new Set([start]);
    let top = start;
    for (;;) {
      const parent = findParentUnion(family, top);
      const next = parent?.union.partners.find((id) => id && people.has(id) && !placed.has(id) && !seen.has(id));
      if (!next) return top;
      seen.add(next);
      top = next;
    }
  };

  const roots: Unit[] = [];
  if (rootId) roots.push(build(climb(rootId), -1));
  for (const person of family.people) {
    if (!placed.has(person.id)) roots.push(build(climb(person.id), -1));
  }

  const nodes: LayoutNode[] = [];
  const edges: LayoutEdge[] = [];
  const rowY = (row: number) => row * (o.cardH + o.rowGap);
  let rootRow = 0;

  function place(unit: Unit, x0: number, row: number): number {
    const y = rowY(row);
    if (unit.kind === 'ref') {
      const x = x0 + (unit.width - o.cardW) / 2;
      nodes.push({ id: `ref:${unit.personId}:${row}:${Math.round(x)}`, kind: 'ref', personId: unit.personId, x, y, w: o.cardW, h: o.cardH, row, branch: unit.branch, relation: unit.relation, birthRank: unit.rank, siblingCount: unit.rankOf });
      return x + o.cardW / 2;
    }
    if (unit.personId === rootId) rootRow = row;
    const blockX = x0 + unit.blockOffset;
    const xs = unit.cards.map((_, index) => blockX + index * pitch);

    unit.cards.forEach((slot, index) => {
      nodes.push({
        id: slot.key, kind: slot.kind, personId: slot.personId ?? undefined, unionId: slot.kind === 'ghost' ? slot.key.slice('ghost:'.length) : undefined,
        x: xs[index], y, w: o.cardW, h: o.cardH, row, branch: unit.branch,
        role: slot.role === 'bloodline' && slot.kind === 'person' ? 'bloodline' : 'spouse',
        relation: slot.kind === 'person' && slot.role === 'bloodline' ? unit.relation : undefined,
        birthRank: slot.kind === 'person' && slot.role === 'bloodline' ? unit.rank : undefined,
        siblingCount: slot.kind === 'person' && slot.role === 'bloodline' ? unit.rankOf : undefined,
      });
    });

    const connectorXs = new Map<string, number>();
    for (const link of unit.links) {
      const x1 = xs[link.leftIndex] + o.cardW;
      const x2 = xs[link.leftIndex + 1];
      const cx = (x1 + x2) / 2;
      const cy = y + o.cardH / 2;
      connectorXs.set(link.union.id, cx);
      nodes.push({ id: link.union.id, kind: 'union', unionId: link.union.id, x: cx - o.connector / 2, y: cy - o.connector / 2, w: o.connector, h: o.connector, row, branch: unit.branch, unionStatus: link.union.status });
      const r = o.connector / 2 + 2;
      edges.push({
        id: `m:${link.union.id}`, kind: 'marriage', unionId: link.union.id, branch: unit.branch,
        dashed: link.union.status !== 'active', involves: link.union.partners.filter((id): id is string => !!id),
        path: `M${round(x1)},${round(cy)} L${round(cx - r)},${round(cy)} M${round(cx + r)},${round(cy)} L${round(x2)},${round(cy)}`,
      });
    }

    // Children are laid out in connector order so buses never cross.
    const groups = unit.links.filter((link) => link.children.length > 0);
    let cursor = x0 + unit.childrenOffset;
    groups.forEach((link, groupIndex) => {
      let childX = cursor;
      const anchors = link.children.map((child) => {
        const anchor = place(child, childX, row + 1);
        childX += child.width + o.siblingGap;
        return anchor;
      });
      cursor += link.width + o.groupGap;
      const cx = connectorXs.get(link.union.id)!;
      const cy = y + o.cardH / 2;
      const busY = y + o.cardH + o.rowGap / 2 + (groupIndex - (groups.length - 1) / 2) * 12;
      const childTop = rowY(row + 1);
      const involves = [...link.union.partners.filter((id): id is string => !!id), ...link.children.map((child) => child.personId)];
      edges.push({ id: `t:${link.union.id}`, kind: 'trunk', unionId: link.union.id, branch: unit.branch, dashed: false, involves, path: polyline([[cx, cy + o.connector / 2 + 2], [cx, busY]]) });
      link.children.forEach((child, i) => {
        edges.push({
          id: `d:${link.union.id}:${child.personId}`, kind: 'drop', unionId: link.union.id, branch: child.branch,
          dashed: !!child.relation && child.relation !== 'biological', involves,
          path: polyline([[cx, busY], [anchors[i], busY], [anchors[i], childTop]]),
        });
      });
    });
    return blockX + unit.selfIndex * pitch + o.cardW / 2;
  }

  let cursor = 0;
  for (const root of roots) {
    place(root, cursor, 0);
    cursor += root.width + o.componentGap;
  }

  const rowNumbers = [...new Set(nodes.map((node) => node.row))].sort((a, b) => a - b);
  const rows = rowNumbers.map((row) => ({ row, y: rowY(row), generation: row - rootRow }));
  const xs = nodes.length ? nodes : [{ x: 0, y: 0, w: 0, h: 0 }];
  const bounds = {
    minX: Math.min(...xs.map((n) => n.x)), minY: Math.min(...xs.map((n) => n.y)),
    maxX: Math.max(...xs.map((n) => n.x + n.w)), maxY: Math.max(...xs.map((n) => n.y + n.h)),
  };
  return { nodes, edges, rows, bounds };
}
