import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { FamilySchema, type Family } from '../schemas.js';
import { applyCommand, type Command } from '../commands.js';
import { validateFamilyGraph } from '../graph/validate.js';
import { defaultLayoutOptions, layoutFamily } from './layout.js';

const seed = () => FamilySchema.parse(JSON.parse(readFileSync(new URL('../../../../apps/api/test-fixtures/family.json', import.meta.url), 'utf8')));
const run = (family: Family, ...commands: Command[]) => commands.reduce((current, command) => applyCommand(current, command).family, family);
const added = (family: Family, command: Command) => { const r = applyCommand(family, command); return { family: r.family, id: r.focusId! }; };
const overlap = (a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) =>
  a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;

/** Basavarajeshwari (P0017) is also Sangappa's elder brother's granddaughter. */
function relativeMarriage() {
  let state = added(seed(), { type: 'addSibling', personId: 'P0003', person: { given: 'Elder', surname: 'Shankaragulli', gender: 'M' } });
  const elder = state.id;
  state = added(state.family, { type: 'addChild', parentId: elder, person: { given: 'Daughter', gender: 'F' } });
  const daughter = state.id;
  const family = run(state.family, { type: 'linkChild', parentId: daughter, childId: 'P0017' });
  return { family, elder, daughter };
}

describe('linking existing people', () => {
  it('connects a person who is already in the tree instead of creating a duplicate', () => {
    const { family } = relativeMarriage();
    expect(family.people.filter((p) => p.name.given === 'Basavarajeshwari')).toHaveLength(1);
    expect(validateFamilyGraph(family).errors).toEqual([]);
    const sheIsChildOf = family.unions.filter((u) => u.children.some((c) => c.personId === 'P0017'));
    expect(sheIsChildOf).toHaveLength(1);
    expect(family.unions.some((u) => u.partners.includes('P0017') && u.partners.includes('P0016'))).toBe(true);
  });

  it('draws her once beside Venkappa and as a reference card under her own parents', () => {
    const { family } = relativeMarriage();
    const layout = layoutFamily(family);
    const real = layout.nodes.filter((n) => n.kind === 'person' && n.personId === 'P0017');
    const refs = layout.nodes.filter((n) => n.kind === 'ref' && n.personId === 'P0017');
    expect(real).toHaveLength(1);
    expect(refs.length).toBeGreaterThanOrEqual(1);
    const venkappa = layout.nodes.find((n) => n.id === 'P0016')!;
    expect(Math.abs(real[0].x - venkappa.x)).toBe(defaultLayoutOptions.cardW + defaultLayoutOptions.spouseGap);
    expect(layout.nodes.some((n) => n.id === 'P0018')).toBe(true);
    for (let i = 0; i < layout.nodes.length; i += 1) {
      for (let j = i + 1; j < layout.nodes.length; j += 1) {
        const a = layout.nodes[i]; const b = layout.nodes[j];
        if (a.kind === 'union' || b.kind === 'union') continue;
        expect(overlap(a, b), `${a.id} overlaps ${b.id}`).toBe(false);
      }
    }
  });

  it('links an existing spouse, parent and sibling', () => {
    const spouse = run(seed(), { type: 'linkSpouse', personId: 'P0009', spouseId: 'P0007' });
    expect(spouse.unions.some((u) => u.partners.includes('P0009') && u.partners.includes('P0007'))).toBe(true);
    const oneParent = added(seed(), { type: 'addChild', parentId: 'P0019', person: { given: 'Kid', gender: 'M' } });
    const parent = run(oneParent.family, { type: 'linkParent', childId: oneParent.id, parentId: 'P0007' });
    expect(parent.unions.find((u) => u.children.some((c) => c.personId === oneParent.id))?.partners).toEqual(['P0019', 'P0007']);
    expect(validateFamilyGraph(parent).errors).toEqual([]);
    expect(() => applyCommand(seed(), { type: 'linkParent', childId: 'P0019', parentId: 'P0007' })).toThrow(/already has two parents/);
  });

  it('refuses impossible links with a clear message', () => {
    expect(() => applyCommand(seed(), { type: 'linkChild', parentId: 'P0018', childId: 'P0003' })).toThrow(/ancestor/);
    expect(() => applyCommand(seed(), { type: 'linkParent', childId: 'P0003', parentId: 'P0018' })).toThrow(/descendant/);
    expect(() => applyCommand(seed(), { type: 'linkChild', parentId: 'P0005', childId: 'P0018' })).toThrow(/already has biological parents/);
    expect(() => applyCommand(seed(), { type: 'linkSpouse', personId: 'P0016', spouseId: 'P0017' })).toThrow(/already linked/);
    expect(() => applyCommand(seed(), { type: 'linkSpouse', personId: 'P0016', spouseId: 'P0016' })).toThrow(/themselves/);
  });

  it('allows linking as adopted when the person already has biological parents', () => {
    const family = run(seed(), { type: 'linkChild', parentId: 'P0005', childId: 'P0018', relation: 'adopted' });
    expect(validateFamilyGraph(family).errors).toEqual([]);
  });

  it('unlinks a marriage or a child without deleting anyone', () => {
    const { family, daughter } = relativeMarriage();
    const parentUnion = family.unions.find((u) => u.partners.includes(daughter))!;
    const detached = run(family, { type: 'detachChild', unionId: parentUnion.id, personId: 'P0017' });
    expect(detached.people).toHaveLength(family.people.length);
    expect(detached.unions.some((u) => u.children.some((c) => c.personId === 'P0017') && u.partners.includes(daughter))).toBe(false);
    const marriage = family.unions.find((u) => u.partners.includes('P0016') && u.partners.includes('P0017'))!;
    const apart = run(family, { type: 'removeUnion', unionId: marriage.id });
    expect(apart.people).toHaveLength(family.people.length);
    expect(apart.unions.some((u) => u.id === marriage.id)).toBe(false);
  });
});
