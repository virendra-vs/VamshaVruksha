import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { FamilySchema, type Family } from '../schemas.js';
import { applyCommand, type Command } from '../commands.js';
import { validateFamilyGraph } from '../graph/validate.js';
import { layoutFamily } from './layout.js';

const seed = () => FamilySchema.parse(JSON.parse(readFileSync(new URL('../../../../apps/api/test-fixtures/family.json', import.meta.url), 'utf8')));
const overlap = (a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) =>
  a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;

function run(family: Family, ...commands: Command[]) {
  let current = family;
  let focus = '';
  for (const command of commands) { const result = applyCommand(current, command); current = result.family; focus = result.focusId ?? focus; }
  return { family: current, focus };
}

describe('remarriage', () => {
  it('lets a divorced person marry again, with children from each marriage', () => {
    const first = run(seed(), { type: 'addSpouse', personId: 'P0018', person: { given: 'Kruthi', gender: 'F' } });
    const kruthi = first.focus;
    const second = run(first.family, { type: 'addSpouse', personId: 'P0018', person: { given: 'Meera', gender: 'F' }, previousStatus: 'divorced' });
    const unionsOfVirendra = second.family.unions.filter((u) => u.partners.includes('P0018'));
    expect(unionsOfVirendra.map((u) => u.status)).toEqual(['divorced', 'active']);
    const withChildren = run(second.family,
      { type: 'addChild', parentId: 'P0018', unionId: unionsOfVirendra[0].id, person: { given: 'Aarav', gender: 'M' } },
      { type: 'addChild', parentId: 'P0018', unionId: unionsOfVirendra[1].id, person: { given: 'Diya', gender: 'F' } });
    expect(validateFamilyGraph(withChildren.family).errors).toEqual([]);
    expect(kruthi).toBeTruthy();

    const layout = layoutFamily(withChildren.family);
    const cards = layout.nodes.filter((n) => n.kind === 'person');
    expect(new Set(cards.map((n) => n.personId)).size).toBe(withChildren.family.people.length);
    expect(layout.nodes.filter((n) => n.kind === 'union' && unionsOfVirendra.some((u) => u.id === n.id))).toHaveLength(2);
  });

  it('draws a spouse\'s later marriage next to that spouse, and a third marriage with a reference card', () => {
    let state = run(seed(), { type: 'addSpouse', personId: 'P0018', person: { given: 'Kruthi', gender: 'F' } });
    const kruthi = state.focus;
    state = run(state.family, { type: 'updateUnion', unionId: state.family.unions.find((u) => u.partners.includes(kruthi))!.id, status: 'divorced' });
    state = run(state.family, { type: 'addSpouse', personId: kruthi, person: { given: 'Rohan', gender: 'M' } });
    const rohan = state.focus;
    state = run(state.family,
      { type: 'addSpouse', personId: 'P0018', person: { given: 'Meera', gender: 'F' } },
      { type: 'addSpouse', personId: 'P0018', person: { given: 'Nisha', gender: 'F' } });
    expect(validateFamilyGraph(state.family).errors).toEqual([]);

    const layout = layoutFamily(state.family);
    const node = (id: string) => layout.nodes.find((n) => n.id === id)!;
    const pitch = node(kruthi).x - node('P0018').x;
    expect(Math.abs(node(rohan).x - node(kruthi).x)).toBe(Math.abs(pitch));
    expect(layout.nodes.some((n) => n.kind === 'ref' && n.personId === 'P0018')).toBe(true);
    expect(new Set(layout.nodes.filter((n) => n.kind === 'person').map((n) => n.personId)).size).toBe(state.family.people.length);
    for (let i = 0; i < layout.nodes.length; i += 1) {
      for (let j = i + 1; j < layout.nodes.length; j += 1) {
        const a = layout.nodes[i]; const b = layout.nodes[j];
        if (a.kind === 'union' || b.kind === 'union') continue;
        expect(overlap(a, b), `${a.id} overlaps ${b.id}`).toBe(false);
      }
    }
  });
});
