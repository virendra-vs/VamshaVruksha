import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { FamilySchema, type Family } from '../schemas.js';
import { applyCommand, type Command } from '../commands.js';
import { validateFamilyGraph } from '../graph/validate.js';
import { layoutFamily } from './layout.js';

const seed = () => FamilySchema.parse(JSON.parse(readFileSync(new URL('../../../../apps/api/test-fixtures/family.json', import.meta.url), 'utf8')));
const run = (family: Family, ...commands: Command[]) => commands.reduce((current, command) => applyCommand(current, command).family, family);
const added = (family: Family, command: Command) => { const r = applyCommand(family, command); return { family: r.family, id: r.focusId! }; };
const kids = (family: Family, unionId: string) => family.unions.find((u) => u.id === unionId)!.children.map((c) => c.personId).sort();
const virendraKids = ['P0018', 'P0019', 'P0020'];

describe('recovering from an accidental delete', () => {
  it('keeps the marriage and children as an unknown partner when the spouse is deleted', () => {
    const family = run(seed(), { type: 'deletePerson', personId: 'P0017' });
    const union = family.unions.find((u) => u.id === 'U0004')!;
    expect(union.partners).toEqual(['P0016', null]);
    expect(kids(family, 'U0004')).toEqual(virendraKids);
    expect(layoutFamily(family).nodes.some((n) => n.kind === 'ghost' && n.unionId === 'U0004')).toBe(true);
  });

  it('fills the unknown partner with a new person so the children stay with the marriage', () => {
    const deleted = run(seed(), { type: 'deletePerson', personId: 'P0017' });
    const fixed = added(deleted, { type: 'fillPartner', unionId: 'U0004', person: { given: 'Basavarajeshwari', surname: 'Shankaragulli', gender: 'F' } });
    expect(fixed.family.unions.find((u) => u.id === 'U0004')!.partners).toEqual(['P0016', fixed.id]);
    expect(kids(fixed.family, 'U0004')).toEqual(virendraKids);
    expect(validateFamilyGraph(fixed.family).errors).toEqual([]);
    expect(layoutFamily(fixed.family).nodes.some((n) => n.kind === 'ghost')).toBe(false);
  });

  it('can also fill the unknown partner with someone already in the tree', () => {
    const deleted = run(seed(), { type: 'deletePerson', personId: 'P0017' });
    const fixed = run(deleted, { type: 'fillPartner', unionId: 'U0004', personId: 'P0010', anchorSurname: undefined });
    expect(fixed.unions.find((u) => u.id === 'U0004')!.partners).toEqual(['P0016', 'P0010']);
    expect(() => applyCommand(fixed, { type: 'fillPartner', unionId: 'U0004', personId: 'P0010' })).toThrow(/both partners/);
  });

  it('repairs the duplicate you already created: new spouse in a new marriage, kids on the old unknown one', () => {
    // Reproduce it: the old marriage is not "active", so adding a spouse starts a new marriage instead of reusing it.
    const deleted = run(seed(), { type: 'deletePerson', personId: 'P0017' }, { type: 'updateUnion', unionId: 'U0004', status: 'separated' });
    const recreated = added(deleted, { type: 'addSpouse', personId: 'P0016', person: { given: 'Basavarajeshwari', gender: 'F' } });
    const unionsOfVenkappa = recreated.family.unions.filter((u) => u.partners.includes('P0016'));
    expect(unionsOfVenkappa).toHaveLength(2);
    expect(kids(recreated.family, 'U0004')).toEqual(virendraKids);

    const repaired = run(recreated.family, { type: 'fillPartner', unionId: 'U0004', personId: recreated.id });
    const after = repaired.unions.filter((u) => u.partners.includes('P0016'));
    expect(after).toHaveLength(1);
    expect(after[0].partners).toContain(recreated.id);
    expect(kids(repaired, after[0].id)).toEqual(virendraKids);
    expect(validateFamilyGraph(repaired).errors).toEqual([]);
  });

  it('lets the add-spouse form choose to fill the unknown partner directly', () => {
    const deleted = run(seed(), { type: 'deletePerson', personId: 'P0017' }, { type: 'updateUnion', unionId: 'U0004', status: 'separated' });
    const filled = added(deleted, { type: 'addSpouse', personId: 'P0016', unionId: 'U0004', person: { given: 'Basavarajeshwari', gender: 'F' } });
    expect(filled.family.unions.filter((u) => u.partners.includes('P0016'))).toHaveLength(1);
    expect(kids(filled.family, 'U0004')).toEqual(virendraKids);
    const fresh = added(deleted, { type: 'addSpouse', personId: 'P0016', unionId: 'new', person: { given: 'Someone', gender: 'F' } });
    expect(fresh.family.unions.filter((u) => u.partners.includes('P0016'))).toHaveLength(2);
  });
});

describe('merging duplicate people', () => {
  it('merges a duplicate into the original, moving its relatives and photos', () => {
    const duplicate = added(seed(), { type: 'addSpouse', personId: 'P0016', unionId: 'new', person: { given: 'Basavarajeshwari', surname: 'Dup', gender: 'F', birthYear: '1963' } });
    const unionOfDup = duplicate.family.unions.find((u) => u.partners.includes(duplicate.id))!;
    const withChild = added(duplicate.family, { type: 'addChild', parentId: 'P0016', unionId: unionOfDup.id, person: { given: 'Extra', gender: 'M' } });
    withChild.family.media.push({ id: 'm_aaaaaaaaaaaaaaaa', kind: 'photo', eventType: 'family', personIds: [duplicate.id], caption: null, date: null });

    const merged = run(withChild.family, { type: 'mergePeople', keepId: 'P0017', removeId: duplicate.id });
    expect(merged.people.some((p) => p.id === duplicate.id)).toBe(false);
    expect(merged.unions.filter((u) => u.partners.includes('P0016'))).toHaveLength(1);
    expect(merged.unions.find((u) => u.partners.includes('P0017'))!.children).toHaveLength(4);
    expect(merged.media[0].personIds).toEqual(['P0017']);
    expect(merged.people.find((p) => p.id === 'P0017')!.vitals?.birth?.date?.value).toBe('1963');
    expect(validateFamilyGraph(merged).errors).toEqual([]);
  });

  it('refuses nonsensical merges', () => {
    expect(() => applyCommand(seed(), { type: 'mergePeople', keepId: 'P0016', removeId: 'P0017' })).toThrow(/married to each other/);
    expect(() => applyCommand(seed(), { type: 'mergePeople', keepId: 'P0003', removeId: 'P0018' })).toThrow(/ancestor/);
    expect(() => applyCommand(seed(), { type: 'mergePeople', keepId: 'P0018', removeId: 'P0007' })).toThrow(/biological parents/);
  });
});
