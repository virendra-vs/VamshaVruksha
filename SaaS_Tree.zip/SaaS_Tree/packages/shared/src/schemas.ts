import { z } from 'zod';

const DateValue = z.object({ value: z.string().nullable(), precision: z.string().optional() }).passthrough();
const Vital = z.object({
  date: DateValue.nullable().optional(),
  place: z.object({ text: z.string().nullable().optional() }).passthrough().nullable().optional(),
}).passthrough();

export const PersonSchema = z.object({
  id: z.string().min(1).max(64),
  name: z.object({
    given: z.string().min(1),
    middle: z.string().nullable().optional(),
    surname: z.string().nullable().optional(),
    nickname: z.string().nullable().optional(),
    birthSurname: z.string().nullable().optional(),
    aliases: z.array(z.string()).optional(),
    localScript: z.record(z.string()).optional(),
  }).passthrough(),
  gender: z.enum(['M', 'F', 'O', 'U']),
  isLiving: z.boolean(),
  status: z.enum(['confirmed', 'unverified', 'placeholder']).default('confirmed'),
  vitals: z.object({ birth: Vital.nullable().optional(), death: Vital.nullable().optional() }).passthrough().optional(),
  profile: z.object({
    occupation: z.string().nullable().optional(),
    education: z.string().nullable().optional(),
    bio: z.string().nullable().optional(),
    currentPlace: z.string().nullable().optional(),
    photoMediaId: z.string().nullable().optional(),
    contacts: z.object({
      phone: z.string().nullable().optional(),
      email: z.string().nullable().optional(),
      address: z.string().nullable().optional(),
    }).passthrough().nullable().optional(),
  }).passthrough().optional(),
  custom: z.record(z.unknown()).optional(),
  tags: z.array(z.string()).default([]),
}).passthrough();

export const UnionSchema = z.object({
  id: z.string().min(1).max(64),
  type: z.enum(['marriage', 'partnership', 'engagement', 'unknown']),
  status: z.enum(['active', 'divorced', 'separated', 'widowed', 'annulled']),
  partners: z.tuple([z.string().nullable(), z.string().nullable()]),
  order: z.record(z.number()).optional(),
  startDate: DateValue.nullable().optional(),
  place: z.object({ text: z.string().nullable().optional() }).passthrough().nullable().optional(),
  children: z.array(z.object({
    personId: z.string(),
    relation: z.enum(['biological', 'adopted', 'step', 'foster', 'guardian']),
    birthOrder: z.number().int().positive(),
  }).passthrough()),
}).passthrough();

export const MEDIA_EVENT_TYPES = ['birth', 'naming', 'birthday', 'education', 'marriage', 'festival', 'family', 'achievement', 'memorial', 'other'] as const;
export type MediaEventType = (typeof MEDIA_EVENT_TYPES)[number];

export const MediaItemSchema = z.object({
  id: z.string().min(1).max(64),
  kind: z.literal('photo').default('photo'),
  caption: z.string().nullable().optional(),
  eventType: z.enum(MEDIA_EVENT_TYPES).default('other'),
  date: DateValue.nullable().optional(),
  personIds: z.array(z.string()).default([]),
  width: z.number().optional(),
  height: z.number().optional(),
  sizeBytes: z.number().optional(),
  uploadedAt: z.string().optional(),
}).passthrough();

export const FamilySchema = z.object({
  schemaVersion: z.string(),
  meta: z.object({
    id: z.string(), tenantId: z.string(), name: z.string(), surname: z.string(),
    rootPersonId: z.string(), dataVersion: z.number().int().positive(), updatedAt: z.string(),
  }).passthrough(),
  config: z.record(z.unknown()).default({}),
  people: z.array(PersonSchema),
  unions: z.array(UnionSchema),
  events: z.array(z.unknown()).default([]),
  media: z.array(MediaItemSchema).default([]),
  sources: z.array(z.unknown()).default([]),
  notes: z.array(z.unknown()).default([]),
}).passthrough();

export const GraphSchema = z.object({ people: z.array(PersonSchema), unions: z.array(UnionSchema), media: z.array(MediaItemSchema).optional() });

export type Person = z.infer<typeof PersonSchema>;
export type Family = z.infer<typeof FamilySchema>;
export type FamilyUnion = z.infer<typeof UnionSchema>;
export type MediaItem = z.infer<typeof MediaItemSchema>;
export type ChildRelation = FamilyUnion['children'][number]['relation'];
export type ValidationIssue = { code: string; message: string; entityType: string; entityId: string; path: string };
