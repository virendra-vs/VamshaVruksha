import type { Person } from './schemas.js';

/** Given, middle and current surname, e.g. "Shivamma Hanumareddy". */
export function fullName(person: Person): string {
  const { given, middle, surname } = person.name;
  return [given, middle, surname].map((part) => part?.trim()).filter(Boolean).join(' ');
}

/** "née Shankaragulli" when the birth surname differs from the current one. */
export function birthNameNote(person: Person): string | null {
  const birth = person.name.birthSurname?.trim();
  if (!birth || birth === person.name.surname?.trim()) return null;
  return `née ${birth}`;
}

/** Nickname, pet names and other names, without duplicates. */
export function knownAs(person: Person): string[] {
  const all = [person.name.nickname, ...(person.name.aliases ?? [])].map((name) => name?.trim()).filter((name): name is string => !!name);
  return [...new Set(all)];
}

/** The surname a person was born with, used for their siblings. */
export const birthSurnameOf = (person: Person): string => person.name.birthSurname?.trim() || person.name.surname?.trim() || '';
