// Builds the app and packs a ready-to-run zip for Azure App Service (Linux, Node 20+).
// Usage: corepack pnpm package:azure   ->   deploy/vamsha-azure.zip
import { execSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { zipDirectory } from './zip.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Secrets must be supplied as Azure App Service application settings.
const DEMO_ENV = {
  NODE_ENV: 'production',
  DATA_DIR: '/home/data',
  SEED_ON_EMPTY: 'true',
};
const initialDataDir = process.env.AZURE_DATA_DIR ? path.resolve(process.env.AZURE_DATA_DIR) : undefined;
const stage = path.join(root, 'deploy', 'stage');
const zip = path.join(root, 'deploy', 'vamsha-azure.zip');
const run = (command, cwd = root) => execSync(command, { cwd, stdio: 'inherit' });
const readJson = (file) => JSON.parse(readFileSync(file, 'utf8'));

if (initialDataDir && !existsSync(path.join(initialDataDir, 'tenants'))) {
  throw new Error(`AZURE_DATA_DIR must contain a tenants directory: ${initialDataDir}`);
}

console.log('\n[1/5] Building shared, api and web...');
run('corepack pnpm build');

console.log('\n[2/5] Collecting build output...');
rmSync(path.join(root, 'deploy'), { recursive: true, force: true });
mkdirSync(stage, { recursive: true });
cpSync(path.join(root, 'apps/api/dist'), path.join(stage, 'apps/api/dist'), { recursive: true });
cpSync(path.join(root, 'apps/api/src/seed'), path.join(stage, 'apps/api/dist/seed'), { recursive: true });
cpSync(path.join(root, 'apps/web/dist'), path.join(stage, 'apps/web/dist'), { recursive: true });
writeFileSync(path.join(stage, 'apps/api/package.json'), JSON.stringify({ name: '@vamsha/api', private: true, type: 'module' }, null, 2));

console.log('\n[3/5] Installing production dependencies...');
const { '@vamsha/shared': _shared, ...dependencies } = readJson(path.join(root, 'apps/api/package.json')).dependencies;
const sharedPackage = readJson(path.join(root, 'packages/shared/package.json'));
writeFileSync(path.join(stage, 'package.json'), JSON.stringify({
  name: 'vamsha', version: readJson(path.join(root, 'package.json')).version, private: true, type: 'module',
  engines: { node: '>=20' },
  scripts: { start: 'bash start.sh' },
  dependencies: { ...dependencies, ...sharedPackage.dependencies },
}, null, 2));
run('npm install --omit=dev --ignore-scripts --no-bin-links --no-audit --no-fund', stage);
writeFileSync(path.join(stage, '.env'), `${Object.entries(DEMO_ENV).map(([key, value]) => `${key}=${value}`).join('\n')}\n`);
writeFileSync(path.join(stage, 'start.sh'), [
  'set -eu',
  'mkdir -p /home/data',
  'if [ -d /home/site/wwwroot/initial-data ]; then',
  '  cp -an /home/site/wwwroot/initial-data/. /home/data/',
  'fi',
  'cd /home/site/wwwroot',
  'exec node apps/api/dist/server.js',
  '',
].join('\n'));

if (initialDataDir) {
  const initialDataTarget = path.join(stage, 'initial-data');
  mkdirSync(initialDataTarget, { recursive: true });
  for (const entry of ['tenants', 'backups']) {
    const source = path.join(initialDataDir, entry);
    if (existsSync(source)) cpSync(source, path.join(initialDataTarget, entry), { recursive: true });
  }
}

// The shared workspace package is copied in as a normal module, so the zip holds no symlinks.
const sharedTarget = path.join(stage, 'node_modules/@vamsha/shared');
mkdirSync(sharedTarget, { recursive: true });
cpSync(path.join(root, 'packages/shared/dist'), path.join(sharedTarget, 'dist'), { recursive: true });
writeFileSync(path.join(sharedTarget, 'package.json'), JSON.stringify({ ...sharedPackage, scripts: undefined, devDependencies: undefined }, null, 2));

console.log('\n[4/5] Zipping...');
const { files } = zipDirectory(stage, zip);
console.log(`${files} files`);

console.log('\n[5/5] Checking the package...');
for (const required of ['apps/api/dist/server.js', 'apps/api/dist/seed/family.json', 'apps/api/dist/seed/media', 'apps/web/dist/index.html', 'node_modules/@vamsha/shared/dist/index.js', 'node_modules/fastify/package.json', '.env', 'start.sh']) {
  if (!existsSync(path.join(stage, required))) throw new Error(`Package is missing ${required}`);
}
if (initialDataDir && !existsSync(path.join(stage, 'initial-data/tenants'))) throw new Error('Package is missing the requested initial tenant data.');
console.log(`\nDone: ${zip} (${(statSync(zip).size / 1024 / 1024).toFixed(1)} MB)`);
console.log(`Unpacked copy for a local test: ${stage}`);
