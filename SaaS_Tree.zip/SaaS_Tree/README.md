# Vamsha

Vamsha is a multi-tenant family archive, built around a family graph of `people[]` and `unions[]`. This workspace is the first runnable implementation slice of the supplied specification.

## Run locally

Requirements: Node.js 20 or newer and Corepack.

```powershell
corepack pnpm install
corepack pnpm dev
```

Open the Vite app at `http://localhost:5173`. The API listens on `http://localhost:3000`; `/health`, `/ready`, and the family read/validation endpoints are available there. Vite proxies `/api` requests to the API. Local JSON data is kept in `./data` by default and is excluded from Git. The development server creates the Shankaragulli sample only when that family file does not exist.

To build and test:

```powershell
corepack pnpm test
corepack pnpm build
```

Copy `.env.example` to `.env` to override local settings. No secret in that example is a production secret.

## Architecture

```mermaid
flowchart LR
  Browser[React + Vite + React Flow] -->|same-origin /api| API[Fastify API]
  API --> Shared[Shared Zod schemas + graph validation]
  API --> Repo[FamilyRepository]
  Repo --> Files[DATA_DIR JSON files]
  Repo --> Backups[Rolling pre-write JSON snapshots]
```

`packages/shared` owns the family/union schemas, ID helper, and initial graph integrity checks. `apps/api` owns Fastify routes and file-backed family persistence. `apps/web` contains the responsive tree workspace and profile panel. The repository writes JSON through a temporary file, fsync, then rename; writes are serialized per family, reject stale `If-Match` versions, validate graph integrity, and retain up to 20 pre-write JSON snapshots.

## Data safety

- The sample seed is non-destructive: an existing family file is never overwritten.
- Set `DATA_DIR=/home/data` in App Service. Production rejects a data directory inside the application folder.
- Keep App Service to one instance; current file locks are process-local.
- Admin sign-in is implemented, but viewers can browse the family tree without signing in. Do not publish sensitive family data unless you intend it to be publicly viewable or protect the site with an external access-control layer.
- Off-site backup/export archives and import/restore workflows are available from the Admin menu (Export / Import backup).

## Deploy to Azure App Service (Linux, Node 20 or 22)

1. `corepack pnpm package:azure` builds everything and writes `deploy/vamsha-azure.zip` with production dependencies. To include an existing data directory on first startup, set `AZURE_DATA_DIR` to its path before packaging. Only `tenants` and `backups` are copied; local platform credentials are excluded. The startup script imports those files into `/home/data` without overwriting files already there.
2. Before deploying, configure `NODE_ENV=production`, `DATA_DIR=/home/data`, `SEED_ON_EMPTY=true`, a strong `JWT_SECRET`, and an `ADMIN_PASSWORD` of at least 10 characters as App Service application settings. The package contains no demo credentials.
3. Upload the zip: `az webapp deploy --resource-group <rg> --name <app> --src-path deploy/vamsha-azure.zip --type zip`, or use the App Service Zip Deploy UI. The package's start script imports initial data, then starts the API. Subsequent deployments do not overwrite existing `/home/data` files.
4. Health check path: `/health`. Keep the plan at one instance; file locks are process-local.

The old small demo family used by the unit tests lives in `apps/api/test-fixtures/family.json`.

## Delivery status

Working now: light and dark themes; the tree loaded from the API with a deterministic layout engine in `packages/shared` (couples side by side, each marriage with its own children, orthogonal rounded connectors, branch colours, generation bands, dashed adopted/step children, unknown-parent ghost cards); photo avatars with an initial fallback; a tabbed person panel (Family, About, Story) with rich optional details; admin and view-only modes (scrypt-hashed admin password, signed httpOnly session cookie, CSRF header, per-client lockout); admin-only editing with undo/redo; photo upload (re-encoded in the browser, which strips EXIF); backup export with photos and validated import with confirmation; contact details hidden from viewers on the server.

Set `ADMIN_PASSWORD` (10+ characters) before the first start. It is hashed into `DATA_DIR/platform/admin.json`; after that the file wins, so change the password from the Admin menu. Anyone can browse the tree without signing in by design, so deploy it behind your own access control if the family data must stay private.

Still pending from the full specification: per-user accounts and roles, kinship terms, layout in a Web Worker, wrapping of very large sibling groups, ancestor collapse, alternate views (fan, descendants, list, timeline), merge-style import, scheduled snapshots, PWA/i18n and Azure packaging.
