import { mkdir, readFile, readdir, rename, stat, writeFile, open, rm, realpath } from 'node:fs/promises';
import path from 'node:path';
import { FamilySchema, validateFamilyGraph, type Family } from '@vamsha/shared';
import { MEDIA_ID } from '../media.js';

const tenantPattern = /^[a-z0-9-]{1,64}$/;
const familyPattern = /^[a-z0-9-]{1,64}$/;
const locks = new Map<string, Promise<void>>();
const HISTORY_ID = /^\d{10,16}_\d+$/;
const HISTORY_FILE = /^\d{10,16}_\d+\.json$/;

function safeId(value: string, pattern: RegExp): string {
  if (!pattern.test(value) || value.includes('..')) throw Object.assign(new Error('Invalid resource identifier.'), { statusCode: 400, code: 'INVALID_ID' });
  return value;
}

async function atomicWrite(filePath: string, content: string | Buffer): Promise<void> {
  const temporary = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  const handle = await open(temporary, 'wx', 0o600);
  try {
    await handle.writeFile(content, typeof content === 'string' ? 'utf8' : undefined);
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await rename(temporary, filePath);
  } catch (error) {
    await rm(temporary, { force: true });
    throw error;
  }
}

export class FamilyRepository {
  constructor(private readonly dataDir: string) {}

  private familyPath(tenantId: string, familyId: string): string {
    const safeTenant = safeId(tenantId, tenantPattern);
    const safeFamily = safeId(familyId, familyPattern);
    const root = path.resolve(this.dataDir);
    const resolved = path.resolve(root, 'tenants', safeTenant, 'families', safeFamily, 'family.json');
    if (!resolved.startsWith(`${root}${path.sep}`)) throw Object.assign(new Error('Invalid storage path.'), { statusCode: 400, code: 'INVALID_PATH' });
    return resolved;
  }

  async read(tenantId: string, familyId: string): Promise<Family> {
    const filePath = this.familyPath(tenantId, familyId);
    const root = await realpath(this.dataDir);
    const directory = await realpath(path.dirname(filePath));
    if (!directory.startsWith(`${root}${path.sep}`)) throw Object.assign(new Error('Storage path escapes DATA_DIR.'), { statusCode: 400, code: 'INVALID_PATH' });
    let raw: string;
    try { raw = await readFile(filePath, 'utf8'); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') throw Object.assign(new Error('Family not found.'), { statusCode: 404, code: 'NOT_FOUND' });
      throw error;
    }
    return FamilySchema.parse(JSON.parse(raw));
  }

  async write(tenantId: string, familyId: string, expectedVersion: number, mutate: (family: Family) => Family): Promise<Family> {
    const key = `${tenantId}/${familyId}`;
    const previous = locks.get(key) ?? Promise.resolve();
    let release!: () => void;
    const current = new Promise<void>((resolve) => { release = resolve; });
    const tail = previous.then(() => current);
    locks.set(key, tail);
    await previous;
    try {
      const currentFamily = await this.read(tenantId, familyId);
      if (currentFamily.meta.dataVersion !== expectedVersion) throw Object.assign(new Error('This family changed since you loaded it.'), { statusCode: 409, code: 'CONFLICT', details: { latestVersion: currentFamily.meta.dataVersion } });
      const updated = mutate(structuredClone(currentFamily));
      updated.meta.dataVersion = currentFamily.meta.dataVersion + 1;
      updated.meta.updatedAt = new Date().toISOString();
      const parsed = FamilySchema.parse(updated);
      const report = validateFamilyGraph(parsed);
      if (report.errors.length) throw Object.assign(new Error('The requested change violates family graph rules.'), { statusCode: 422, code: 'VALIDATION_FAILED', details: report });
      const filePath = this.familyPath(tenantId, familyId);
      const backupDir = path.join(this.dataDir, 'backups', tenantId, familyId, 'write');
      await mkdir(backupDir, { recursive: true });
      const backupPath = path.join(backupDir, `${Date.now()}_${currentFamily.meta.dataVersion}.json`);
      await atomicWrite(backupPath, JSON.stringify(currentFamily));
      await atomicWrite(filePath, JSON.stringify(parsed, null, 2));
      const backupFiles = (await readdir(backupDir)).filter((name) => name.endsWith('.json')).sort().reverse();
      for (const staleFile of backupFiles.slice(80)) await rm(path.join(backupDir, staleFile), { force: true });
      return parsed;
    } finally {
      release();
      if (locks.get(key) === tail) locks.delete(key);
    }
  }

  private historyDir(tenantId: string, familyId: string): string {
    this.familyPath(tenantId, familyId);
    return path.join(this.dataDir, 'backups', tenantId, familyId, 'write');
  }

  /** Earlier states of the family, newest first. Each is the copy kept just before a change was saved. */
  async listHistory(tenantId: string, familyId: string): Promise<{ id: string; savedAt: number; dataVersion: number; family: Family }[]> {
    const dir = this.historyDir(tenantId, familyId);
    let names: string[];
    try { names = await readdir(dir); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return [];
      throw error;
    }
    const entries: { id: string; savedAt: number; dataVersion: number; family: Family }[] = [];
    for (const name of names.filter((entry) => HISTORY_FILE.test(entry)).sort().reverse()) {
      try {
        const family = FamilySchema.parse(JSON.parse(await readFile(path.join(dir, name), 'utf8')));
        const [savedAt, dataVersion] = name.replace('.json', '').split('_').map(Number);
        entries.push({ id: name.replace('.json', ''), savedAt, dataVersion, family });
      } catch { /* skip unreadable copies */ }
    }
    return entries;
  }

  async readHistory(tenantId: string, familyId: string, id: string): Promise<Family | null> {
    if (!HISTORY_ID.test(id)) throw Object.assign(new Error('Invalid version identifier.'), { statusCode: 400, code: 'INVALID_ID' });
    try { return FamilySchema.parse(JSON.parse(await readFile(path.join(this.historyDir(tenantId, familyId), `${id}.json`), 'utf8'))); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return null;
      throw error;
    }
  }

  private mediaFile(tenantId: string, familyId: string, mediaId: string, size: 'thumb' | 'medium'): string {
    if (!MEDIA_ID.test(mediaId) || (size !== 'thumb' && size !== 'medium')) throw Object.assign(new Error('Invalid media identifier.'), { statusCode: 400, code: 'INVALID_ID' });
    return path.join(path.dirname(this.familyPath(tenantId, familyId)), 'media', mediaId, `${size}.jpg`);
  }

  async saveMedia(tenantId: string, familyId: string, mediaId: string, files: { medium: Buffer; thumb: Buffer }): Promise<void> {
    for (const size of ['medium', 'thumb'] as const) {
      const target = this.mediaFile(tenantId, familyId, mediaId, size);
      await mkdir(path.dirname(target), { recursive: true });
      await atomicWrite(target, files[size]);
    }
  }

  async readMedia(tenantId: string, familyId: string, mediaId: string, size: 'thumb' | 'medium'): Promise<Buffer | null> {
    try { return await readFile(this.mediaFile(tenantId, familyId, mediaId, size)); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return null;
      throw error;
    }
  }

  async ensureWritable(): Promise<void> {
    await mkdir(this.dataDir, { recursive: true });
    const info = await stat(this.dataDir);
    if (!info.isDirectory()) throw new Error('DATA_DIR must be a directory.');
    const probe = path.join(this.dataDir, `.write-check-${process.pid}`);
    await writeFile(probe, 'ok', { flag: 'wx' });
    await rm(probe);
  }
}