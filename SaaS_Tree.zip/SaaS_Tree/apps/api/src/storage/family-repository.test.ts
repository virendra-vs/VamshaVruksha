import { mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { FamilySchema } from '@vamsha/shared';
import { FamilyRepository } from './family-repository.js';

const scratchDirectories: string[] = [];

async function setup() {
  const dataDir = await mkdtemp(path.join(tmpdir(), 'vamsha-test-'));
  scratchDirectories.push(dataDir);
  const family = FamilySchema.parse(JSON.parse(await readFile(new URL('../../test-fixtures/family.json', import.meta.url), 'utf8')));
  const familyPath = path.join(dataDir, 'tenants', 't-shankaragulli', 'families', 'fam-shankaragulli', 'family.json');
  await mkdir(path.dirname(familyPath), { recursive: true });
  await writeFile(familyPath, JSON.stringify(family));
  return { dataDir, family, repository: new FamilyRepository(dataDir) };
}

afterEach(async () => {
  await Promise.all(scratchDirectories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

describe('FamilyRepository', () => {
  it('rejects a stale data version and preserves a write backup', async () => {
    const { family, repository, dataDir } = await setup();
    const updated = await repository.write(family.meta.tenantId, family.meta.id, 1, (current) => ({ ...current, notes: [{ id: 'N1' }] }));
    await expect(repository.write(family.meta.tenantId, family.meta.id, 1, (current) => current)).rejects.toMatchObject({ statusCode: 409, code: 'CONFLICT' });
    const backupDir = path.join(dataDir, 'backups', family.meta.tenantId, family.meta.id, 'write');
    const [backupFile] = await readdir(backupDir);
    const backup = JSON.parse(await readFile(path.join(backupDir, backupFile), 'utf8'));
    expect(updated.meta.dataVersion).toBe(2);
    expect(backup.meta.dataVersion).toBe(1);
  });

  it('keeps a restorable history, newest first, and rejects unsafe version ids', async () => {
    const { family, repository } = await setup();
    const t = family.meta.tenantId;
    const f = family.meta.id;
    await repository.write(t, f, 1, (current) => ({ ...current, notes: [{ id: 'N1' }] }));
    await repository.write(t, f, 2, (current) => ({ ...current, notes: [{ id: 'N1' }, { id: 'N2' }] }));
    const history = await repository.listHistory(t, f);
    expect(history.map((entry) => entry.dataVersion)).toEqual([2, 1]);
    expect(history[1].family.notes).toHaveLength(0);
    expect(await repository.readHistory(t, f, history[1].id)).not.toBeNull();
    await expect(repository.readHistory(t, f, '../../family')).rejects.toMatchObject({ statusCode: 400 });
  });

  it('serializes competing writes using optimistic concurrency', async () => {
    const { family, repository } = await setup();
    const outcomes = await Promise.allSettled([
      repository.write(family.meta.tenantId, family.meta.id, 1, (current) => ({ ...current, notes: [{ id: 'N1' }] })),
      repository.write(family.meta.tenantId, family.meta.id, 1, (current) => ({ ...current, notes: [{ id: 'N2' }] })),
    ]);
    expect(outcomes.filter((outcome) => outcome.status === 'fulfilled')).toHaveLength(1);
    expect(outcomes.filter((outcome) => outcome.status === 'rejected')).toHaveLength(1);
  });

  it('rejects unsafe tenant and family identifiers', async () => {
    const { repository } = await setup();
    await expect(repository.read('../outside', 'fam-shankaragulli')).rejects.toMatchObject({ statusCode: 400, code: 'INVALID_ID' });
  });
});