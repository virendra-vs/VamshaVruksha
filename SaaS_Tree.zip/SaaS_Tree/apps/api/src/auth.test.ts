import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { AdminAuth } from './auth.js';
import { MediaError, decodeJpeg } from './media.js';

const dirs: string[] = [];
async function make(password = 'correct horse battery') {
  const dir = await mkdtemp(path.join(tmpdir(), 'vamsha-auth-'));
  dirs.push(dir);
  const auth = new AdminAuth(dir);
  await auth.init(password);
  return { dir, auth };
}
afterEach(async () => { await Promise.all(dirs.splice(0).map((dir) => rm(dir, { recursive: true, force: true }))); });

describe('AdminAuth', () => {
  it('accepts the right password and rejects a wrong one', async () => {
    const { auth } = await make();
    expect(await auth.verify('correct horse battery')).toBe(true);
    expect(await auth.verify('nope nope nope')).toBe(false);
  });

  it('issues tokens that verify, and rejects tampered or empty ones', async () => {
    const { auth } = await make();
    const { token } = auth.issueToken();
    expect(auth.isValidToken(token)).toBe(true);
    expect(auth.isValidToken(`${token}x`)).toBe(false);
    expect(auth.isValidToken(undefined)).toBe(false);
    const [body] = token.split('.');
    expect(auth.isValidToken(`${body}.AAAA`)).toBe(false);
  });

  it('revokes sessions when the password changes and keeps the new password after restart', async () => {
    const { dir, auth } = await make();
    const { token } = auth.issueToken();
    await auth.changePassword('correct horse battery', 'a brand new passphrase');
    expect(auth.isValidToken(token)).toBe(false);
    const restarted = new AdminAuth(dir);
    await restarted.init('ignored-because-file-exists');
    expect(await restarted.verify('a brand new passphrase')).toBe(true);
  });

  it('locks out only the client that keeps failing', async () => {
    const { auth } = await make();
    for (let i = 0; i < 5; i += 1) await auth.verify('wrong wrong wrong', '10.0.0.1');
    await expect(auth.verify('correct horse battery', '10.0.0.1')).rejects.toMatchObject({ statusCode: 429 });
    expect(await auth.verify('correct horse battery', '10.0.0.2')).toBe(true);
  });

  it('rejects weak passwords', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'vamsha-auth-'));
    dirs.push(dir);
    await expect(new AdminAuth(dir).init('short')).rejects.toMatchObject({ code: 'WEAK_PASSWORD' });
  });
});

describe('decodeJpeg', () => {
  const jpeg = `data:image/jpeg;base64,${Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 1, 2]).toString('base64')}`;
  it('accepts a JPEG and rejects other content', () => {
    expect(decodeJpeg(jpeg, 1000).length).toBe(7);
    const fake = `data:image/jpeg;base64,${Buffer.from('<script>alert(1)</script>').toString('base64')}`;
    expect(() => decodeJpeg(fake, 1000)).toThrow(MediaError);
    expect(() => decodeJpeg('data:image/png;base64,AAAA', 1000)).toThrow(MediaError);
    expect(() => decodeJpeg(jpeg, 3)).toThrow(/too large/);
  });
});
