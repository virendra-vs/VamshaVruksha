import { createHmac, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

const SCRYPT = { N: 16384, r: 8, p: 1 } as const;
const SESSION_MS = 8 * 60 * 60 * 1000;
const MAX_FAILURES = 5;
const LOCK_MS = 15 * 60 * 1000;

interface AdminFile { schemaVersion: '1.0.0'; salt: string; hash: string; sessionSecret: string }

const derive = (password: string, salt: Buffer) => new Promise<Buffer>((resolve, reject) => {
  scrypt(password, salt, 32, SCRYPT, (error, key) => (error ? reject(error) : resolve(key)));
});

const sign = (payload: string, secret: string) => createHmac('sha256', secret).update(payload).digest('base64url');

export class AuthError extends Error {
  constructor(public readonly statusCode: number, public readonly code: string, message: string) { super(message); }
}

export class AdminAuth {
  private file!: AdminFile;
  private attempts = new Map<string, { failures: number; lockedUntil: number }>();
  private readonly filePath: string;

  constructor(dataDir: string, private readonly envSecret?: string, private readonly minLength = 10) {
    this.filePath = path.join(dataDir, 'platform', 'admin.json');
  }

  /** Returns a generated password only when none was supplied and no admin exists yet. */
  async init(initialPassword?: string): Promise<{ generated?: string }> {
    try {
      this.file = JSON.parse(await readFile(this.filePath, 'utf8')) as AdminFile;
      return {};
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
    }
    const generated = initialPassword ? undefined : randomBytes(9).toString('base64url');
    await this.save(initialPassword ?? generated!);
    return generated ? { generated } : {};
  }

  private async save(password: string, keepSecret = true) {
    if (password.length < this.minLength) throw new AuthError(400, 'WEAK_PASSWORD', `Use at least ${this.minLength} characters for the admin password.`);
    const salt = randomBytes(16);
    const hash = await derive(password, salt);
    this.file = {
      schemaVersion: '1.0.0', salt: salt.toString('base64'), hash: hash.toString('base64'),
      sessionSecret: keepSecret && this.file ? this.file.sessionSecret : randomBytes(32).toString('hex'),
    };
    await mkdir(path.dirname(this.filePath), { recursive: true });
    const temporary = `${this.filePath}.${process.pid}.tmp`;
    await writeFile(temporary, JSON.stringify(this.file), { mode: 0o600 });
    await rename(temporary, this.filePath);
  }

  private get secret() { return `${this.envSecret ?? ''}${this.file.sessionSecret}`; }

  async verify(password: string, client = 'local'): Promise<boolean> {
    const state = this.attempts.get(client) ?? { failures: 0, lockedUntil: 0 };
    if (Date.now() < state.lockedUntil) throw new AuthError(429, 'LOCKED', 'Too many attempts. Try again in a few minutes.');
    const expected = Buffer.from(this.file.hash, 'base64');
    const actual = await derive(password, Buffer.from(this.file.salt, 'base64'));
    const ok = actual.length === expected.length && timingSafeEqual(actual, expected);
    if (ok) { this.attempts.delete(client); return true; }
    state.failures += 1;
    if (state.failures >= MAX_FAILURES) { state.lockedUntil = Date.now() + LOCK_MS; state.failures = 0; }
    this.attempts.set(client, state);
    if (this.attempts.size > 5000) this.attempts.clear();
    return false;
  }

  async changePassword(current: string, next: string, client = 'local') {
    if (!(await this.verify(current, client))) throw new AuthError(403, 'BAD_PASSWORD', 'The current password is not correct.');
    await this.save(next, true);
  }

  issueToken(): { token: string; maxAgeSeconds: number } {
    const body = Buffer.from(JSON.stringify({ exp: Date.now() + SESSION_MS, pv: this.file.hash.slice(0, 8) })).toString('base64url');
    return { token: `${body}.${sign(body, this.secret)}`, maxAgeSeconds: SESSION_MS / 1000 };
  }

  isValidToken(token: string | undefined): boolean {
    if (!token) return false;
    const [body, signature] = token.split('.');
    if (!body || !signature) return false;
    const expected = Buffer.from(sign(body, this.secret));
    const given = Buffer.from(signature);
    if (expected.length !== given.length || !timingSafeEqual(expected, given)) return false;
    try {
      const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as { exp: number; pv: string };
      return payload.exp > Date.now() && payload.pv === this.file.hash.slice(0, 8);
    } catch { return false; }
  }
}
