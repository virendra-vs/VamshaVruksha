export const MEDIA_ID = /^m_[a-f0-9]{16}$/;

export class MediaError extends Error {
  constructor(public readonly statusCode: number, public readonly code: string, message: string) { super(message); }
}

/** Accepts only a JPEG data URL (the browser re-encodes photos, which also strips EXIF). */
export function decodeJpeg(dataUrl: unknown, maxBytes: number): Buffer {
  const match = typeof dataUrl === 'string' ? /^data:image\/jpeg;base64,([A-Za-z0-9+/]+={0,2})$/.exec(dataUrl) : null;
  if (!match) throw new MediaError(400, 'INVALID_IMAGE', 'Photos must be JPEG images.');
  const buffer = Buffer.from(match[1], 'base64');
  if (buffer.length > maxBytes) throw new MediaError(413, 'IMAGE_TOO_LARGE', 'That photo is too large.');
  if (!(buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff)) throw new MediaError(400, 'INVALID_IMAGE', 'That file is not a valid JPEG.');
  return buffer;
}

export const toDataUrl = (buffer: Buffer) => `data:image/jpeg;base64,${buffer.toString('base64')}`;
export const MEDIUM_MAX = 2 * 1024 * 1024;
export const THUMB_MAX = 220 * 1024;
