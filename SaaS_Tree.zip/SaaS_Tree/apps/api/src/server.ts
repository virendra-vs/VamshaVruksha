import 'dotenv/config';
import Fastify, { type FastifyRequest } from 'fastify';
import helmet from '@fastify/helmet';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import fastifyStatic from '@fastify/static';
import { randomBytes } from 'node:crypto';
import { z } from 'zod';
import { access, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  CommandError, CommandSchema, FamilySchema, GraphSchema, MEDIA_EVENT_TYPES, applyCommand, isValidPartialDate, redactForViewer, validateFamilyGraph, type Family,
} from '@vamsha/shared';
import { FamilyRepository } from './storage/family-repository.js';
import { AdminAuth, AuthError } from './auth.js';
import { MEDIA_ID, MEDIUM_MAX, MediaError, THUMB_MAX, decodeJpeg, toDataUrl } from './media.js';

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const isProduction = process.env.NODE_ENV === 'production';
if (isProduction && !process.env.JWT_SECRET) throw new Error('JWT_SECRET is required in production. Set it in App Service application settings.');
const dataDir = path.resolve(process.env.DATA_DIR ?? path.resolve(process.cwd(), 'data'));
if (isProduction && (dataDir === process.cwd() || dataDir.startsWith(`${process.cwd()}${path.sep}`))) {
  throw new Error('In production, DATA_DIR must be outside the application folder. Use /home/data.');
}
const repository = new FamilyRepository(dataDir);
const app = Fastify({ logger: true, trustProxy: true, bodyLimit: 3 * 1024 * 1024 });

await repository.ensureWritable();

const auth = new AdminAuth(dataDir, process.env.JWT_SECRET, isProduction ? 10 : 3);
const adminInit = await auth.init(process.env.ADMIN_PASSWORD);
if (adminInit.generated) {
  if (isProduction) throw new Error('Set ADMIN_PASSWORD (at least 10 characters) in application settings before the first production start.');
  app.log.warn(`No ADMIN_PASSWORD set. Generated a one-time admin password for local use: ${adminInit.generated}`);
}

const seedEnabled = !isProduction || process.env.SEED_ON_EMPTY === 'true';
const seedPath = path.join(dataDir, 'tenants', 't-shankaragulli', 'families', 'fam-shankaragulli', 'family.json');
if (seedEnabled) {
  const familyDir = path.dirname(seedPath);
  let familyFolderExists = true;
  try { await access(familyDir); }
  catch { familyFolderExists = false; }
  if (!familyFolderExists) {
    const seedCandidates = [path.resolve(currentDir, 'seed/family.json'), path.resolve(currentDir, '../src/seed/family.json')];
    const seedFile = (await Promise.all(seedCandidates.map(async (candidate) => {
      try { await access(candidate); return candidate; } catch { return undefined; }
    }))).find((candidate) => candidate !== undefined);
    if (!seedFile) throw new Error('Demo seed file is missing from this build.');
    const seed = await readFile(seedFile, 'utf8');
    const empty = (await readdir(dataDir)).filter((name) => name !== 'platform').length === 0;
    if (!isProduction || empty) {
      await mkdir(familyDir, { recursive: true });
      await writeFile(seedPath, seed, { flag: 'wx' });
      const seedMedia = path.join(path.dirname(seedFile), 'media');
      for (const mediaId of await readdir(seedMedia).catch(() => [])) {
        await repository.saveMedia('t-shankaragulli', 'fam-shankaragulli', mediaId, {
          medium: await readFile(path.join(seedMedia, mediaId, 'medium.jpg')),
          thumb: await readFile(path.join(seedMedia, mediaId, 'thumb.jpg')),
        });
      }
      app.log.info('Created the non-destructive Shankaragulli demo family seed.');
    }
  }
}

await app.register(helmet, { contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], imgSrc: ["'self'", 'data:', 'blob:'], styleSrc: ["'self'", "'unsafe-inline'"], scriptSrc: ["'self'"], connectSrc: ["'self'"] } } });
await app.register(rateLimit, { max: 240, timeWindow: '1 minute' });
await app.register(cookie);

app.setErrorHandler((error, _request, reply) => {
  const serverError = error as Error & { statusCode?: number; code?: string; details?: unknown };
  const statusCode = serverError.statusCode && serverError.statusCode >= 400 ? serverError.statusCode : 500;
  if (statusCode >= 500) app.log.error(error);
  reply.status(statusCode).send({ code: serverError.code ?? 'INTERNAL_ERROR', message: statusCode >= 500 ? 'An unexpected error occurred.' : serverError.message, ...(serverError.details ? { details: serverError.details } : {}) });
});

const COOKIE = 'vamsha_admin';
const isAdmin = (request: FastifyRequest) => auth.isValidToken(request.cookies[COOKIE]);

/** Every change needs an admin session plus the custom header (CSRF defence on top of SameSite=Strict). */
function requireAdmin(request: FastifyRequest) {
  if (!isAdmin(request)) throw new AuthError(401, 'ADMIN_REQUIRED', 'Sign in as admin to make changes.');
  if (request.headers['x-vamsha-csrf'] !== '1') throw new AuthError(403, 'CSRF', 'Missing request header.');
}

app.get('/health', async () => ({ status: 'ok' }));
app.get('/ready', async (_request, reply) => {
  try { await repository.ensureWritable(); return { status: 'ready' }; }
  catch { return reply.status(503).send({ status: 'not-ready' }); }
});

// ---------- Admin session ----------
app.get('/api/v1/auth/session', async (request, reply) => reply.header('Cache-Control', 'no-store').send({ admin: isAdmin(request) }));

app.post('/api/v1/auth/login', { config: { rateLimit: { max: 10, timeWindow: '15 minutes' } } }, async (request, reply) => {
  const body = z.object({ password: z.string().min(1).max(200) }).safeParse(request.body);
  if (!body.success) return reply.status(400).send({ code: 'INVALID_REQUEST', message: 'Enter the admin password.' });
  if (!(await auth.verify(body.data.password, request.ip))) return reply.status(401).send({ code: 'BAD_PASSWORD', message: 'That password is not correct.' });
  const { token, maxAgeSeconds } = auth.issueToken();
  reply.setCookie(COOKIE, token, { httpOnly: true, sameSite: 'strict', secure: isProduction, path: '/', maxAge: maxAgeSeconds });
  return { admin: true };
});

app.post('/api/v1/auth/logout', async (_request, reply) => {
  reply.clearCookie(COOKIE, { path: '/' });
  return { admin: false };
});

app.post('/api/v1/auth/change-password', async (request) => {
  requireAdmin(request);
  const body = z.object({ current: z.string().min(1).max(200), next: z.string().min(1).max(200) }).parse(request.body);
  await auth.changePassword(body.current, body.next, request.ip);
  return { ok: true };
});

// ---------- Family ----------
type FamilyParams = { Params: { tenantId: string; familyId: string }; Body: unknown };
const familyUrl = '/api/v1/tenants/:tenantId/families/:familyId';
const expectedVersionOf = (header: string | string[] | undefined): number => {
  const version = Number(String(header ?? '').replaceAll('"', ''));
  if (!Number.isInteger(version)) throw Object.assign(new Error('Send the current family version in If-Match.'), { statusCode: 428, code: 'VERSION_REQUIRED' });
  return version;
};

app.get<FamilyParams>(familyUrl, async (request, reply) => {
  const admin = isAdmin(request);
  const family = await repository.read(request.params.tenantId, request.params.familyId);
  const etag = `"${family.meta.dataVersion}-${admin ? 'a' : 'v'}"`;
  reply.header('ETag', etag).header('Cache-Control', 'private, no-cache').header('Vary', 'Cookie');
  if (request.headers['if-none-match'] === etag) return reply.status(304).send();
  return admin ? family : redactForViewer(family);
});

app.post<FamilyParams>(`${familyUrl}/commands`, async (request, reply) => {
  requireAdmin(request);
  const expectedVersion = expectedVersionOf(request.headers['if-match']);
  const parsed = z.object({ command: CommandSchema }).safeParse(request.body);
  if (!parsed.success) return reply.status(400).send({ code: 'INVALID_COMMAND', message: parsed.error.issues[0]?.message ?? 'The change is invalid.', details: parsed.error.flatten() });
  let focusId: string | undefined;
  const family = await repository.write(request.params.tenantId, request.params.familyId, expectedVersion, (current) => {
    try {
      const result = applyCommand(current, parsed.data.command);
      focusId = result.focusId;
      return result.family;
    } catch (error) {
      if (error instanceof CommandError) throw Object.assign(new Error(error.message), { statusCode: 422, code: error.code });
      throw error;
    }
  });
  return reply.header('ETag', `"${family.meta.dataVersion}-a"`).send({ family, focusId });
});

// Undo/redo: swaps people and unions for an earlier snapshot, still validated.
app.put<FamilyParams>(`${familyUrl}/graph`, async (request, reply) => {
  requireAdmin(request);
  const expectedVersion = expectedVersionOf(request.headers['if-match']);
  const parsed = GraphSchema.safeParse(request.body);
  if (!parsed.success) return reply.status(400).send({ code: 'INVALID_GRAPH', message: 'The snapshot is invalid.', details: parsed.error.flatten() });
  const family = await repository.write(request.params.tenantId, request.params.familyId, expectedVersion, (current) => ({ ...current, ...parsed.data }));
  return reply.header('ETag', `"${family.meta.dataVersion}-a"`).send({ family });
});

app.get<FamilyParams>(`${familyUrl}/validate`, async (request) => {
  const family = FamilySchema.parse(await repository.read(request.params.tenantId, request.params.familyId));
  return validateFamilyGraph(family);
});

// ---------- Photos ----------
type PersonParams = { Params: { tenantId: string; familyId: string; personId: string }; Body: unknown };

app.put<PersonParams>(`${familyUrl}/people/:personId/photo`, { bodyLimit: 3 * 1024 * 1024 }, async (request, reply) => {
  requireAdmin(request);
  const expectedVersion = expectedVersionOf(request.headers['if-match']);
  const body = (request.body ?? {}) as { medium?: unknown; thumb?: unknown };
  let files: { medium: Buffer; thumb: Buffer };
  try { files = { medium: decodeJpeg(body.medium, MEDIUM_MAX), thumb: decodeJpeg(body.thumb, THUMB_MAX) }; }
  catch (error) {
    if (error instanceof MediaError) throw Object.assign(new Error(error.message), { statusCode: error.statusCode, code: error.code });
    throw error;
  }
  const { tenantId, familyId, personId } = request.params;
  const mediaId = `m_${randomBytes(8).toString('hex')}`;
  await repository.saveMedia(tenantId, familyId, mediaId, files);
  const family = await repository.write(tenantId, familyId, expectedVersion, (current) => {
    const person = current.people.find((entry) => entry.id === personId);
    if (!person) throw Object.assign(new Error('That person no longer exists.'), { statusCode: 404, code: 'NOT_FOUND' });
    person.profile = { ...(person.profile ?? {}), photoMediaId: mediaId };
    return current;
  });
  return reply.header('ETag', `"${family.meta.dataVersion}-a"`).send({ family });
});

app.delete<PersonParams>(`${familyUrl}/people/:personId/photo`, async (request, reply) => {
  requireAdmin(request);
  const expectedVersion = expectedVersionOf(request.headers['if-match']);
  const { tenantId, familyId, personId } = request.params;
  const family = await repository.write(tenantId, familyId, expectedVersion, (current) => {
    const person = current.people.find((entry) => entry.id === personId);
    if (!person) throw Object.assign(new Error('That person no longer exists.'), { statusCode: 404, code: 'NOT_FOUND' });
    person.profile = { ...(person.profile ?? {}), photoMediaId: null };
    return current;
  });
  return reply.header('ETag', `"${family.meta.dataVersion}-a"`).send({ family });
});

// ---------- Gallery ----------
const GalleryUploadSchema = z.object({
  medium: z.string(),
  thumb: z.string(),
  width: z.number().int().positive().max(12000),
  height: z.number().int().positive().max(12000),
  caption: z.string().trim().max(300).nullish(),
  eventType: z.enum(MEDIA_EVENT_TYPES).default('other'),
  date: z.string().refine(isValidPartialDate, 'Use a valid date.').nullish(),
  personIds: z.array(z.string()).min(1).max(60),
});

app.post<FamilyParams>(`${familyUrl}/gallery`, { bodyLimit: 6 * 1024 * 1024 }, async (request, reply) => {
  requireAdmin(request);
  const expectedVersion = expectedVersionOf(request.headers['if-match']);
  const parsed = GalleryUploadSchema.safeParse(request.body);
  if (!parsed.success) return reply.status(400).send({ code: 'INVALID_PHOTO', message: parsed.error.issues[0]?.message ?? 'The photo details are invalid.' });
  let files: { medium: Buffer; thumb: Buffer };
  try { files = { medium: decodeJpeg(parsed.data.medium, MEDIUM_MAX), thumb: decodeJpeg(parsed.data.thumb, THUMB_MAX) }; }
  catch (error) {
    if (error instanceof MediaError) throw Object.assign(new Error(error.message), { statusCode: error.statusCode, code: error.code });
    throw error;
  }
  const { tenantId, familyId } = request.params;
  const mediaId = `m_${randomBytes(8).toString('hex')}`;
  await repository.saveMedia(tenantId, familyId, mediaId, files);
  const family = await repository.write(tenantId, familyId, expectedVersion, (current) => {
    const known = new Set(current.people.map((person) => person.id));
    if (!parsed.data.personIds.every((id) => known.has(id))) throw Object.assign(new Error('One of the tagged people no longer exists.'), { statusCode: 422, code: 'NOT_FOUND' });
    const date = parsed.data.date;
    current.media.push({
      id: mediaId, kind: 'photo', caption: parsed.data.caption || null, eventType: parsed.data.eventType,
      date: date ? { value: date, precision: date.length === 4 ? 'year' : date.length === 7 ? 'month' : 'exact' } : null,
      personIds: [...new Set(parsed.data.personIds)], width: parsed.data.width, height: parsed.data.height,
      sizeBytes: files.medium.length, uploadedAt: new Date().toISOString(),
    });
    return current;
  });
  return reply.header('ETag', `"${family.meta.dataVersion}-a"`).send({ family, mediaId });
});

app.get<{ Params: { tenantId: string; familyId: string; mediaId: string; size: string } }>(`${familyUrl}/media/:mediaId/:size`, async (request, reply) => {
  const { tenantId, familyId, mediaId, size } = request.params;
  if (!MEDIA_ID.test(mediaId) || (size !== 'thumb' && size !== 'medium')) return reply.status(404).send({ code: 'NOT_FOUND', message: 'Photo not found.' });
  const file = await repository.readMedia(tenantId, familyId, mediaId, size);
  if (!file) return reply.status(404).send({ code: 'NOT_FOUND', message: 'Photo not found.' });
  return reply.type('image/jpeg').header('Cache-Control', 'public, max-age=31536000, immutable').header('X-Content-Type-Options', 'nosniff').send(file);
});

// ---------- Backup export / import ----------
app.get<{ Params: { tenantId: string; familyId: string } }>(`${familyUrl}/export`, async (request, reply) => {
  requireAdmin(request);
  const { tenantId, familyId } = request.params;
  const family = await repository.read(tenantId, familyId);
  const photos: Record<string, { medium: string; thumb: string }> = {};
  const mediaIds = new Set<string>([
    ...family.people.map((person) => person.profile?.photoMediaId).filter((id): id is string => !!id),
    ...family.media.map((item) => item.id),
  ]);
  for (const id of mediaIds) {
    if (photos[id]) continue;
    const [medium, thumb] = await Promise.all([repository.readMedia(tenantId, familyId, id, 'medium'), repository.readMedia(tenantId, familyId, id, 'thumb')]);
    if (medium && thumb) photos[id] = { medium: toDataUrl(medium), thumb: toDataUrl(thumb) };
  }
  return reply.header('Cache-Control', 'no-store').send({ format: 'vamsha-backup', formatVersion: 1, exportedAt: new Date().toISOString(), family, photos });
});

const ImportSchema = z.object({
  family: z.unknown(),
  photos: z.record(z.object({ medium: z.string(), thumb: z.string() })).optional(),
});

app.post<FamilyParams>(`${familyUrl}/import`, { bodyLimit: 100 * 1024 * 1024 }, async (request, reply) => {
  requireAdmin(request);
  const expectedVersion = expectedVersionOf(request.headers['if-match']);
  const body = ImportSchema.safeParse(request.body);
  const incoming = body.success ? FamilySchema.safeParse(body.data.family) : null;
  if (!body.success || !incoming?.success) return reply.status(400).send({ code: 'INVALID_BACKUP', message: 'This file is not a valid Vamsha backup.' });
  const report = validateFamilyGraph(incoming.data);
  if (report.errors.length) return reply.status(422).send({ code: 'VALIDATION_FAILED', message: report.errors[0].message, details: report });
  const { tenantId, familyId } = request.params;
  const wanted = new Set([
    ...incoming.data.people.map((person) => person.profile?.photoMediaId).filter((id): id is string => !!id),
    ...incoming.data.media.map((item) => item.id),
  ]);
  for (const [id, files] of Object.entries(body.data.photos ?? {})) {
    if (!MEDIA_ID.test(id) || !wanted.has(id)) continue;
    try { await repository.saveMedia(tenantId, familyId, id, { medium: decodeJpeg(files.medium, MEDIUM_MAX), thumb: decodeJpeg(files.thumb, THUMB_MAX) }); }
    catch (error) {
      if (error instanceof MediaError) throw Object.assign(new Error(error.message), { statusCode: error.statusCode, code: error.code });
      throw error;
    }
  }
  // The repository keeps a pre-import copy of the current family among its rolling write backups.
  const family = await repository.write(tenantId, familyId, expectedVersion, (current): Family => ({
    ...incoming.data,
    meta: { ...incoming.data.meta, id: current.meta.id, tenantId: current.meta.tenantId, rootPersonId: incoming.data.people.some((p) => p.id === incoming.data.meta.rootPersonId) ? incoming.data.meta.rootPersonId : current.meta.rootPersonId },
  }));
  return reply.header('ETag', `"${family.meta.dataVersion}-a"`).send({ family });
});

// ---------- Version history ----------
const nameList = (names: string[]) => (names.length > 6 ? [...names.slice(0, 6), `and ${names.length - 6} more`] : names);

app.get<{ Params: { tenantId: string; familyId: string } }>(`${familyUrl}/history`, async (request, reply) => {
  requireAdmin(request);
  const { tenantId, familyId } = request.params;
  const current = await repository.read(tenantId, familyId);
  const currentIds = new Set(current.people.map((person) => person.id));
  const entries = (await repository.listHistory(tenantId, familyId)).map(({ id, savedAt, dataVersion, family }) => {
    const ids = new Set(family.people.map((person) => person.id));
    const label = (person: { name: { given: string; surname?: string | null } }) => [person.name.given, person.name.surname].filter(Boolean).join(' ');
    return {
      id, savedAt, dataVersion, people: family.people.length, unions: family.unions.length, photos: family.media.length,
      missingNow: nameList(family.people.filter((person) => !currentIds.has(person.id)).map(label)),
      addedSince: nameList(current.people.filter((person) => !ids.has(person.id)).map(label)),
    };
  });
  return reply.header('Cache-Control', 'no-store').send({ currentVersion: current.meta.dataVersion, entries });
});

app.post<FamilyParams & { Params: { tenantId: string; familyId: string; versionId: string } }>(`${familyUrl}/history/:versionId/restore`, async (request, reply) => {
  requireAdmin(request);
  const expectedVersion = expectedVersionOf(request.headers['if-match']);
  const { tenantId, familyId, versionId } = request.params;
  const earlier = await repository.readHistory(tenantId, familyId, versionId);
  if (!earlier) return reply.status(404).send({ code: 'NOT_FOUND', message: 'That version is no longer available.' });
  // The state being replaced is itself kept as a new history entry, so a restore can be undone.
  const family = await repository.write(tenantId, familyId, expectedVersion, (current) => ({ ...current, people: earlier.people, unions: earlier.unions, media: earlier.media }));
  return reply.header('ETag', `"${family.meta.dataVersion}-a"`).send({ family });
});

const publicDir = path.resolve(currentDir, '../../web/dist');
try {
  await app.register(fastifyStatic, { root: publicDir, prefix: '/', wildcard: false, decorateReply: true, index: false });
  app.get('/*', async (request, reply) => {
    if (request.url.startsWith('/api/')) return reply.status(404).send({ code: 'NOT_FOUND', message: 'API route not found.' });
    return reply.type('text/html').send(await readFile(path.join(publicDir, 'index.html')));
  });
} catch (error) {
  app.log.info({ error }, 'Web build not found; run the Vite dev server separately.');
}

const port = Number(process.env.PORT ?? 3000);
const host = process.env.HOST ?? (isProduction ? '0.0.0.0' : '127.0.0.1');
await mkdir(dataDir, { recursive: true });
await app.listen({ port, host });
await writeFile(path.join(dataDir, '.vamsha-data-dir'), 'Vamsha persistent data directory\n', { flag: 'a' });
