import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Camera, Flower2, Gem, Heart, HeartCrack, Pencil, Plus, Trash2, X } from 'lucide-react';
import {
  ancestorIds, birthRankIn, birthSurnameOf, descendantIds, getRelatives, isValidPartialDate, orderedChildren,
  type ChildRelation, type Command, type FamilyUnion, type Person,
} from '@vamsha/shared';
import { useFamily, useUi } from './store';
import { ageText, birthLabel, birthNameNoteL, dateText, displayNameL, fullNameL, givenL, knownAsL, num, ordinalL, t, useLang, useT } from './i18n';
import { isLate, isPlaceholder, lifeSpan } from './theme';
import { Avatar } from './Avatar';
import { GenderMark } from './GenderMark';
import { preparePhoto } from './photo';
import { DateField, Field } from './Fields';
import { ChildOrder } from './ChildOrder';
import { GalleryTab } from './Gallery';
import { LinkExisting } from './LinkExisting';

type AddKind = 'spouse' | 'child' | 'parent' | 'sibling';
type Mode = { kind: 'view' } | { kind: 'edit' } | { kind: 'add'; relation: AddKind } | { kind: 'remove' } | { kind: 'merge' };
type Tab = 'family' | 'about' | 'story' | 'photos';

const UNION_STATUSES: FamilyUnion['status'][] = ['active', 'widowed', 'divorced', 'separated', 'annulled'];
const STATUS_LABEL: Record<FamilyUnion['status'], string> = { active: 'Married', widowed: 'Widowed', divorced: 'Divorced', separated: 'Separated', annulled: 'Annulled' };
const RELATIONS: ChildRelation[] = ['biological', 'adopted', 'step', 'foster', 'guardian'];
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const cap = (value: string) => value[0].toUpperCase() + value.slice(1);
const clean = (value: string) => value.trim() || null;

interface Values {
  given: string; surname: string; birthSurname: string; nickname: string; aliases: string; localName: string;
  gender: Person['gender']; isLiving: boolean;
  birthDate: string; birthPlace: string; deathDate: string; deathPlace: string; currentPlace: string;
  village: string; gotra: string; bloodGroup: string; occupation: string; education: string;
  phone: string; email: string; address: string; bio: string;
}

function valuesOf(person: Person): Values {
  const custom = (key: string) => (typeof person.custom?.[key] === 'string' ? (person.custom[key] as string) : '');
  return {
    given: isPlaceholder(person) ? '' : person.name.given, surname: person.name.surname ?? '', nickname: person.name.nickname ?? '',
    birthSurname: person.name.birthSurname ?? '', aliases: (person.name.aliases ?? []).join(', '), localName: person.name.localScript?.kn ?? '',
    gender: person.gender, isLiving: person.isLiving,
    birthDate: person.vitals?.birth?.date?.value ?? '', birthPlace: person.vitals?.birth?.place?.text ?? '',
    deathDate: person.vitals?.death?.date?.value ?? '', deathPlace: person.vitals?.death?.place?.text ?? '',
    currentPlace: person.profile?.currentPlace ?? '', village: custom('village'), gotra: custom('gotra'), bloodGroup: custom('bloodGroup'),
    occupation: person.profile?.occupation ?? '', education: person.profile?.education ?? '',
    phone: person.profile?.contacts?.phone ?? '', email: person.profile?.contacts?.email ?? '', address: person.profile?.contacts?.address ?? '',
    bio: person.profile?.bio ?? '',
  };
}

function Fold({ title, open, children }: { title: string; open?: boolean; children: ReactNode }) {
  return <details className="fold" open={open}><summary>{title}</summary><div className="fold-body">{children}</div></details>;
}

function GenderPicker({ value, onChange }: { value: Person['gender']; onChange: (value: Person['gender']) => void }) {
  useT();
  return (
    <div className="seg" role="radiogroup" aria-label={t('Gender')}>
      {([['M', 'Male'], ['F', 'Female'], ['O', 'Other']] as const).map(([v, label]) => (
        <button type="button" key={v} role="radio" aria-checked={value === v} className={value === v ? 'on' : ''} onClick={() => onChange(v)}>{t(label)}</button>
      ))}
    </div>
  );
}

export type QuickValues = { given: string; surname: string; birthSurname: string; gender: Person['gender']; birthYear: string; takesName: boolean };

export function QuickAdd({ initial, submitLabel, onSubmit, onCancel, extra, spouseOf }: {
  initial: { given: string; surname: string; gender: Person['gender'] }; submitLabel: string;
  onSubmit: (v: QuickValues) => void; onCancel: () => void; extra?: ReactNode; spouseOf?: Person;
}) {
  const t = useT();
  const [v, setV] = useState<QuickValues>({ ...initial, birthSurname: '', birthYear: '', takesName: true });
  return (
    <form className="form" onSubmit={(e: FormEvent) => { e.preventDefault(); if (v.given.trim()) onSubmit(v); }}>
      <Field label={t('First name')}><input autoFocus required maxLength={80} value={v.given} onChange={(e) => setV({ ...v, given: e.target.value })} /></Field>
      <Field label={spouseOf && v.gender === 'F' ? t('Surname now') : t('Surname')}><input maxLength={80} value={v.surname} onChange={(e) => setV({ ...v, surname: e.target.value })} /></Field>
      <GenderPicker value={v.gender} onChange={(gender) => setV({ ...v, gender })} />
      {spouseOf && v.gender === 'F' && (
        <Field label={t('Maiden (birth) surname')}><input maxLength={80} placeholder={t('If different from her surname now')} value={v.birthSurname} onChange={(e) => setV({ ...v, birthSurname: e.target.value })} /></Field>
      )}
      {spouseOf?.gender === 'F' && v.gender === 'M' && v.surname.trim() && (
        <label className="check"><input type="checkbox" checked={v.takesName} onChange={(e) => setV({ ...v, takesName: e.target.checked })} />{t('{name} takes the surname “{surname}”', { name: givenL(spouseOf), surname: v.surname.trim() })}</label>
      )}
      <Field label={t('Birth year (optional)')}><input inputMode="numeric" placeholder={t('e.g. 1990')} value={v.birthYear} onChange={(e) => setV({ ...v, birthYear: e.target.value.replace(/\D/g, '').slice(0, 4) })} /></Field>
      {extra}
      <div className="form-actions"><button type="button" className="btn ghost" onClick={onCancel}>{t('Cancel')}</button><button type="submit" className="btn gold">{submitLabel}</button></div>
    </form>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return <div className="kv"><dt>{label}</dt><dd>{children}</dd></div>;
}

export function Chip({ person, note, icon }: { person: Person; note?: string; icon?: ReactNode }) {
  useT();
  return (
    <button className="chip" onClick={() => useUi.getState().select(person.id, true)}>
      <Avatar person={person} size="sm" />
      <span className="chip-name">{isPlaceholder(person) ? t('Unknown') : displayNameL(person)}</span>
      {note && <em>{note}</em>}
      {icon}
    </button>
  );
}

export function PersonPanel() {
  const t = useT();
  const lang = useLang((s) => s.lang);
  const selectedId = useUi((s) => s.selectedId);
  const family = useFamily((s) => s.family);
  const admin = useFamily((s) => s.admin);
  const busy = useFamily((s) => s.busy);
  const run = useFamily((s) => s.run);
  const setPhoto = useFamily((s) => s.setPhoto);
  const notify = useFamily((s) => s.notify);
  const [mode, setMode] = useState<Mode>({ kind: 'view' });
  const [tab, setTab] = useState<Tab>('family');
  const [unionId, setUnionId] = useState('');
  const [relation, setRelation] = useState<ChildRelation>('biological');
  const [previousStatus, setPreviousStatus] = useState<FamilyUnion['status']>('active');
  const [addSource, setAddSource] = useState<'new' | 'existing'>('new');
  const [spouseSlot, setSpouseSlot] = useState('new');
  const [position, setPosition] = useState('');
  const [confirmUnlink, setConfirmUnlink] = useState('');
  const [draft, setDraft] = useState<Values | null>(null);
  const [unionDraft, setUnionDraft] = useState<Record<string, { status: FamilyUnion['status']; startDate: string; place: string }>>({});
  const [parentRelation, setParentRelation] = useState<ChildRelation>('biological');
  const [formError, setFormError] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => { setMode({ kind: 'view' }); setTab('family'); setUnionId(''); setRelation('biological'); setPreviousStatus('active'); setFormError(''); }, [selectedId]);
  useEffect(() => { if (!admin) setMode({ kind: 'view' }); }, [admin]);

  const person = useMemo(() => family?.people.find((entry) => entry.id === selectedId), [family, selectedId]);
  const rel = useMemo(() => (family && person ? getRelatives(family, person.id) : null), [family, person]);
  if (!family || !person || !rel) return null;

  const placeholder = isPlaceholder(person);
  const late = isLate(person);
  const span = lifeSpan(person);
  const age = ageText(person);
  const nameOf = (entry: Person | null) => (entry ? (isPlaceholder(entry) ? t('Unknown') : givenL(entry)) : t('Unknown'));
  const custom = (key: string) => (typeof person.custom?.[key] === 'string' ? (person.custom[key] as string) : '');
  const born = dateText(person.vitals?.birth?.date?.value);
  const died = dateText(person.vitals?.death?.date?.value);
  const birthNote = birthNameNoteL(person);
  const known = knownAsL(person);
  const kannada = lang === 'en' ? person.name.localScript?.kn : undefined;
  const photoCount = family.media.filter((m) => m.personIds.includes(person.id)).length;
  const rankInfo = rel.parentUnion ? birthRankIn(rel.parentUnion, person.id) : null;
  const rankText = birthLabel(rankInfo) && rankInfo ? t('{label} of {n}', { label: birthLabel(rankInfo)!, n: rankInfo.of }) : null;
  const tabs: Tab[] = photoCount > 0 || admin ? ['family', 'about', 'story', 'photos'] : ['family', 'about', 'story'];
  const fatherSurname = person.gender !== 'F'
    ? person.name.surname ?? ''
    : rel.spouses.find((s) => s.person?.gender === 'M' && s.person.name.surname)?.person?.name.surname ?? person.name.surname ?? '';

  const exec = async (command: Command) => {
    const focusId = await run(command);
    if (focusId && command.type !== 'updatePerson') useUi.getState().select(focusId, true);
    if (focusId !== undefined) setMode({ kind: 'view' });
    return focusId;
  };

  const openAdd = (kind: AddKind) => {
    setAddSource('new'); setPreviousStatus('active'); setUnionId(''); setRelation('biological');
    setSpouseSlot(rel.spouses.find((s) => !s.person)?.union.id ?? 'new');
    setPosition('');
    setMode({ kind: 'add', relation: kind });
  };
  const hasUnknownPartner = rel.spouses.some((s) => !s.person);
  const slotLabel = (union: FamilyUnion) => {
    const names = union.children.map((c) => family.people.find((p) => p.id === c.personId)).filter((p): p is Person => !!p).slice(0, 3).map(givenL).join(', ');
    return names ? t('The unknown partner (parent of {names})', { names }) : t('The unknown partner');
  };

  /** People who cannot be linked in this role: already linked, or would create an impossible loop. */
  const blockedFor = (kind: AddKind): Set<string> => {
    const blocked = new Set<string>(rel.spouses.filter((s) => s.person && s.union.status === 'active').map((s) => s.person!.id));
    const above = ancestorIds(family, person.id);
    const below = descendantIds(family, person.id);
    if (kind === 'child') { above.forEach((id) => blocked.add(id)); rel.children.forEach((c) => blocked.add(c.person.id)); rel.spouses.forEach((s) => s.person && blocked.add(s.person.id)); }
    if (kind === 'parent') { below.forEach((id) => blocked.add(id)); rel.parents.forEach((p) => blocked.add(p.id)); rel.spouses.forEach((s) => s.person && blocked.add(s.person.id)); }
    if (kind === 'sibling') { above.forEach((id) => blocked.add(id)); below.forEach((id) => blocked.add(id)); rel.siblings.forEach((p) => blocked.add(p.id)); }
    return blocked;
  };

  const unlink = async (key: string, command: Command) => {
    if (confirmUnlink !== key) { setConfirmUnlink(key); return; }
    setConfirmUnlink('');
    await run(command);
  };

  const startEdit = () => {
    setDraft(valuesOf(person));
    setUnionDraft(Object.fromEntries(rel.spouses.filter((s) => s.person).map(({ union }) => [union.id, { status: union.status, startDate: union.startDate?.value ?? '', place: union.place?.text ?? '' }])));
    setParentRelation(rel.parentRelation ?? 'biological');
    setFormError('');
    setMode({ kind: 'edit' });
  };

  const saveEdit = async (event: FormEvent) => {
    event.preventDefault();
    if (!draft) return;
    const dates = [[t('Birth date'), draft.birthDate], [t('Death date'), draft.isLiving ? '' : draft.deathDate], ...Object.values(unionDraft).map((u) => [t('Marriage date'), u.startDate])];
    const bad = dates.find(([, value]) => value && !isValidPartialDate(value));
    if (bad) { setFormError(t('{label} is not a valid date.', { label: bad[0] })); return; }
    setFormError('');
    const ok = await run({
      type: 'updatePerson', personId: person.id,
      patch: {
        given: draft.given.trim(), surname: clean(draft.surname), birthSurname: clean(draft.birthSurname), nickname: clean(draft.nickname),
        aliases: draft.aliases.split(',').map((a) => a.trim()).filter(Boolean), localName: clean(draft.localName), gender: draft.gender, isLiving: draft.isLiving,
        birthDate: clean(draft.birthDate), birthPlace: clean(draft.birthPlace), deathDate: draft.isLiving ? null : clean(draft.deathDate), deathPlace: draft.isLiving ? null : clean(draft.deathPlace),
        currentPlace: clean(draft.currentPlace), village: clean(draft.village), gotra: clean(draft.gotra), bloodGroup: clean(draft.bloodGroup),
        occupation: clean(draft.occupation), education: clean(draft.education), phone: clean(draft.phone), email: clean(draft.email), address: clean(draft.address), bio: clean(draft.bio),
      },
    });
    if (!ok) return;
    for (const { union } of rel.spouses) {
      const next = unionDraft[union.id];
      if (!next) continue;
      if (next.status !== union.status || next.startDate !== (union.startDate?.value ?? '') || next.place !== (union.place?.text ?? '')) {
        await run({ type: 'updateUnion', unionId: union.id, status: next.status, startDate: clean(next.startDate), place: clean(next.place) });
      }
    }
    if (rel.parentUnion && parentRelation !== (rel.parentRelation ?? 'biological')) {
      await run({ type: 'setChildRelation', unionId: rel.parentUnion.id, personId: person.id, relation: parentRelation });
    }
    setMode({ kind: 'view' });
  };

  const submitAdd = (kind: AddKind) => (v: QuickValues) => {
    const input = { given: v.given.trim(), surname: clean(v.surname), birthSurname: kind === 'spouse' && v.gender === 'F' ? clean(v.birthSurname) : null, gender: v.gender, isLiving: true, birthYear: /^\d{4}$/.test(v.birthYear) ? v.birthYear : null };
    if (kind === 'spouse') {
      const anchorSurname = person.gender === 'F' && v.gender === 'M' && v.takesName && v.surname.trim() ? v.surname.trim() : undefined;
      return exec({ type: 'addSpouse', personId: person.id, person: input, previousStatus: previousStatus === 'active' ? undefined : previousStatus, anchorSurname, unionId: hasUnknownPartner ? spouseSlot : undefined });
    }
    if (kind === 'parent') return exec({ type: 'addParent', childId: person.id, person: input });
    if (kind === 'sibling') return exec({ type: 'addSibling', personId: person.id, person: input, position: position ? Number(position) : undefined });
    return exec({ type: 'addChild', parentId: person.id, unionId: unionId || undefined, person: input, relation, position: position ? Number(position) : undefined });
  };

  const choosePhoto = async (file: File | undefined) => {
    if (!file) return;
    try { await setPhoto(person.id, await preparePhoto(file)); }
    catch (error) { notify(error instanceof Error ? error.message : t('That photo could not be used.')); }
    if (fileInput.current) fileInput.current.value = '';
  };

  const addLabels: Record<AddKind, string> = { spouse: t('Add spouse'), child: t('Add child'), parent: t('Add parent'), sibling: t('Add sibling') };
  const hasPhoto = !!person.profile?.photoMediaId;
  const removeImpact = [
    rel.children.length ? (rel.children.length > 1 ? t('{n} children will stay in the tree, with an "Unknown" parent you can fill in later.', { n: rel.children.length }) : t('1 child will stay in the tree, with an "Unknown" parent you can fill in later.')) : '',
    rel.parentUnion ? t(rel.parents.length > 1 ? 'Their link to their own parents will also be removed.' : 'Their link to their own parent will also be removed.') : '',
  ].filter(Boolean).join(' ') || t('No one else is affected.');
  const mergeBlocked = new Set<string>([...ancestorIds(family, person.id), ...descendantIds(family, person.id), ...rel.spouses.flatMap((s) => (s.person ? [s.person.id] : []))]);
  const set = <K extends keyof Values>(key: K, value: Values[K]) => setDraft((d) => (d ? { ...d, [key]: value } : d));

  /** Lets the admin say where a new child belongs among the brothers and sisters. */
  const positionField = (kind: 'child' | 'sibling') => {
    const target = kind === 'sibling'
      ? rel.parentUnion
      : unionId ? family.unions.find((u) => u.id === unionId) : rel.spouses.length === 1 ? rel.spouses[0].union : null;
    const kids = target ? orderedChildren(target).flatMap((l) => family.people.find((p) => p.id === l.personId) ?? []) : [];
    if (kids.length === 0) return null;
    return (
      <Field label={t('Position among brothers and sisters')}>
        <select value={position} onChange={(e) => setPosition(e.target.value)}>
          <option value="">{t('Automatic (by birth year, otherwise youngest)')}</option>
          {Array.from({ length: kids.length + 1 }, (_, i) => (
            <option key={i + 1} value={String(i + 1)}>
              {i < kids.length ? t('{ord} born · before {name}', { ord: ordinalL(i + 1), name: givenL(kids[i]) }) : t('{ord} born · after {name}', { ord: ordinalL(i + 1), name: givenL(kids[kids.length - 1]) })}
            </option>
          ))}
        </select>
      </Field>
    );
  };

  const renderAddExtra = (kind: AddKind) => (
    <>
      {kind === 'spouse' && hasUnknownPartner && (
        <Field label={t('Which marriage is this?')}>
          <select value={spouseSlot} onChange={(e) => setSpouseSlot(e.target.value)}>
            {rel.spouses.filter((s) => !s.person).map(({ union }) => <option key={union.id} value={union.id}>{slotLabel(union)}</option>)}
            <option value="new">{t('A new marriage')}</option>
          </select>
        </Field>
      )}
      {kind === 'spouse' && rel.spouses.some((s) => s.person && s.union.status === 'active') && (
        <Field label={t('Earlier marriage')}>
          <select value={previousStatus} onChange={(e) => setPreviousStatus(e.target.value as FamilyUnion['status'])}>
            <option value="active">{t('Still married')}</option>
            <option value="divorced">{t('Divorced')}</option>
            <option value="widowed">{t('Widowed')}</option>
            <option value="separated">{t('Separated')}</option>
            <option value="annulled">{t('Annulled')}</option>
          </select>
        </Field>
      )}
      {kind === 'child' && (
        <>
          {rel.spouses.length > 1 && (
            <Field label={t('Child of')}>
              <select value={unionId} onChange={(e) => setUnionId(e.target.value)} required>
                <option value="" disabled>{t('Choose a marriage')}</option>
                {rel.spouses.map(({ person: spouse, union }) => <option key={union.id} value={union.id}>{givenL(person)} &amp; {nameOf(spouse)}{union.status !== 'active' ? ` (${t(STATUS_LABEL[union.status])})` : ''}</option>)}
              </select>
            </Field>
          )}
          <Field label={t('Relationship')}><select value={relation} onChange={(e) => setRelation(e.target.value as ChildRelation)}>{RELATIONS.map((r) => <option key={r} value={r}>{t(cap(r))}</option>)}</select></Field>
        </>
      )}
      {(kind === 'child' || kind === 'sibling') && positionField(kind)}
    </>
  );

  const buildLink = (kind: AddKind) => (picked: Person, options: { takesName: boolean }): Command => {
    if (kind === 'spouse') {
      return {
        type: 'linkSpouse', personId: person.id, spouseId: picked.id,
        previousStatus: previousStatus === 'active' ? undefined : previousStatus, unionId: hasUnknownPartner ? spouseSlot : undefined,
        anchorSurname: person.gender === 'F' && picked.gender === 'M' && options.takesName && picked.name.surname ? picked.name.surname : undefined,
      };
    }
    if (kind === 'child') return { type: 'linkChild', parentId: person.id, childId: picked.id, unionId: unionId || undefined, relation, position: position ? Number(position) : undefined };
    if (kind === 'parent') return { type: 'linkParent', childId: person.id, parentId: picked.id };
    return { type: 'linkSibling', personId: person.id, siblingId: picked.id, position: position ? Number(position) : undefined };
  };

  return (
    <aside className="panel" aria-label={t('{name} details', { name: givenL(person) })}>
      <header className="panel-head">
        <div className="portrait">
          <Avatar person={person} size="lg" />
          {admin && (
            <>
              <button className="cam" aria-label={hasPhoto ? t('Change photo') : t('Add photo')} title={hasPhoto ? t('Change photo') : t('Add photo')} onClick={() => fileInput.current?.click()}><Camera size={14} /></button>
              <input ref={fileInput} type="file" accept="image/*" hidden onChange={(e) => void choosePhoto(e.target.files?.[0])} />
            </>
          )}
        </div>
        <div className="panel-title">
          <h2>{placeholder ? t('Unknown ancestor') : fullNameL(person)}</h2>
          {!placeholder && (birthNote || kannada || known.length > 0) && (
            <div className="names-sub">
              {birthNote && <span>{birthNote}</span>}
              {kannada && <span className="kn" lang="kn">{kannada}</span>}
              {known.length > 0 && <span>{t('Also known as {names}', { names: known.join(', ') })}</span>}
            </div>
          )}
          <p>
            <GenderMark gender={person.gender} />
            {late && <Flower2 size={12} aria-label={t('Late')} />}
            <span>{[late ? t('Late') : null, span, age, rankText].filter(Boolean).join(' · ') || (person.isLiving ? t('Living') : '')}</span>
          </p>
          {admin && hasPhoto && <button className="linkish" onClick={() => void setPhoto(person.id, null)}>{t('Remove photo')}</button>}
        </div>
        <button className="icon-btn" aria-label={t('Close')} onClick={() => useUi.getState().select(null)}><X size={18} /></button>
      </header>

      {mode.kind === 'view' && (
        <>
          {admin && (
            <div className="actions">
              {(['spouse', 'child', 'parent', 'sibling'] as AddKind[]).map((kind) => (
                <button key={kind} className="btn soft" onClick={() => openAdd(kind)}><Plus size={14} />{t(cap(kind))}</button>
              ))}
              <button className="btn soft" onClick={startEdit}><Pencil size={14} />{t('Edit')}</button>
            </div>
          )}
          <nav className="tabs" role="tablist">
            {tabs.map((name) => <button key={name} role="tab" aria-selected={tab === name} className={tab === name ? 'on' : ''} onClick={() => setTab(name)}>{t(cap(name))}{name === 'photos' && photoCount > 0 ? ` ${num(photoCount)}` : ''}</button>)}
          </nav>
          <div className="body">
            {tab === 'family' && (
              <>
                {rel.parents.length > 0 && <section><h3>{t('Parents')}</h3><div className="chips">{rel.parents.map((p) => <Chip key={p.id} person={p} note={rel.parentRelation && rel.parentRelation !== 'biological' ? t(cap(rel.parentRelation)) : undefined} />)}</div></section>}
                {rel.spouses.length > 0 && (
                  <section><h3>{t(person.gender === 'F' ? 'Husband' : person.gender === 'M' ? 'Wife' : 'Partner')}</h3>
                    <div className="chips">{rel.spouses.map(({ person: spouse, union }) => {
                      const note = [union.status === 'active' ? '' : t(STATUS_LABEL[union.status]), dateText(union.startDate?.value), union.place?.text].filter(Boolean).join(' · ');
                      return spouse
                        ? <Chip key={union.id} person={spouse} note={note || undefined} icon={union.status === 'active' ? <Heart size={12} className="gold" fill="currentColor" /> : <HeartCrack size={12} />} />
                        : <span key={union.id} className="chip ghost">{t('Unknown')}</span>;
                    })}</div></section>
                )}
                {rel.children.length > 0 && <section><h3>{t('Children')}</h3><div className="chips">{rel.children.map(({ person: child, relation: kind, union }) => <Chip key={child.id} person={child} note={[kind !== 'biological' ? t(cap(kind)) : '', birthLabel(birthRankIn(union, child.id)) ?? ''].filter(Boolean).join(' · ') || undefined} />)}</div></section>}
                {rel.siblings.length > 0 && <section><h3>{t('Siblings')}</h3><div className="chips">{rel.siblings.map((p) => <Chip key={p.id} person={p} note={rel.parentUnion ? birthLabel(birthRankIn(rel.parentUnion, p.id)) ?? undefined : undefined} />)}</div></section>}
                {rel.parents.length + rel.spouses.length + rel.children.length + rel.siblings.length === 0 && <p className="muted">{t('No relatives linked yet.')}</p>}
              </>
            )}
            {tab === 'about' && (() => {
              const rows: [string, ReactNode][] = [
                [t('Born'), [born, person.vitals?.birth?.place?.text].filter(Boolean).join(' · ')],
                [t('Passed away'), [died, person.vitals?.death?.place?.text].filter(Boolean).join(' · ')],
                [t('Lives in'), person.profile?.currentPlace], [t('Native village'), custom('village')], [t('Gotra'), custom('gotra')],
                [t('Blood group'), custom('bloodGroup')], [t('Occupation'), person.profile?.occupation], [t('Education'), person.profile?.education],
                [t('Phone'), person.profile?.contacts?.phone], [t('Email'), person.profile?.contacts?.email], [t('Address'), person.profile?.contacts?.address],
              ];
              const shown = rows.filter(([, value]) => value);
              return shown.length
                ? <dl className="facts">{shown.map(([label, value]) => <Row key={label} label={label}>{value}</Row>)}</dl>
                : <p className="muted">{t('Nothing recorded yet.')}{admin ? ` ${t('Use Edit to add details future generations will want to know.')}` : ''}</p>;
            })()}
            {tab === 'story' && (person.profile?.bio
              ? <p className="story">{person.profile.bio}</p>
              : <p className="muted">{t('No story yet.')}{admin ? ` ${t('Use Edit to write a few lines about their life.')}` : ''}</p>)}
            {tab === 'photos' && <GalleryTab person={person} />}
          </div>
        </>
      )}

      {mode.kind === 'add' && (
        <div className="body">
          <h3 className="form-title">{addLabels[mode.relation]} <span>{t('for {name}', { name: nameOf(person) })}</span></h3>
          <div className="seg two" role="radiogroup" aria-label={t('Who to add')}>
            <button type="button" role="radio" aria-checked={addSource === 'new'} className={addSource === 'new' ? 'on' : ''} onClick={() => setAddSource('new')}>{t('New person')}</button>
            <button type="button" role="radio" aria-checked={addSource === 'existing'} className={addSource === 'existing' ? 'on' : ''} onClick={() => setAddSource('existing')}>{t('Already in the tree')}</button>
          </div>
          {addSource === 'existing' ? (
            <LinkExisting
              key={mode.relation}
              person={person}
              kind={mode.relation}
              blocked={blockedFor(mode.relation)}
              busy={busy}
              onCancel={() => setMode({ kind: 'view' })}
              build={buildLink(mode.relation)}
              onSubmit={(command) => void exec(command)}
              extra={renderAddExtra(mode.relation)}
            />
          ) : (
          <QuickAdd
            key={mode.relation}
            initial={{
              given: '',
              surname: mode.relation === 'child' ? fatherSurname : mode.relation === 'sibling' || mode.relation === 'parent' ? birthSurnameOf(person) : person.gender === 'M' ? person.name.surname ?? '' : '',
              gender: mode.relation === 'spouse' ? (person.gender === 'F' ? 'M' : 'F') : 'M',
            }}
            spouseOf={mode.relation === 'spouse' ? person : undefined}
            submitLabel={busy ? t('Saving…') : t('Add to tree')}
            onSubmit={submitAdd(mode.relation)}
            onCancel={() => setMode({ kind: 'view' })}
            extra={renderAddExtra(mode.relation)}
          />
          )}
        </div>
      )}

      {mode.kind === 'edit' && draft && (
        <form className="body edit" onSubmit={(e) => void saveEdit(e)}>
          <Fold title={t('Basics')} open>
            <Field label={t('First name')}><input required maxLength={80} value={draft.given} onChange={(e) => set('given', e.target.value)} /></Field>
            <Field label={t('Surname (current)')}><input maxLength={80} value={draft.surname} onChange={(e) => set('surname', e.target.value)} /></Field>
            <Field label={t('Birth surname (if it changed after marriage)')}><input maxLength={80} value={draft.birthSurname} onChange={(e) => set('birthSurname', e.target.value)} /></Field>
            <Field label={t('Pet name / nickname')}><input maxLength={80} placeholder={t('What family calls them')} value={draft.nickname} onChange={(e) => set('nickname', e.target.value)} /></Field>
            <Field label={t('Other names (separate with commas)')}><input maxLength={300} placeholder={t('e.g. Shivakka, Amma')} value={draft.aliases} onChange={(e) => set('aliases', e.target.value)} /></Field>
            <Field label={t('Name in Kannada')}><input maxLength={80} lang="kn" placeholder={t('If empty, it is spelled from the English name')} value={draft.localName} onChange={(e) => set('localName', e.target.value)} /></Field>
            <GenderPicker value={draft.gender} onChange={(g) => set('gender', g)} />
          </Fold>
          <Fold title={t('Life')} open>
            <DateField label={t('Born')} value={draft.birthDate} onChange={(v) => set('birthDate', v)} />
            <Field label={t('Birthplace')}><input maxLength={120} value={draft.birthPlace} onChange={(e) => set('birthPlace', e.target.value)} /></Field>
            <label className="check"><input type="checkbox" checked={!draft.isLiving} onChange={(e) => set('isLiving', !e.target.checked)} /> {t('Passed away')}</label>
            {!draft.isLiving && <><DateField label={t('Died')} value={draft.deathDate} onChange={(v) => set('deathDate', v)} /><Field label={t('Place of passing')}><input maxLength={120} value={draft.deathPlace} onChange={(e) => set('deathPlace', e.target.value)} /></Field></>}
            {draft.isLiving && <Field label={t('Lives in')}><input maxLength={120} value={draft.currentPlace} onChange={(e) => set('currentPlace', e.target.value)} /></Field>}
          </Fold>
          <Fold title={t('Roots and work')}>
            <Field label={t('Native village')}><input maxLength={120} value={draft.village} onChange={(e) => set('village', e.target.value)} /></Field>
            <Field label={t('Gotra')}><input maxLength={80} value={draft.gotra} onChange={(e) => set('gotra', e.target.value)} /></Field>
            <Field label={t('Blood group')}><select value={draft.bloodGroup} onChange={(e) => set('bloodGroup', e.target.value)}><option value="">{t('Not known')}</option>{BLOOD_GROUPS.map((g) => <option key={g}>{g}</option>)}</select></Field>
            <Field label={t('Occupation')}><input maxLength={120} value={draft.occupation} onChange={(e) => set('occupation', e.target.value)} /></Field>
            <Field label={t('Education')}><input maxLength={200} value={draft.education} onChange={(e) => set('education', e.target.value)} /></Field>
          </Fold>
          {(Object.keys(unionDraft).length > 0 || rel.parentUnion) && (
            <Fold title={t('Marriage and family links')}>
              {rel.spouses.filter((s) => s.person).map(({ person: spouse, union }) => {
                const u = unionDraft[union.id];
                if (!u) return null;
                const patch = (next: Partial<typeof u>) => setUnionDraft((d) => ({ ...d, [union.id]: { ...u, ...next } }));
                return (
                  <div className="mini-card" key={union.id}>
                    <b><Gem size={11} /> {t('With {name}', { name: nameOf(spouse) })}</b>
                    <Field label={t('Status')}><select value={u.status} onChange={(e) => patch({ status: e.target.value as FamilyUnion['status'] })}>{UNION_STATUSES.map((s) => <option key={s} value={s}>{t(STATUS_LABEL[s])}</option>)}</select></Field>
                    <DateField label={t('Married on')} value={u.startDate} onChange={(v) => patch({ startDate: v })} />
                    <Field label={t('Place')}><input maxLength={120} value={u.place} onChange={(e) => patch({ place: e.target.value })} /></Field>
                  </div>
                );
              })}
              {rel.parentUnion && <Field label={t('Relation to parents')}><select value={parentRelation} onChange={(e) => setParentRelation(e.target.value as ChildRelation)}>{RELATIONS.map((r) => <option key={r} value={r}>{t(cap(r))}</option>)}</select></Field>}
            </Fold>
          )}
          {((rel.parentUnion && rel.parentUnion.children.length > 1) || rel.spouses.some((s) => s.union.children.length > 1)) && (
            <Fold title={t('Birth order')}>
              <p className="muted">{t('Eldest first. Use the arrows to correct the order; changes apply immediately.')}</p>
              {rel.parentUnion && <ChildOrder unionId={rel.parentUnion.id} title={t('Among brothers and sisters')} currentId={person.id} />}
              {rel.spouses.map(({ person: spouse, union }) => <ChildOrder key={union.id} unionId={union.id} title={t('Children with {name}', { name: nameOf(spouse) })} />)}
            </Fold>
          )}
          <Fold title={t('Story')}><Field label={t('A few lines for the next generation')} wide><textarea rows={5} maxLength={4000} value={draft.bio} onChange={(e) => set('bio', e.target.value)} /></Field></Fold>
          {(rel.parentUnion || rel.spouses.some((s) => s.person) || rel.children.length > 0) && (
            <Fold title={t('Unlink relatives')}>
              <p className="muted">{t('Removes only the connection. The person stays in the tree and can be linked again.')}</p>
              {rel.parentUnion && (
                <button type="button" className="btn danger" onClick={() => void unlink('parents', { type: 'detachChild', unionId: rel.parentUnion!.id, personId: person.id })}>
                  {confirmUnlink === 'parents' ? t('Click again to confirm') : t('Detach from {names}', { names: rel.parents.map((p) => givenL(p)).join(' & ') || t('parents') })}
                </button>
              )}
              {rel.spouses.filter((s) => s.person).map(({ person: spouse, union }) => (
                <button type="button" key={union.id} className="btn danger" onClick={() => void unlink(union.id, { type: 'removeUnion', unionId: union.id })}>
                  {confirmUnlink === union.id ? (union.children.length === 0 ? t('Click again') : union.children.length === 1 ? t('Click again (1 child loses this link)') : t('Click again ({n} children lose this link)', { n: union.children.length })) : t('Unlink marriage with {name}', { name: nameOf(spouse) })}
                </button>
              ))}
              {rel.children.map(({ person: child, union }) => (
                <button type="button" key={`${union.id}:${child.id}`} className="btn danger" onClick={() => void unlink(`${union.id}:${child.id}`, { type: 'detachChild', unionId: union.id, personId: child.id })}>
                  {confirmUnlink === `${union.id}:${child.id}` ? t('Click again to confirm') : t('Detach child {name}', { name: nameOf(child) })}
                </button>
              ))}
            </Fold>
          )}
          <Fold title={t('Contact (admins only)')}>
            <Field label={t('Phone')}><input maxLength={40} value={draft.phone} onChange={(e) => set('phone', e.target.value)} /></Field>
            <Field label={t('Email')}><input type="email" maxLength={120} value={draft.email} onChange={(e) => set('email', e.target.value)} /></Field>
            <Field label={t('Address')}><textarea rows={2} maxLength={300} value={draft.address} onChange={(e) => set('address', e.target.value)} /></Field>
          </Fold>
          {formError && <p className="error" role="alert">{formError}</p>}
          <div className="form-actions sticky">
            <button type="button" className="btn ghost" onClick={() => setMode({ kind: 'view' })}>{t('Cancel')}</button>
            <button type="submit" className="btn gold" disabled={busy}>{busy ? t('Saving…') : t('Save changes')}</button>
          </div>
          {person.id !== family.meta.rootPersonId && <button type="button" className="btn danger" onClick={() => setMode({ kind: 'remove' })}><Trash2 size={14} />{t('Remove from tree')}</button>}
          <button type="button" className="btn soft" onClick={() => setMode({ kind: 'merge' })}>{t('Merge a duplicate into {name}', { name: givenL(person) })}</button>
        </form>
      )}

      {mode.kind === 'merge' && (
        <div className="body">
          <h3 className="form-title">{t('Merge a duplicate')} <span>{t('into {name}', { name: nameOf(person) })}</span></h3>
          <p className="muted">{t('Use this when the same person was entered twice. Pick the duplicate.')}</p>
          <LinkExisting
            person={person}
            kind="merge"
            blocked={mergeBlocked}
            busy={busy}
            onCancel={() => setMode({ kind: 'view' })}
            build={(picked) => ({ type: 'mergePeople', keepId: person.id, removeId: picked.id })}
            onSubmit={(command) => void exec(command)}
          />
        </div>
      )}

      {mode.kind === 'remove' && (
        <div className="body">
          <h3 className="form-title">{t('Remove {name}?', { name: nameOf(person) })}</h3>
          <p className="muted">{removeImpact} {t('You can undo this right after.')}</p>
          <div className="form-actions">
            <button className="btn ghost" onClick={startEdit}>{t('Keep')}</button>
            <button className="btn danger solid" disabled={busy} onClick={async () => { const ok = await run({ type: 'deletePerson', personId: person.id }); if (ok !== undefined) useUi.getState().select(null); }}>{t('Remove')}</button>
          </div>
        </div>
      )}
    </aside>
  );
}
