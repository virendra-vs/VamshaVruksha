import { create } from 'zustand';
import { ageSummary, formatPartialDate, fullName, knownAs, ordinal, type Person } from '@vamsha/shared';
import { KN } from './kn';
import { toKannada } from './translit';

export type Lang = 'en' | 'kn';

const readLang = (): Lang => {
  const stored = localStorage.getItem('vamsha-lang');
  if (stored === 'en' || stored === 'kn') return stored;
  return navigator.language?.toLowerCase().startsWith('kn') ? 'kn' : 'en';
};

const applyLang = (lang: Lang) => { document.documentElement.lang = lang; };

export const useLang = create<{ lang: Lang; setLang: (lang: Lang) => void }>((set) => {
  const initial = readLang();
  applyLang(initial);
  return {
    lang: initial,
    setLang(lang) { localStorage.setItem('vamsha-lang', lang); applyLang(lang); set({ lang }); },
  };
});

const isKn = () => useLang.getState().lang === 'kn';

const KN_DIGITS = '೦೧೨೩೪೫೬೭೮೯';
/** Numbers as Kannada numerals when the language is Kannada. */
export const num = (value: number | string): string => (isKn() ? String(value).replace(/\d/g, (d) => KN_DIGITS[Number(d)]) : String(value));

const fill = (text: string, params?: Record<string, string | number>) =>
  (params ? text.replace(/\{(\w+)\}/g, (_, key: string) => (key in params ? (typeof params[key] === 'number' ? num(params[key]) : String(params[key])) : `{${key}}`)) : text);

/** Translates a UI string; the English text is the key, so a missing translation simply stays in English. */
export function t(key: string, params?: Record<string, string | number>): string {
  return fill(isKn() ? KN[key] ?? key : key, params);
}

const templates = Object.keys(KN)
  .filter((key) => key.includes('{'))
  .sort((a, b) => b.length - a.length)
  .map((key) => ({ key, names: [...key.matchAll(/\{(\w+)\}/g)].map((m) => m[1]), pattern: new RegExp(`^${key.replace(/[.*+?^$()|[\]\\]/g, '\\$&').replace(/\{\w+\}/g, '(.+?)')}$`) }));

/** Translates a message that came from the server, including ones with names in them. */
export function serverText(message: string): string {
  if (!isKn()) return message;
  if (KN[message]) return KN[message];
  for (const { key, names, pattern } of templates) {
    const match = pattern.exec(message);
    if (match) return fill(KN[key], Object.fromEntries(names.map((name, i) => [name, match[i + 1]])));
  }
  return message;
}

/** Call inside a component so it redraws when the language changes. */
export function useT() {
  useLang((state) => state.lang);
  return t;
}

/* ---------- Names ---------- */

let familySurname: { en: string; kn: string } | null = null;
export function registerFamilyName(surname: string, localName?: string | null) {
  const first = localName?.trim().split(/\s+/)[0];
  familySurname = first ? { en: surname.trim().toLowerCase(), kn: first } : null;
}

const word = (text: string) => (familySurname && text.trim().toLowerCase() === familySurname.en ? familySurname.kn : toKannada(text));

/** A saved Kannada name wins; one word is taken as the first name, several as the whole name. */
export function fullNameL(person: Person): string {
  if (!isKn()) return fullName(person);
  const saved = person.name.localScript?.kn?.trim();
  const rest = [person.name.middle, person.name.surname].filter((part): part is string => !!part?.trim()).map(word);
  if (saved) return /\s/.test(saved) ? saved : [saved, ...rest].join(' ');
  return [word(person.name.given), ...rest].join(' ');
}

export function givenL(person: Person): string {
  if (!isKn()) return person.name.given;
  const saved = person.name.localScript?.kn?.trim();
  return saved ? saved.split(/\s+/)[0] : toKannada(person.name.given);
}

export const displayNameL = (person: Person): string =>
  (person.name.nickname ? `${givenL(person)} (${isKn() ? toKannada(person.name.nickname) : person.name.nickname})` : givenL(person));

export const knownAsL = (person: Person): string[] => (isKn() ? knownAs(person).map(toKannada) : knownAs(person));

export function birthNameNoteL(person: Person): string | null {
  const birth = person.name.birthSurname?.trim();
  if (!birth || birth === person.name.surname?.trim()) return null;
  return t('née {name}', { name: isKn() ? word(birth) : birth });
}

/** First letter of the name in the current language, for the round avatar. */
export function initialL(person: Person): string {
  const name = givenL(person).trim();
  const first = typeof Intl.Segmenter === 'function' ? [...new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(name)][0]?.segment : Array.from(name)[0];
  return (first ?? '').toUpperCase();
}

/* ---------- Dates, ages, birth order ---------- */

const KN_MONTHS = ['ಜನವರಿ', 'ಫೆಬ್ರವರಿ', 'ಮಾರ್ಚ್', 'ಏಪ್ರಿಲ್', 'ಮೇ', 'ಜೂನ್', 'ಜುಲೈ', 'ಆಗಸ್ಟ್', 'ಸೆಪ್ಟೆಂಬರ್', 'ಅಕ್ಟೋಬರ್', 'ನವೆಂಬರ್', 'ಡಿಸೆಂಬರ್'];
const EN_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const monthName = (index: number) => (isKn() ? KN_MONTHS[index] : EN_MONTHS[index]);

export function dateText(value?: string | null): string {
  const english = formatPartialDate(value);
  if (!english || !isKn()) return english;
  const [year, month, day] = value!.split('-');
  if (!month) return num(year);
  return day ? `${num(Number(day))} ${monthName(Number(month) - 1)} ${num(year)}` : `${monthName(Number(month) - 1)} ${num(year)}`;
}

export function ageText(person: Person): string | null {
  const text = ageSummary(person);
  if (!text) return null;
  const years = Number(/\d+/.exec(text)?.[0] ?? 0);
  return text.startsWith('Age') ? t('Age {n}', { n: years }) : t('Lived {n} years', { n: years });
}

const KN_ORDINALS = ['', 'ಮೊದಲ', 'ಎರಡನೇ', 'ಮೂರನೇ', 'ನಾಲ್ಕನೇ', 'ಐದನೇ', 'ಆರನೇ', 'ಏಳನೇ', 'ಎಂಟನೇ', 'ಒಂಬತ್ತನೇ', 'ಹತ್ತನೇ'];
export const ordinalL = (n: number): string => (isKn() ? KN_ORDINALS[n] ?? `${num(n)}ನೇ` : ordinal(n));
export const bornL = (n: number): string => (isKn() ? `${ordinalL(n)} ಮಗು` : `${ordinal(n)} born`);

/** "2nd born", or null for an only child. */
export const birthLabel = (rank: { rank: number; of: number } | null | undefined): string | null => (rank && rank.of > 1 ? bornL(rank.rank) : null);
