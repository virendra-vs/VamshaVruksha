import { birthYear, deathYear, type Person } from '@vamsha/shared';
import { initialL, num, t } from './i18n';

/** Mid-tone jewel colours that read well on both the light and the dark theme. */
export const BRANCH_COLORS = ['#8566E0', '#1F9E78', '#D44F69', '#3B7FD6', '#D9872B', '#B957C4', '#7BA32A', '#1B9FB0'];
export const GOLD_HEX = { dark: '#D4AF5C', light: '#A57B26' } as const;

/** CSS colour for lines and accents; -1 (founders and ancestors) follows the theme's gold. */
export const branchColor = (branch: number) => (branch < 0 ? 'var(--gold)' : BRANCH_COLORS[branch % BRANCH_COLORS.length]);
export const branchHex = (branch: number, theme: 'light' | 'dark') => (branch < 0 ? GOLD_HEX[theme] : BRANCH_COLORS[branch % BRANCH_COLORS.length]);

export function lifeSpan(person: Person): string {
  const born = birthYear(person);
  const died = deathYear(person);
  if (born && died) return `${num(born)} – ${num(died)}`;
  if (born) return person.isLiving ? t('b. {y}', { y: num(born) }) : `${num(born)} –`;
  if (died) return t('d. {y}', { y: num(died) });
  return '';
}

export const isPlaceholder = (person: Person) => person.status === 'placeholder';
export const isLate = (person: Person) => !person.isLiving && !isPlaceholder(person);
export const initialOf = (person: Person) => (isPlaceholder(person) ? '?' : initialL(person));
