import type { ReactNode } from 'react';
import type { Person } from '@vamsha/shared';
import { useT } from './i18n';
import { mediaUrl } from './store';
import { initialOf } from './theme';

/** Shows the person's photo, or their initial when no photo has been added. */
export function Avatar({ person, size = 'sm', children }: { person: Person; size?: 'sm' | 'md' | 'lg'; children?: ReactNode }) {
  const photo = person.profile?.photoMediaId;
  useT();
  return (
    <span className={`pic ${size} g-${person.gender}`}>
      {photo
        ? <img src={mediaUrl(photo, size === 'lg' ? 'medium' : 'thumb')} alt="" loading="lazy" draggable={false} />
        : <span className="initial">{initialOf(person)}</span>}
      {children}
    </span>
  );
}
