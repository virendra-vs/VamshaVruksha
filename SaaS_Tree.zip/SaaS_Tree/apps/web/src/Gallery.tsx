import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft, ChevronRight, ImagePlus, Pencil, Star, Trash2, X } from 'lucide-react';
import {
  MEDIA_EVENT_TYPES, isValidPartialDate, type MediaEventType, type MediaItem, type Person,
} from '@vamsha/shared';
import { mediaUrl, useFamily, useUi } from './store';
import { dateText, fullNameL, givenL, num, t, useT } from './i18n';
import { isPlaceholder } from './theme';
import { prepareGalleryPhoto } from './photo';
import { Avatar } from './Avatar';
import { DateField, eventLabel, Field } from './Fields';

const dateKey = (item: MediaItem) => item.date?.value ?? '';
const yearOf = (item: MediaItem) => dateKey(item).slice(0, 4) || 'Undated';

/** Tag people in a photo: shows chips with a remove button and a search to add more. */
function PeoplePicker({ value, onChange }: { value: string[]; onChange: (ids: string[]) => void }) {
  const t = useT();
  const family = useFamily((s) => s.family)!;
  const [query, setQuery] = useState('');
  const byId = useMemo(() => new Map(family.people.map((p) => [p.id, p])), [family.people]);
  const matches = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return [];
    return family.people.filter((p) => !value.includes(p.id) && !isPlaceholder(p) && `${p.name.given} ${p.name.surname ?? ''} ${fullNameL(p)}`.toLowerCase().includes(needle)).slice(0, 5);
  }, [query, family.people, value]);
  return (
    <div className="field wide">
      <span>{t('People in the photo')}</span>
      <div className="chips tight">
        {value.map((id) => { const p = byId.get(id); return p && (
          <span className="chip static" key={id}><Avatar person={p} size="sm" /><span className="chip-name">{givenL(p)}</span>
            {value.length > 1 && <button type="button" className="x" aria-label={t('Remove {name}', { name: givenL(p) })} onClick={() => onChange(value.filter((v) => v !== id))}><X size={12} /></button>}
          </span>
        ); })}
      </div>
      <input placeholder={t('Add another person…')} value={query} onChange={(e) => setQuery(e.target.value)} />
      {matches.length > 0 && (
        <div className="pick-list">{matches.map((p) => <button type="button" key={p.id} onClick={() => { onChange([...value, p.id]); setQuery(''); }}><Avatar person={p} size="sm" />{fullNameL(p)}</button>)}</div>
      )}
    </div>
  );
}

function EventSelect({ value, onChange }: { value: MediaEventType; onChange: (v: MediaEventType) => void }) {
  useT();
  return <Field label={t('Occasion')}><select value={value} onChange={(e) => onChange(e.target.value as MediaEventType)}>{MEDIA_EVENT_TYPES.map((type) => <option key={type} value={type}>{eventLabel(type)}</option>)}</select></Field>;
}

function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); onClose(); } };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onClose]);
  return createPortal(
    <div className="backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <header><h2>{title}</h2><button className="icon-btn" aria-label={t('Close')} onClick={onClose}><X size={18} /></button></header>
        {children}
      </div>
    </div>, document.body);
}

function UploadDialog({ person, files, onClose }: { person: Person; files: File[]; onClose: () => void }) {
  const t = useT();
  const addGalleryPhoto = useFamily((s) => s.addGalleryPhoto);
  const [eventType, setEventType] = useState<MediaEventType>('other');
  const [date, setDate] = useState('');
  const [caption, setCaption] = useState('');
  const [people, setPeople] = useState([person.id]);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState('');

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (date && !isValidPartialDate(date)) { setError(t('That date is not valid.')); return; }
    setError('');
    for (let i = 0; i < files.length; i += 1) {
      setProgress(i);
      try {
        const prepared = await prepareGalleryPhoto(files[i]);
        const ok = await addGalleryPhoto({ ...prepared, caption: caption.trim() || null, eventType, date: date || null, personIds: people });
        if (!ok) { setProgress(null); return; }
      } catch (e) { setError(e instanceof Error ? e.message : t('Upload failed.')); setProgress(null); return; }
    }
    onClose();
  };

  return (
    <Modal title={files.length === 1 ? t('Add photo') : t('Add {n} photos', { n: files.length })} onClose={progress === null ? onClose : () => undefined}>
      <form className="form" onSubmit={(e) => void submit(e)}>
        <p className="muted">{files.map((f) => f.name).slice(0, 3).join(', ')}{files.length > 3 ? ` ${t('{names} and {n} more', { names: '', n: files.length - 3 }).trim()}` : ''}</p>
        <EventSelect value={eventType} onChange={setEventType} />
        <DateField label={t('When')} value={date} onChange={setDate} />
        <Field label={files.length > 1 ? t('Caption (same for all)') : t('Caption')} wide><input maxLength={300} placeholder={t('e.g. Naming ceremony at the village temple')} value={caption} onChange={(e) => setCaption(e.target.value)} /></Field>
        <PeoplePicker value={people} onChange={setPeople} />
        {error && <p className="error" role="alert">{error}</p>}
        <div className="form-actions">
          <button type="button" className="btn ghost" disabled={progress !== null} onClick={onClose}>{t('Cancel')}</button>
          <button className="btn gold" disabled={progress !== null}>{progress === null ? t('Upload') : t('Uploading {i} of {n}…', { i: progress + 1, n: files.length })}</button>
        </div>
      </form>
    </Modal>
  );
}

function Lightbox({ items, index, setIndex, onClose }: { items: MediaItem[]; index: number; setIndex: (i: number) => void; onClose: () => void }) {
  const t = useT();
  const family = useFamily((s) => s.family)!;
  const admin = useFamily((s) => s.admin);
  const run = useFamily((s) => s.run);
  const busy = useFamily((s) => s.busy);
  const item = items[index];
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState({ caption: '', eventType: 'other' as MediaEventType, date: '', personIds: [] as string[] });
  const [confirmDelete, setConfirmDelete] = useState(false);
  const byId = useMemo(() => new Map(family.people.map((p) => [p.id, p])), [family.people]);

  useEffect(() => { setEditing(false); setConfirmDelete(false); }, [item?.id]);
  useEffect(() => { if (!item) onClose(); }, [item, onClose]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (editing || (e.target as HTMLElement).closest('input, select, textarea')) return;
      if (e.key === 'Escape') { e.stopPropagation(); onClose(); }
      if (e.key === 'ArrowLeft' && index > 0) setIndex(index - 1);
      if (e.key === 'ArrowRight' && index < items.length - 1) setIndex(index + 1);
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [index, items.length, editing, onClose, setIndex]);

  if (!item) return null;
  const when = dateText(item.date?.value);
  const startEdit = () => { setDraft({ caption: item.caption ?? '', eventType: item.eventType, date: item.date?.value ?? '', personIds: item.personIds }); setEditing(true); };
  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    if (draft.date && !isValidPartialDate(draft.date)) return;
    const result = await run({ type: 'updateMedia', mediaId: item.id, caption: draft.caption.trim() || null, eventType: draft.eventType, date: draft.date || null, personIds: draft.personIds });
    if (result !== undefined || !useFamily.getState().toast) setEditing(false);
  };

  return createPortal(
    <div className="lightbox" role="dialog" aria-modal="true" aria-label={t('Photo')} onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <button className="lb-close icon-btn" aria-label={t('Close')} onClick={onClose}><X size={22} /></button>
      {index > 0 && <button className="lb-nav prev" aria-label={t('Previous photo')} onClick={() => setIndex(index - 1)}><ChevronLeft size={26} /></button>}
      {index < items.length - 1 && <button className="lb-nav next" aria-label={t('Next photo')} onClick={() => setIndex(index + 1)}><ChevronRight size={26} /></button>}
      <figure>
        <img src={mediaUrl(item.id, 'medium')} alt={item.caption ?? eventLabel(item.eventType)} />
        {!editing ? (
          <figcaption>
            <div className="lb-meta"><b>{eventLabel(item.eventType)}</b>{when && <span>{when}</span>}<span>{num(index + 1)} / {num(items.length)}</span></div>
            {item.caption && <p>{item.caption}</p>}
            <div className="chips tight">
              {item.personIds.map((id) => { const p = byId.get(id); return p && (
                <button key={id} className="chip" onClick={() => { useUi.getState().select(id, true); onClose(); }}><Avatar person={p} size="sm" /><span className="chip-name">{givenL(p)}</span></button>
              ); })}
            </div>
            {admin && (
              <div className="lb-actions">
                <button className="btn soft" onClick={startEdit}><Pencil size={14} />{t('Edit details')}</button>
                <button className="btn soft" disabled={busy} onClick={() => { const target = useUi.getState().selectedId; if (target) void run({ type: 'setProfilePhoto', personId: target, mediaId: item.id }); }}><Star size={14} />{t('Use as profile photo')}</button>
                {!confirmDelete
                  ? <button className="btn danger" onClick={() => setConfirmDelete(true)}><Trash2 size={14} />{t('Delete')}</button>
                  : <button className="btn danger solid" disabled={busy} onClick={async () => { await run({ type: 'deleteMedia', mediaId: item.id }); }}>{t('Delete this photo?')}</button>}
              </div>
            )}
          </figcaption>
        ) : (
          <form className="lb-edit form" onSubmit={(e) => void save(e)}>
            <EventSelect value={draft.eventType} onChange={(eventType) => setDraft({ ...draft, eventType })} />
            <DateField label={t('When')} value={draft.date} onChange={(date) => setDraft({ ...draft, date })} />
            <Field label={t('Caption')} wide><input maxLength={300} value={draft.caption} onChange={(e) => setDraft({ ...draft, caption: e.target.value })} /></Field>
            <PeoplePicker value={draft.personIds} onChange={(personIds) => setDraft({ ...draft, personIds })} />
            <div className="form-actions"><button type="button" className="btn ghost" onClick={() => setEditing(false)}>{t('Cancel')}</button><button className="btn gold" disabled={busy}>{t('Save')}</button></div>
          </form>
        )}
      </figure>
    </div>, document.body);
}

export function GalleryTab({ person }: { person: Person }) {
  const t = useT();
  const family = useFamily((s) => s.family)!;
  const admin = useFamily((s) => s.admin);
  const [filter, setFilter] = useState<MediaEventType | 'all'>('all');
  const [open, setOpen] = useState<number | null>(null);
  const [files, setFiles] = useState<File[] | null>(null);
  const input = useRef<HTMLInputElement>(null);

  const all = useMemo(() => family.media
    .filter((m) => m.personIds.includes(person.id))
    .sort((a, b) => (dateKey(a) || '9999').localeCompare(dateKey(b) || '9999') || (a.uploadedAt ?? '').localeCompare(b.uploadedAt ?? '')), [family.media, person.id]);
  const types = useMemo(() => [...new Set(all.map((m) => m.eventType))], [all]);
  const items = filter === 'all' ? all : all.filter((m) => m.eventType === filter);
  const groups = useMemo(() => {
    const map = new Map<string, MediaItem[]>();
    for (const item of items) map.set(yearOf(item), [...(map.get(yearOf(item)) ?? []), item]);
    return [...map.entries()];
  }, [items]);

  useEffect(() => { if (filter !== 'all' && !types.includes(filter)) setFilter('all'); }, [types, filter]);

  return (
    <>
      {admin && (
        <>
          <button className="btn soft add-photos" onClick={() => input.current?.click()}><ImagePlus size={15} />{t('Add photos')}</button>
          <input ref={input} type="file" accept="image/*" multiple hidden onChange={(e) => { const picked = [...(e.target.files ?? [])]; if (picked.length) setFiles(picked); if (input.current) input.current.value = ''; }} />
        </>
      )}
      {types.length > 1 && (
        <div className="filters" role="tablist" aria-label={t('Filter photos')}>
          {(['all', ...types] as const).map((type) => <button key={type} className={filter === type ? 'on' : ''} onClick={() => setFilter(type)}>{type === 'all' ? t('All') : eventLabel(type)}</button>)}
        </div>
      )}
      {all.length === 0 && <p className="muted">{t('No photos yet.')}{admin ? ` ${t('Add pictures from naming ceremonies, birthdays, weddings and family gatherings so future generations can see them.')}` : ''}</p>}
      {groups.map(([year, list]) => (
        <section key={year} className="year-group">
          <h3>{year === 'Undated' ? t('Undated') : num(year)}</h3>
          <div className="photo-grid">
            {list.map((item) => (
              <button key={item.id} className="photo" aria-label={item.caption ?? eventLabel(item.eventType)} onClick={() => setOpen(items.indexOf(item))}>
                <img src={mediaUrl(item.id, 'thumb')} alt="" loading="lazy" draggable={false} />
                <span>{item.caption || eventLabel(item.eventType)}</span>
              </button>
            ))}
          </div>
        </section>
      ))}
      {open !== null && <Lightbox items={items} index={open} setIndex={setOpen} onClose={() => setOpen(null)} />}
      {files && <UploadDialog person={person} files={files} onClose={() => setFiles(null)} />}
    </>
  );
}
