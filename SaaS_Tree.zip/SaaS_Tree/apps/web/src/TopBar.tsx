import { useEffect, useMemo, useRef, useState } from 'react';
import { Crown, Download, History, Info, KeyRound, Lock, LogOut, Maximize, Moon, Redo2, Search, ShieldCheck, Sun, Undo2, Upload } from 'lucide-react';
import { FamilySchema, fullName, getRelatives, knownAs } from '@vamsha/shared';
import { useFamily, useTheme, useUi } from './store';
import { birthNameNoteL, fullNameL, givenL, t, useLang, useT } from './i18n';
import { isPlaceholder } from './theme';
import { Avatar } from './Avatar';

function LangSwitch() {
  const lang = useLang((state) => state.lang);
  return (
    <div className="lang" role="group" aria-label={t('Language')} data-lang={lang}>
      <i className="lang-thumb" aria-hidden="true" />
      <button type="button" lang="kn" title="ಕನ್ನಡ" aria-label="ಕನ್ನಡ" aria-pressed={lang === 'kn'} onClick={() => useLang.getState().setLang('kn')}>ಕ</button>
      <button type="button" lang="en" title="English" aria-label="English" aria-pressed={lang === 'en'} onClick={() => useLang.getState().setLang('en')}>EN</button>
    </div>
  );
}

function SearchBox() {
  const family = useFamily((state) => state.family)!;
  const lang = useLang((state) => state.lang);
  const [query, setQuery] = useState('');
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); input.current?.focus(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const results = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return [];
    return family.people
      .filter((person) => !isPlaceholder(person) && `${fullName(person)} ${fullNameL(person)} ${person.name.birthSurname ?? ''} ${knownAs(person).join(' ')} ${person.name.localScript?.kn ?? ''}`.toLowerCase().includes(needle))
      .sort((a, b) => Number(!a.name.given.toLowerCase().startsWith(needle)) - Number(!b.name.given.toLowerCase().startsWith(needle)) || fullName(a).localeCompare(fullName(b)))
      .slice(0, 7)
      .map((person) => {
        const rel = getRelatives(family, person.id);
        const parents = rel.parents.map((p) => givenL(p)).join(' & ');
        const spouse = rel.spouses[0]?.person;
        const hint = rel.parents.length
          ? t(person.gender === 'F' ? 'Daughter of {parents}' : person.gender === 'M' ? 'Son of {parents}' : 'Child of {parents}', { parents })
          : spouse ? t(person.gender === 'F' ? 'Wife of {name}' : 'Husband of {name}', { name: givenL(spouse) }) : '';
        return { person, hint };
      });
  }, [query, family, lang]);

  return (
    <div className="search">
      <Search size={16} />
      <input ref={input} value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('Search family')} aria-label={t('Search family')} />
      {results.length > 0 && (
        <div className="results" role="listbox">
          {results.map(({ person, hint }) => (
            <button key={person.id} role="option" aria-selected={false} onClick={() => { useUi.getState().select(person.id, true); setQuery(''); }}>
              <Avatar person={person} size="sm" />
              <span><b>{fullNameL(person)}</b>{(hint || birthNameNoteL(person)) && <small>{[birthNameNoteL(person), hint].filter(Boolean).join(' · ')}</small>}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function AdminMenu() {
  const t = useT();
  const admin = useFamily((state) => state.admin);
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);
  const file = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return undefined;
    const close = (event: MouseEvent) => { if (!wrap.current?.contains(event.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);

  const readBackup = async (selected: File | undefined) => {
    if (!selected) return;
    const { notify } = useFamily.getState();
    try {
      const json = JSON.parse(await selected.text()) as { family?: unknown; photos?: Record<string, unknown> };
      const candidate = json.family ?? json;
      const parsed = FamilySchema.safeParse(candidate);
      if (!parsed.success) { notify(t('That file is not a Vamsha backup.')); return; }
      useUi.getState().openDialog('import', { family: parsed.data, raw: { family: candidate, photos: json.photos ?? {} }, photos: Object.keys(json.photos ?? {}).length });
    } catch { notify(t('That file could not be read.')); }
    if (file.current) file.current.value = '';
  };

  if (!admin) {
    return <button className="pill" onClick={() => useUi.getState().openDialog('login')} title={t('Sign in to edit')}><Lock size={14} /><span>{t('View only')}</span></button>;
  }
  return (
    <div className="menu-wrap" ref={wrap}>
      <button className="pill on" onClick={() => setOpen(!open)} aria-expanded={open}><ShieldCheck size={14} /><span>{t('Admin')}</span></button>
      {open && (
        <div className="menu" role="menu">
          <button role="menuitem" onClick={() => { setOpen(false); void useFamily.getState().exportBackup(); }}><Download size={15} />{t('Export backup')}</button>
          <button role="menuitem" onClick={() => file.current?.click()}><Upload size={15} />{t('Import backup')}</button>
          <button role="menuitem" onClick={() => { setOpen(false); useUi.getState().openDialog('history'); }}><History size={15} />{t('Version history')}</button>
          <button role="menuitem" onClick={() => { setOpen(false); useUi.getState().openDialog('password'); }}><KeyRound size={15} />{t('Change password')}</button>
          <button role="menuitem" onClick={() => { setOpen(false); void useFamily.getState().logout(); }}><LogOut size={15} />{t('Switch to view only')}</button>
        </div>
      )}
      <input ref={file} type="file" accept="application/json,.json" hidden onChange={(e) => { setOpen(false); void readBackup(e.target.files?.[0]); }} />
    </div>
  );
}

export function TopBar() {
  const t = useT();
  const lang = useLang((state) => state.lang);
  const family = useFamily((state) => state.family)!;
  const admin = useFamily((state) => state.admin);
  const canUndo = useFamily((state) => state.past.length > 0 && !state.busy);
  const canRedo = useFamily((state) => state.future.length > 0 && !state.busy);
  const legendOpen = useUi((state) => state.legendOpen);
  const theme = useTheme((state) => state.theme);

  return (
    <header className="topbar">
      <div className="brand"><Crown size={18} /><span lang={lang}>{lang === 'kn' ? (family.meta.localName as { kn?: string } | null | undefined)?.kn?.split(' ')[0] || family.meta.surname : family.meta.surname}</span></div>
      <SearchBox />
      <div className="tools">
        {admin && <button className="icon-btn" aria-label={t('Undo')} title={t('Undo (Ctrl+Z)')} disabled={!canUndo} onClick={() => void useFamily.getState().undo()}><Undo2 size={17} /></button>}
        {admin && <button className="icon-btn" aria-label={t('Redo')} title={t('Redo (Ctrl+Shift+Z)')} disabled={!canRedo} onClick={() => void useFamily.getState().redo()}><Redo2 size={17} /></button>}
        <button className={`icon-btn ${legendOpen ? 'on' : ''}`} aria-label={t('Legend')} title={t('What the symbols mean')} onClick={() => useUi.getState().toggleLegend()}><Info size={17} /></button>
        <button className="icon-btn" aria-label={theme === 'dark' ? t('Switch to light theme') : t('Switch to dark theme')} title={theme === 'dark' ? t('Light theme') : t('Dark theme')} onClick={() => useTheme.getState().toggle()}>{theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}</button>
        <button className="icon-btn hide-sm" aria-label={t('Full screen')} title={t('Full screen')} onClick={() => void (document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen())}><Maximize size={17} /></button>
        <LangSwitch />
        <AdminMenu />
      </div>
    </header>
  );
}
