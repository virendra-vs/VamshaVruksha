/** Best-effort English-to-Kannada spelling for names that have no Kannada name saved. */

/** Well-known words spelled the way Kannada readers expect. */
const WORDS: Record<string, string> = {
  shankarappa: 'ಶಂಕರಪ್ಪ', sagaramma: 'ಸಾಗರಮ್ಮ', sangappa: 'ಸಂಗಪ್ಪ', mallamma: 'ಮಲ್ಲಮ್ಮ', mahantappa: 'ಮಹಾಂತಪ್ಪ',
  parvatemma: 'ಪಾರ್ವತಮ್ಮ', parvathemma: 'ಪಾರ್ವತಮ್ಮ', savita: 'ಸವಿತಾ', manjula: 'ಮಂಜುಳಾ', chandru: 'ಚಂದ್ರು',
  vijayalaxmi: 'ವಿಜಯಲಕ್ಷ್ಮಿ', shivamma: 'ಶಿವಮ್ಮ', hanumareddy: 'ಹನುಮರೆಡ್ಡಿ', somaraja: 'ಸೋಮರಾಜ', venkappa: 'ವೆಂಕಪ್ಪ',
  virendra: 'ವೀರೇಂದ್ರ', vinod: 'ವಿನೋದ್', padma: 'ಪದ್ಮಾ', veerabhadrappa: 'ವೀರಭದ್ರಪ್ಪ', veerabhadra: 'ವೀರಭದ್ರ',
  chandrakala: 'ಚಂದ್ರಕಲಾ', shivakumar: 'ಶಿವಕುಮಾರ್', chennabasava: 'ಚನ್ನಬಸವ', ravi: 'ರವಿ', shakuntala: 'ಶಕುಂತಲಾ',
  annapoorna: 'ಅನ್ನಪೂರ್ಣ', savitri: 'ಸಾವಿತ್ರಿ', soumya: 'ಸೌಮ್ಯ', sangeeta: 'ಸಂಗೀತಾ', mallika: 'ಮಲ್ಲಿಕಾ',
  rekha: 'ರೇಖಾ', sahitya: 'ಸಾಹಿತ್ಯ', ritvik: 'ಋತ್ವಿಕ್', kushi: 'ಖುಷಿ', ivanshika: 'ಇವಾಂಶಿಕಾ', shruthi: 'ಶ್ರುತಿ',
  sushma: 'ಸುಷ್ಮಾ', vinayaka: 'ವಿನಾಯಕ', preethi: 'ಪ್ರೀತಿ', vijaykumar: 'ವಿಜಯಕುಮಾರ್', dayananda: 'ದಯಾನಂದ',
  anand: 'ಆನಂದ್', vinisha: 'ವಿನೀಶಾ', sharabanna: 'ಶರಬಣ್ಣ', eeshwaramma: 'ಈಶ್ವರಮ್ಮ', amma: 'ಅಮ್ಮ',
  amaregowda: 'ಅಮರೇಗೌಡ', basavarajeshwari: 'ಬಸವರಾಜೇಶ್ವರಿ', gundamma: 'ಗುಂಡಮ್ಮ', lakshmamma: 'ಲಕ್ಷ್ಮಮ್ಮ',
  aruna: 'ಅರುಣಾ', rishika: 'ರಿಷಿಕಾ', samarth: 'ಸಮರ್ಥ', neelamma: 'ನೀಲಮ್ಮ', reyansh: 'ರೇಯಾಂಶ್',
  konnapur: 'ಕೊನ್ನಾಪುರ', shankaragulli: 'ಶಂಕರಗುಳ್ಳಿ', hanamanagowda: 'ಹನುಮನಗೌಡ', sanaganagowda: 'ಸಂಗನಗೌಡ',
  sanganagowda: 'ಸಂಗನಗೌಡ', naganagowda: 'ನಾಗನಗೌಡ', sharanagowda: 'ಶರಣಗೌಡ', unknown: 'ಅಜ್ಞಾತ',
};

/** Endings that are best written whole; the rest of the word is spelled by the rules below. */
const ENDINGS: [string, string][] = [
  ['gowda', 'ಗೌಡ'], ['gouda', 'ಗೌಡ'], ['patil', 'ಪಾಟೀಲ'], ['kumari', 'ಕುಮಾರಿ'], ['kumar', 'ಕುಮಾರ್'], ['reddy', 'ರೆಡ್ಡಿ'],
  ['shetty', 'ಶೆಟ್ಟಿ'], ['swamy', 'ಸ್ವಾಮಿ'], ['laxmi', 'ಲಕ್ಷ್ಮಿ'], ['lakshmi', 'ಲಕ್ಷ್ಮಿ'], ['devi', 'ದೇವಿ'], ['appa', 'ಪ್ಪ'], ['amma', 'ಮ್ಮ'],
];

const VIRAMA = '್';
const CONSONANTS: [string, string][] = [
  ['ksh', 'ಕ್ಷ'], ['chh', 'ಛ'], ['kh', 'ಖ'], ['gh', 'ಘ'], ['ch', 'ಚ'], ['jh', 'ಝ'], ['th', 'ತ'], ['dh', 'ಧ'], ['ph', 'ಫ'], ['bh', 'ಭ'], ['sh', 'ಶ'],
  ['k', 'ಕ'], ['g', 'ಗ'], ['c', 'ಕ'], ['j', 'ಜ'], ['t', 'ತ'], ['d', 'ದ'], ['n', 'ನ'], ['p', 'ಪ'], ['f', 'ಫ'], ['b', 'ಬ'], ['m', 'ಮ'], ['y', 'ಯ'],
  ['r', 'ರ'], ['l', 'ಲ'], ['v', 'ವ'], ['w', 'ವ'], ['s', 'ಸ'], ['h', 'ಹ'], ['z', 'ಜ'], ['q', 'ಕ'], ['x', 'ಕ್ಷ'],
];
const VOWELS: [string, string, string][] = [
  ['aa', 'ಆ', 'ಾ'], ['ai', 'ಐ', 'ೈ'], ['au', 'ಔ', 'ೌ'], ['ou', 'ಔ', 'ೌ'], ['ow', 'ಔ', 'ೌ'], ['ee', 'ಈ', 'ೀ'], ['ii', 'ಈ', 'ೀ'],
  ['oo', 'ಊ', 'ೂ'], ['uu', 'ಊ', 'ೂ'], ['a', 'ಅ', ''], ['e', 'ಎ', 'ೆ'], ['i', 'ಇ', 'ಿ'], ['o', 'ಒ', 'ೊ'], ['u', 'ಉ', 'ು'],
];

type Token = { c: string; raw: string } | { v: [string, string] };

function tokenize(word: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < word.length) {
    const vowel = VOWELS.find(([key]) => word.startsWith(key, i));
    if (vowel) { tokens.push({ v: [vowel[1], vowel[2]] }); i += vowel[0].length; continue; }
    const consonant = CONSONANTS.find(([key]) => word.startsWith(key, i));
    if (consonant) { tokens.push({ c: consonant[1], raw: consonant[0] }); i += consonant[0].length; continue; }
    i += 1;
  }
  return tokens;
}

function spell(word: string): string {
  const tokens = tokenize(word);
  let out = '';
  let open = false;
  tokens.forEach((token, index) => {
    if ('v' in token) { out += open ? token.v[1] : token.v[0]; open = false; return; }
    const next = tokens[index + 1];
    const nasal = (token.raw === 'n' || token.raw === 'm') && !open && index > 0 && !!next && 'c' in next && next.raw !== 'n' && next.raw !== 'm' && next.raw !== 'y';
    if (nasal) { out += 'ಂ'; return; }
    if (open) out += VIRAMA;
    out += token.c;
    open = true;
  });
  return open ? out + VIRAMA : out;
}

function spellWord(word: string): string {
  const lower = word.toLowerCase();
  if (WORDS[lower]) return WORDS[lower];
  const ending = ENDINGS.find(([suffix]) => lower.endsWith(suffix) && (lower.length > suffix.length || (suffix !== 'appa' && suffix !== 'amma')));
  if (ending) {
    const head = spell(lower.slice(0, -ending[0].length));
    return (head.endsWith(VIRAMA) ? head.slice(0, -1) : head) + ending[1];
  }
  return spell(lower);
}

const cache = new Map<string, string>();

/** Spells English letters in Kannada; text that is already Kannada passes through unchanged. */
export function toKannada(text: string): string {
  const hit = cache.get(text);
  if (hit !== undefined) return hit;
  const result = text.replace(/[A-Za-z]+/g, spellWord);
  cache.set(text, result);
  return result;
}
