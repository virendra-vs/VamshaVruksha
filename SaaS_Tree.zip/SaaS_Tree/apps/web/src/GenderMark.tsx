import type { Person } from '@vamsha/shared';

/** Small, quiet line glyphs: ring with an arrow (male) or a cross (female). */
export function GenderMark({ gender, className = '' }: { gender: Person['gender']; className?: string }) {
  if (gender !== 'M' && gender !== 'F') return null;
  const label = gender === 'M' ? 'Male' : 'Female';
  return (
    <svg className={`gender-mark ${className}`} viewBox="0 0 16 16" width="11" height="11" role="img" aria-label={label} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <title>{label}</title>
      {gender === 'M'
        ? <><circle cx="6.5" cy="9.5" r="3.5" /><path d="M9.2 6.8 13 3M9.5 3H13v3.5" /></>
        : <><circle cx="8" cy="5.5" r="3.5" /><path d="M8 9v5M5.7 11.7h4.6" /></>}
    </svg>
  );
}
