import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { useFamily, useUi, type HistoryEntry } from './store';
import { num, serverText, t, useLang, useT } from './i18n';

function Modal({ title, children, onClose, wide }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  return (
    <div className="backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <header><h2>{title}</h2><button className="icon-btn" aria-label={t('Close')} onClick={onClose}><X size={18} /></button></header>
        {children}
      </div>
    </div>
  );
}

function LoginDialog({ onClose }: { onClose: () => void }) {
  const t = useT();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [working, setWorking] = useState(false);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setWorking(true);
    setError('');
    try { await useFamily.getState().login(password); onClose(); }
    catch (e) { setError(e instanceof Error ? serverText(e.message) : t('Sign in failed.')); }
    finally { setWorking(false); }
  };
  return (
    <Modal title={t('Admin sign in')} onClose={onClose}>
      <form className="form" onSubmit={(e) => void submit(e)}>
        <p className="muted">{t('Anyone can browse the tree. Only the admin can add people, edit details and manage backups.')}</p>
        <label className="field"><span>{t('Admin password')}</span><input type="password" autoFocus required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        {error && <p className="error" role="alert">{error}</p>}
        <div className="form-actions"><button type="button" className="btn ghost" onClick={onClose}>{t('Cancel')}</button><button className="btn gold" disabled={working}>{working ? t('Checking…') : t('Sign in')}</button></div>
      </form>
    </Modal>
  );
}

function PasswordDialog({ onClose }: { onClose: () => void }) {
  const t = useT();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [error, setError] = useState('');
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError('');
    try {
      await useFamily.getState().changePassword(current, next);
      useFamily.getState().notify(t('Password changed. Please sign in again.'));
      await useFamily.getState().logout();
      onClose();
    } catch (e) { setError(e instanceof Error ? serverText(e.message) : t('The password could not be changed.')); }
  };
  return (
    <Modal title={t('Change admin password')} onClose={onClose}>
      <form className="form" onSubmit={(e) => void submit(e)}>
        <label className="field"><span>{t('Current password')}</span><input type="password" required autoFocus autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} /></label>
        <label className="field"><span>{t('New password (10 characters or more)')}</span><input type="password" required minLength={10} autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} /></label>
        {error && <p className="error" role="alert">{error}</p>}
        <div className="form-actions"><button type="button" className="btn ghost" onClick={onClose}>{t('Cancel')}</button><button className="btn gold">{t('Change password')}</button></div>
      </form>
    </Modal>
  );
}

function ImportDialog({ onClose }: { onClose: () => void }) {
  const t = useT();
  const family = useFamily((s) => s.family)!;
  const busy = useFamily((s) => s.busy);
  const data = useUi((s) => s.importData);
  const [confirm, setConfirm] = useState('');
  if (!data) return null;
  const word = family.meta.surname;
  const ready = confirm.trim().toLowerCase() === word.toLowerCase();
  return (
    <Modal title={t('Restore from backup')} onClose={onClose}>
      <div className="form">
        <div className="compare">
          <div><small>{t('Current tree')}</small><b>{num(family.people.length)}</b><span>{t('people')}</span><b>{num(family.unions.length)}</b><span>{t('marriages')}</span></div>
          <div className="arrow" aria-hidden="true">→</div>
          <div><small>{t('Backup file')}</small><b>{num(data.family.people.length)}</b><span>{t('people')}</span><b>{num(data.family.unions.length)}</b><span>{t('marriages')}</span>{data.photos > 0 && <><b>{num(data.photos)}</b><span>{t('photos')}</span></>}</div>
        </div>
        <p className="muted">{t("This replaces the current tree with the backup. A copy of the current tree is kept in the server's rolling backups, and you can also export it first.")}</p>
        <label className="field"><span>{t('Type “{word}” to confirm', { word })}</span><input value={confirm} onChange={(e) => setConfirm(e.target.value)} /></label>
        <div className="form-actions">
          <button className="btn ghost" onClick={onClose}>{t('Cancel')}</button>
          <button className="btn gold" disabled={!ready || busy} onClick={async () => { await useFamily.getState().importBackup(data.raw); onClose(); }}>{busy ? t('Restoring…') : t('Replace tree')}</button>
        </div>
      </div>
    </Modal>
  );
}

function HistoryDialog({ onClose }: { onClose: () => void }) {
  const t = useT();
  const lang = useLang((s) => s.lang);
  const busy = useFamily((s) => s.busy);
  const [entries, setEntries] = useState<HistoryEntry[] | null>(null);
  const [error, setError] = useState('');
  const [confirm, setConfirm] = useState('');

  useEffect(() => {
    useFamily.getState().loadHistory().then(setEntries).catch((e: unknown) => setError(e instanceof Error ? serverText(e.message) : t('The history could not be loaded.')));
  }, []);

  const when = (savedAt: number) => new Date(savedAt).toLocaleString(lang === 'kn' ? 'kn-IN' : undefined, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
  const restore = async (entry: HistoryEntry) => {
    if (confirm !== entry.id) { setConfirm(entry.id); return; }
    if (await useFamily.getState().restoreVersion(entry.id)) onClose();
  };

  return (
    <Modal title={t('Version history')} onClose={onClose} wide>
      <p className="muted">{t('Every change keeps a copy of what came before. If something was removed by mistake, find the version that still has it and restore. Restoring itself can be undone from this list.')}</p>
      {error && <p className="error" role="alert">{error}</p>}
      {!entries && !error && <p className="muted">{t('Loading…')}</p>}
      {entries && entries.length === 0 && <p className="muted">{t('No earlier versions yet.')}</p>}
      <ul className="history">
        {entries?.map((entry) => (
          <li key={entry.id}>
            <div>
              <b>{t('Before the change at {when}', { when: when(entry.savedAt) })}</b>
              <small>{t('{people} people · {unions} marriages · {photos} photos', { people: entry.people, unions: entry.unions, photos: entry.photos })}</small>
              {entry.missingNow.length > 0 && <small className="plus">{t('Has people who are missing now: {names}', { names: entry.missingNow.join(', ') })}</small>}
              {entry.addedSince.length > 0 && <small className="minus">{t('Would remove people added since: {names}', { names: entry.addedSince.join(', ') })}</small>}
            </div>
            <button className={`btn ${confirm === entry.id ? 'gold' : 'soft'}`} disabled={busy} onClick={() => void restore(entry)}>{confirm === entry.id ? t('Click to confirm') : t('Restore')}</button>
          </li>
        ))}
      </ul>
    </Modal>
  );
}

export function Dialogs() {
  const dialog = useUi((s) => s.dialog);
  const close = () => useUi.getState().openDialog(null);
  if (dialog === 'history') return <HistoryDialog onClose={close} />;
  if (dialog === 'login') return <LoginDialog onClose={close} />;
  if (dialog === 'password') return <PasswordDialog onClose={close} />;
  if (dialog === 'import') return <ImportDialog onClose={close} />;
  return null;
}
