import { describe, expect, it } from 'vitest';
import { toKannada } from './translit';

describe('toKannada', () => {
  it('uses the well-known spelling for known names', () => {
    expect(toKannada('Shankaragulli')).toBe('ಶಂಕರಗುಳ್ಳಿ');
    expect(toKannada('Parvathemma')).toBe('ಪಾರ್ವತಮ್ಮ');
  });

  it('spells other names by rules, with nasals before consonants and endings kept whole', () => {
    expect(toKannada('Mahesh')).toBe('ಮಹೆಶ್');
    expect(toKannada('Sangappa')).toBe('ಸಂಗಪ್ಪ');
    expect(toKannada('Basavaraj Gowda')).toBe('ಬಸವರಜ್ ಗೌಡ');
  });

  it('leaves Kannada and punctuation unchanged', () => {
    expect(toKannada('ಶಿವಮ್ಮ (Shivi)')).toBe('ಶಿವಮ್ಮ (ಶಿವಿ)');
  });
});
