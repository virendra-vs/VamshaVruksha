import type { ReactNode } from 'react';
import type { MediaEventType } from '@vamsha/shared';
import { monthName, num, t, useT } from './i18n';

const EVENT_LABELS: Record<MediaEventType, string> = {
  birth: 'Birth', naming: 'Naming ceremony', birthday: 'Birthday', education: 'School and education', marriage: 'Marriage',
  festival: 'Festival', family: 'Family gathering', achievement: 'Achievement', memorial: 'Memorial', other: 'Other',
};
export const eventLabel = (type: MediaEventType) => t(EVENT_LABELS[type]);

export function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return <label className={`field ${wide ? 'wide' : ''}`}><span>{label}</span>{children}</label>;
}

/** Year, optional month, optional day: stores "1990", "1990-05" or "1990-05-12". */
export function DateField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  useT();
  const [year = '', month = '', day = ''] = value.split('-');
  const emit = (y: string, m: string, d: string) => onChange(!y ? '' : m ? (d ? `${y}-${m}-${d}` : `${y}-${m}`) : y);
  return (
    <div className="field wide">
      <span>{label}</span>
      <div className="date3">
        <input inputMode="numeric" placeholder={t('Year')} aria-label={t('{label} year', { label })} value={year} onChange={(e) => emit(e.target.value.replace(/\D/g, '').slice(0, 4), month, day)} />
        <select aria-label={t('{label} month', { label })} value={month} onChange={(e) => emit(year, e.target.value, e.target.value ? day : '')} disabled={year.length !== 4}>
          <option value="">{t('Month')}</option>
          {Array.from({ length: 12 }, (_, i) => <option key={i} value={String(i + 1).padStart(2, '0')}>{monthName(i)}</option>)}
        </select>
        <select aria-label={t('{label} day', { label })} value={day} onChange={(e) => emit(year, month, e.target.value)} disabled={!month}>
          <option value="">{t('Day')}</option>
          {Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, '0')).map((d) => <option key={d} value={d}>{num(Number(d))}</option>)}
        </select>
      </div>
    </div>
  );
}
