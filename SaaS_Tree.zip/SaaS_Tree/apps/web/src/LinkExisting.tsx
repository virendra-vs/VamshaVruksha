import { useMemo, useState, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { fullName, getRelatives, knownAs, type Command, type Family, type Person } from '@vamsha/shared';
import { useFamily } from './store';
import { birthNameNoteL, fullNameL, givenL, t, useT } from './i18n';
import { isPlaceholder } from './theme';
import { Avatar } from './Avatar';

/** "Son of A & B" or "Wife of C": tells apart people who share a name. */
export function describePerson(family: Family, person: Person): string {
  const rel = getRelatives(family, person.id);
  const parents = rel.parents.map((p) => givenL(p)).join(' & ');
  const note = birthNameNoteL(person);
  let text = '';
  if (parents) text = t(person.gender === 'F' ? 'Daughter of {parents}' : person.gender === 'M' ? 'Son of {parents}' : 'Child of {parents}', { parents });
  else {
    const spouse = rel.spouses.find((s) => s.person)?.person;
    if (spouse) text = t(person.gender === 'F' ? 'Wife of {name}' : person.gender === 'M' ? 'Husband of {name}' : 'Partner of {name}', { name: givenL(spouse) });
  }
  return [note, text].filter(Boolean).join(' · ');
}

interface Props {
  person: Person;
  kind: 'spouse' | 'child' | 'parent' | 'sibling' | 'merge';
  blocked: Set<string>;
  busy: boolean;
  onCancel: () => void;
  build: (picked: Person, options: { takesName: boolean }) => Command;
  onSubmit: (command: Command) => void;
  extra?: ReactNode;
}

const TARGET: Record<Exclude<Props['kind'], 'merge'>, string> = {
  spouse: 'Link {a} as a spouse of {b}.', child: 'Link {a} as a child of {b}.', parent: 'Link {a} as a parent of {b}.', sibling: 'Link {a} as a sibling of {b}.',
};

/** Link someone who is already in the tree, so nobody is entered twice. */
export function LinkExisting({ person, kind, blocked, busy, onCancel, build, onSubmit, extra }: Props) {
  const t = useT();
  const family = useFamily((s) => s.family)!;
  const [query, setQuery] = useState('');
  const [picked, setPicked] = useState<Person | null>(null);
  const [takesName, setTakesName] = useState(true);

  const matches = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return [];
    return family.people
      .filter((p) => p.id !== person.id && !blocked.has(p.id) && !isPlaceholder(p)
        && `${fullName(p)} ${fullNameL(p)} ${p.name.birthSurname ?? ''} ${knownAs(p).join(' ')} ${p.name.localScript?.kn ?? ''}`.toLowerCase().includes(needle))
      .sort((a, b) => Number(!a.name.given.toLowerCase().startsWith(needle)) - Number(!b.name.given.toLowerCase().startsWith(needle)) || fullName(a).localeCompare(fullName(b)))
      .slice(0, 8);
  }, [query, family.people, blocked, person.id]);

  const showTakesName = kind === 'spouse' && person.gender === 'F' && picked?.gender === 'M' && !!picked.name.surname;

  return (
    <form className="form" onSubmit={(e) => { e.preventDefault(); if (picked) onSubmit(build(picked, { takesName })); }}>
      {!picked ? (
        <div className="field wide">
          <span>{t('Find the person')}</span>
          <input autoFocus placeholder={t('Type a name, nickname or maiden name')} value={query} onChange={(e) => setQuery(e.target.value)} />
          {matches.length > 0 && (
            <div className="pick-list">
              {matches.map((p) => (
                <button type="button" key={p.id} onClick={() => setPicked(p)}>
                  <Avatar person={p} size="sm" />
                  <span className="pick-text"><b>{fullNameL(p)}</b><small>{describePerson(family, p) || t('No relatives linked yet')}</small></span>
                </button>
              ))}
            </div>
          )}
          {query.trim() && matches.length === 0 && <p className="muted">{t('No one matches. People already linked in that way are hidden.')}</p>}
        </div>
      ) : (
        <div className="picked">
          <Avatar person={picked} size="md" />
          <div><b>{fullNameL(picked)}</b><small>{describePerson(family, picked) || t('No relatives linked yet')}</small></div>
          <button type="button" className="icon-btn" aria-label={t('Choose someone else')} onClick={() => setPicked(null)}><X size={16} /></button>
        </div>
      )}
      {picked && kind === 'merge' && <p className="muted">{t("{a}'s relatives, photos and any missing details move to {b}, then {a} is removed. You can undo this right after.", { a: givenL(picked), b: givenL(person) })}</p>}
      {picked && kind !== 'merge' && <p className="muted">{t(TARGET[kind], { a: givenL(picked), b: givenL(person) })} {t('This adds a connection only; no one is duplicated.')}</p>}
      {extra}
      {showTakesName && (
        <label className="check"><input type="checkbox" checked={takesName} onChange={(e) => setTakesName(e.target.checked)} />{t('{name} takes the surname “{surname}”', { name: givenL(person), surname: picked?.name.surname ?? '' })}</label>
      )}
      <div className="form-actions">
        <button type="button" className="btn ghost" onClick={onCancel}>{t('Cancel')}</button>
        <button type="submit" className="btn gold" disabled={!picked || busy}>{busy ? t('Saving…') : kind === 'merge' ? t('Merge') : t('Link')}</button>
      </div>
    </form>
  );
}
