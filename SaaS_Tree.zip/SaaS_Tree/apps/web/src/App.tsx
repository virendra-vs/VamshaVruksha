import { useEffect } from 'react';
import { Flower2, Gem, Heart, HeartCrack, X } from 'lucide-react';
import { ReactFlowProvider } from '@xyflow/react';
import { useFamily, useUi } from './store';
import { TopBar } from './TopBar';
import { TreeCanvas } from './tree/TreeCanvas';
import { PersonPanel } from './PersonPanel';
import { GhostPanel } from './GhostPanel';
import { BRANCH_COLORS } from './theme';
import { Dialogs } from './Dialogs';
import { GenderMark } from './GenderMark';
import { useT } from './i18n';

function Legend() {
  const t = useT();
  const open = useUi((state) => state.legendOpen);
  if (!open) return null;
  return (
    <div className="legend" role="dialog" aria-label={t('Legend')}>
      <button className="icon-btn close" aria-label={t('Close legend')} onClick={() => useUi.getState().toggleLegend()}><X size={15} /></button>
      <ul>
        <li><Heart size={13} fill="currentColor" className="gold" /> {t('Married')}</li>
        <li><HeartCrack size={13} /> {t('Divorced or separated')}</li>
        <li><Heart size={13} className="silver" /> {t('Widowed')}</li>
        <li><span className="swatch-ring"><Gem size={9} /></span> {t('Married into the family')}</li>
        <li><GenderMark gender="M" /> {t('Man')}</li>
        <li><GenderMark gender="F" /> {t('Woman')}</li>
        <li><Flower2 size={13} className="silver" /> {t('Late (passed away)')}</li>
        <li><span className="line-sample dashed" /> {t('Adopted, step or foster child')}</li>
        <li><span className="line-sample" style={{ borderColor: 'var(--gold)' }} /> {t('Founders')}</li>
        <li className="swatches">{BRANCH_COLORS.slice(0, 5).map((color) => <i key={color} style={{ background: color }} />)} {t('Branches')}</li>
      </ul>
    </div>
  );
}

function Toast() {
  const toast = useFamily((state) => state.toast);
  useEffect(() => {
    if (!toast) return undefined;
    const timer = window.setTimeout(() => useFamily.getState().notify(null), 5000);
    return () => window.clearTimeout(timer);
  }, [toast]);
  if (!toast) return null;
  return <div className="toast" role="status">{toast}</div>;
}

export default function App() {
  const t = useT();
  const family = useFamily((state) => state.family);
  const error = useFamily((state) => state.error);

  useEffect(() => { void useFamily.getState().checkSession().then(() => useFamily.getState().load()); }, []);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const typing = (event.target as HTMLElement | null)?.closest('input, select, textarea');
      if (event.key === 'Escape') useUi.getState().select(null);
      if (typing) return;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' && useFamily.getState().admin) {
        event.preventDefault();
        void (event.shiftKey ? useFamily.getState().redo() : useFamily.getState().undo());
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  if (error) return <div className="state"><h1>{t("We couldn't open the family")}</h1><p>{error}</p><button className="btn gold" onClick={() => void useFamily.getState().load()}>{t('Try again')}</button></div>;
  if (!family) return <div className="state"><div className="spinner" aria-label={t('Loading')} /></div>;

  return (
    <ReactFlowProvider>
      <div className="app">
        <TreeCanvas />
        <TopBar />
        <Legend />
        <PersonPanel />
        <GhostPanel />
        <Dialogs />
        <Toast />
      </div>
    </ReactFlowProvider>
  );
}
