import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { ancestorIds, descendantIds, type Command } from '@vamsha/shared';
import { useFamily, useUi } from './store';
import { fullNameL, useT } from './i18n';
import { Chip, QuickAdd } from './PersonPanel';
import { LinkExisting } from './LinkExisting';

/** Opens when an "Unknown" partner card is clicked, so the marriage and children can be reconnected to a real person. */
export function GhostPanel() {
  const t = useT();
  const unionId = useUi((s) => s.ghostUnionId);
  const family = useFamily((s) => s.family);
  const admin = useFamily((s) => s.admin);
  const busy = useFamily((s) => s.busy);
  const run = useFamily((s) => s.run);
  const [source, setSource] = useState<'new' | 'existing'>('new');
  useEffect(() => setSource('new'), [unionId]);

  const union = family?.unions.find((entry) => entry.id === unionId);
  if (!family || !union || !union.partners.includes(null)) return null;
  const known = family.people.find((p) => p.id === union.partners.find(Boolean)) ?? null;
  const children = union.children.flatMap((c) => family.people.find((p) => p.id === c.personId) ?? []);
  const close = () => useUi.getState().select(null);

  const exec = async (command: Command) => {
    const id = await run(command);
    if (id) useUi.getState().select(id, true);
  };
  const blocked = known ? new Set([known.id, ...ancestorIds(family, known.id), ...descendantIds(family, known.id), ...union.children.map((c) => c.personId)]) : new Set<string>();

  return (
    <aside className="panel" aria-label={t('Unknown partner')}>
      <header className="panel-head">
        <div className="portrait"><span className="pic lg"><span className="initial">?</span></span></div>
        <div className="panel-title">
          <h2>{t('Unknown partner')}</h2>
          {known && <div className="names-sub"><span>{t('of {name}', { name: fullNameL(known) })}</span></div>}
        </div>
        <button className="icon-btn" aria-label={t('Close')} onClick={close}><X size={18} /></button>
      </header>
      <div className="body">
        {children.length > 0 && <section><h3>{t('Their children')}</h3><div className="chips">{children.map((c) => <Chip key={c.id} person={c} />)}</div></section>}
        {!admin && <p className="muted">{t('This partner has not been recorded yet.')}</p>}
        {admin && known && (
          <>
            <p className="muted">{t(children.length ? 'Who is this? Fill in the partner and the children stay connected to them. Use someone already in the tree if they exist, so nobody is entered twice.' : 'Who is this? Fill in the partner and the marriage is completed. Use someone already in the tree if they exist, so nobody is entered twice.')}</p>
            <div className="seg two" role="radiogroup" aria-label={t('Who to add')}>
              <button type="button" role="radio" aria-checked={source === 'new'} className={source === 'new' ? 'on' : ''} onClick={() => setSource('new')}>{t('New person')}</button>
              <button type="button" role="radio" aria-checked={source === 'existing'} className={source === 'existing' ? 'on' : ''} onClick={() => setSource('existing')}>{t('Already in the tree')}</button>
            </div>
            {source === 'existing' ? (
              <LinkExisting
                person={known}
                kind="spouse"
                blocked={blocked}
                busy={busy}
                onCancel={close}
                build={(picked, { takesName }) => ({ type: 'fillPartner', unionId: union.id, personId: picked.id, anchorSurname: known.gender === 'F' && picked.gender === 'M' && takesName && picked.name.surname ? picked.name.surname : undefined })}
                onSubmit={(command) => void exec(command)}
              />
            ) : (
              <QuickAdd
                initial={{ given: '', surname: known.gender === 'M' ? known.name.surname ?? '' : '', gender: known.gender === 'F' ? 'M' : 'F' }}
                spouseOf={known}
                submitLabel={busy ? t('Saving…') : t('Fill in partner')}
                onCancel={close}
                onSubmit={(v) => void exec({
                  type: 'fillPartner', unionId: union.id,
                  person: { given: v.given.trim(), surname: v.surname.trim() || null, birthSurname: v.gender === 'F' ? v.birthSurname.trim() || null : null, gender: v.gender, isLiving: true, birthYear: /^\d{4}$/.test(v.birthYear) ? v.birthYear : null },
                  anchorSurname: known.gender === 'F' && v.gender === 'M' && v.takesName && v.surname.trim() ? v.surname.trim() : undefined,
                })}
              />
            )}
          </>
        )}
      </div>
    </aside>
  );
}
