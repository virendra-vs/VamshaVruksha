import { create } from 'zustand';
import { FamilySchema, getRelatives, type Command, type Family, type MediaEventType } from '@vamsha/shared';
import { registerFamilyName, serverText, t } from './i18n';

const BASE = '/api/v1/tenants/t-shankaragulli/families/fam-shankaragulli';
export const mediaUrl = (id: string, size: 'thumb' | 'medium') => `${BASE}/media/${id}/${size}`;

export interface GalleryUpload {
  medium: string; thumb: string; width: number; height: number;
  caption?: string | null; eventType: MediaEventType; date?: string | null; personIds: string[];
}

export class ApiError extends Error {
  constructor(public status: number, message: string, public code?: string) { super(message); }
}

async function call(url: string, method: string, body?: unknown, version?: number) {
  const response = await fetch(url, {
    method,
    headers: {
      'x-vamsha-csrf': '1',
      ...(body === undefined ? {} : { 'content-type': 'application/json' }),
      ...(version ? { 'if-match': String(version) } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) throw new ApiError(response.status, data?.message ?? 'Something went wrong.', data?.code);
  return data;
}
const request = (method: string, path: string, body?: unknown, version?: number) => call(`${BASE}${path}`, method, body, version);

type Snapshot = Pick<Family, 'people' | 'unions' | 'media'>;
const snapshotOf = (family: Family): Snapshot => ({ people: family.people, unions: family.unions, media: family.media });

export interface HistoryEntry {
  id: string; savedAt: number; dataVersion: number; people: number; unions: number; photos: number;
  missingNow: string[]; addedSince: string[];
}

interface FamilyState {
  family: Family | null;
  admin: boolean;
  error: string | null;
  past: Snapshot[];
  future: Snapshot[];
  busy: boolean;
  toast: string | null;
  load: () => Promise<void>;
  checkSession: () => Promise<void>;
  login: (password: string) => Promise<void>;
  logout: () => Promise<void>;
  changePassword: (current: string, next: string) => Promise<void>;
  run: (command: Command) => Promise<string | undefined>;
  undo: () => Promise<void>;
  redo: () => Promise<void>;
  setPhoto: (personId: string, photo: { medium: string; thumb: string } | null) => Promise<void>;
  addGalleryPhoto: (photo: GalleryUpload) => Promise<boolean>;
  loadHistory: () => Promise<HistoryEntry[]>;
  restoreVersion: (id: string) => Promise<boolean>;
  exportBackup: () => Promise<void>;
  importBackup: (payload: unknown) => Promise<void>;
  notify: (message: string | null) => void;
}

export const useFamily = create<FamilyState>((set, get) => {
  /** Runs a change; any failure becomes a friendly toast and a signed-out state on 401. */
  async function guarded<T>(action: () => Promise<T>, fallback: string): Promise<T | undefined> {
    if (get().busy) return undefined;
    set({ busy: true });
    try {
      return await action();
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        set({ admin: false, past: [], future: [], toast: t('Your admin session ended. Sign in again to keep editing.') });
        await get().load();
      } else if (error instanceof ApiError && error.status === 409) {
        await get().load();
        set({ toast: t('The family was changed elsewhere. It has been reloaded; please try again.') });
      } else {
        set({ toast: error instanceof Error ? serverText(error.message) : t(fallback) });
      }
      return undefined;
    } finally {
      set({ busy: false });
    }
  }

  const apply = (family: unknown, extra: Partial<FamilyState> = {}) => {
    const parsed = FamilySchema.parse(family);
    registerFamilyName(parsed.meta.surname, (parsed.meta.localName as { kn?: string } | null | undefined)?.kn);
    set({ family: parsed, ...extra });
  };

  return {
    family: null, admin: false, error: null, past: [], future: [], busy: false, toast: null,
    notify: (toast) => set({ toast }),

    async load() {
      try { apply(await request('GET', ''), { error: null }); }
      catch (error) { set({ error: error instanceof Error ? serverText(error.message) : t('Unable to load the family.') }); }
    },
    async checkSession() {
      try { set({ admin: (await call('/api/v1/auth/session', 'GET')).admin === true }); } catch { set({ admin: false }); }
    },
    async login(password) {
      await call('/api/v1/auth/login', 'POST', { password });
      set({ admin: true, past: [], future: [] });
      await get().load();
    },
    async logout() {
      await call('/api/v1/auth/logout', 'POST', {});
      set({ admin: false, past: [], future: [] });
      await get().load();
    },
    async changePassword(current, next) { await call('/api/v1/auth/change-password', 'POST', { current, next }); },

    async run(command) {
      const { family, past } = get();
      if (!family) return undefined;
      const data = await guarded(async () => {
        const result = await request('POST', '/commands', { command }, family.meta.dataVersion);
        apply(result.family, { past: [...past, snapshotOf(family)].slice(-50), future: [] });
        return result;
      }, 'The change could not be saved.');
      return data ? ((data.focusId as string | undefined) ?? '') : undefined;
    },
    async undo() {
      const { family, past, future } = get();
      const previous = past[past.length - 1];
      if (!family || !previous) return;
      await guarded(async () => {
        apply((await request('PUT', '/graph', previous, family.meta.dataVersion)).family, { past: past.slice(0, -1), future: [snapshotOf(family), ...future] });
      }, 'Undo failed.');
    },
    async redo() {
      const { family, past, future } = get();
      const next = future[0];
      if (!family || !next) return;
      await guarded(async () => {
        apply((await request('PUT', '/graph', next, family.meta.dataVersion)).family, { future: future.slice(1), past: [...past, snapshotOf(family)] });
      }, 'Redo failed.');
    },
    async setPhoto(personId, photo) {
      const { family } = get();
      if (!family) return;
      await guarded(async () => {
        const result = photo
          ? await request('PUT', `/people/${personId}/photo`, photo, family.meta.dataVersion)
          : await request('DELETE', `/people/${personId}/photo`, undefined, family.meta.dataVersion);
        apply(result.family);
      }, 'The photo could not be saved.');
    },
    async addGalleryPhoto(photo) {
      const { family, past } = get();
      if (!family) return false;
      const result = await guarded(async () => {
        const data = await request('POST', '/gallery', photo, family.meta.dataVersion);
        apply(data.family, { past: [...past, snapshotOf(family)].slice(-50), future: [] });
        return data;
      }, 'The photo could not be uploaded.');
      return !!result;
    },
    async loadHistory() {
      const data = await request('GET', '/history');
      return data.entries as HistoryEntry[];
    },
    async restoreVersion(id) {
      const { family } = get();
      if (!family) return false;
      const result = await guarded(async () => {
        const data = await request('POST', `/history/${id}/restore`, undefined, family.meta.dataVersion);
        apply(data.family, { past: [], future: [], toast: t('Version restored. You can restore the previous state from Version history if needed.') });
        return data;
      }, 'That version could not be restored.');
      return !!result;
    },
    async exportBackup() {
      await guarded(async () => {
        const data = await request('GET', '/export');
        const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `vamsha-backup-${new Date().toISOString().slice(0, 10)}.json`;
        link.click();
        URL.revokeObjectURL(link.href);
      }, 'The backup could not be created.');
    },
    async importBackup(payload) {
      const { family } = get();
      if (!family) return;
      await guarded(async () => {
        const result = await request('POST', '/import', payload, family.meta.dataVersion);
        apply(result.family, { past: [], future: [], toast: t("Backup restored. The previous tree is kept in the server's write backups.") });
      }, 'The backup could not be imported.');
    },
  };
});

type Dialog = null | 'login' | 'import' | 'password' | 'history';

interface UiState {
  selectedId: string | null;
  /** An "Unknown" partner slot that is selected instead of a person. */
  ghostUnionId: string | null;
  focus: Set<string> | null;
  legendOpen: boolean;
  dialog: Dialog;
  importData: { family: Family; raw: unknown; photos: number } | null;
  centerTick: number;
  select: (id: string | null, center?: boolean) => void;
  selectGhost: (unionId: string) => void;
  toggleLegend: () => void;
  openDialog: (dialog: Dialog, importData?: UiState['importData']) => void;
}

export const useUi = create<UiState>((set) => ({
  selectedId: null, ghostUnionId: null, focus: null, legendOpen: false, dialog: null, importData: null, centerTick: 0,
  selectGhost: (unionId) => set({ selectedId: null, focus: null, ghostUnionId: unionId }),
  select(id, center = false) {
    const family = useFamily.getState().family;
    if (!id || !family) { set({ selectedId: null, focus: null, ghostUnionId: null }); return; }
    const rel = getRelatives(family, id);
    const focus = new Set<string>([id, ...rel.parents.map((p) => p.id), ...rel.siblings.map((p) => p.id), ...rel.children.map((c) => c.person.id)]);
    for (const spouse of rel.spouses) if (spouse.person) focus.add(spouse.person.id);
    set((state) => ({ selectedId: id, ghostUnionId: null, focus, centerTick: center ? state.centerTick + 1 : state.centerTick }));
  },
  toggleLegend: () => set((state) => ({ legendOpen: !state.legendOpen })),
  openDialog: (dialog, importData = null) => set({ dialog, importData }),
}));

type Theme = 'light' | 'dark';
const savedTheme = (): Theme => {
  const stored = localStorage.getItem('vamsha-theme');
  if (stored === 'light' || stored === 'dark') return stored;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};

export const THEME_COLORS: Record<Theme, string> = { light: '#F4F0E8', dark: '#0E1020' };

function applyTheme(theme: Theme) {
  document.documentElement.dataset.theme = theme;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', THEME_COLORS[theme]);
}

export const useTheme = create<{ theme: Theme; toggle: () => void }>((set, get) => {
  const initial = savedTheme();
  applyTheme(initial);
  return {
    theme: initial,
    toggle() {
      const next: Theme = get().theme === 'dark' ? 'light' : 'dark';
      localStorage.setItem('vamsha-theme', next);
      applyTheme(next);
      set({ theme: next });
    },
  };
});
