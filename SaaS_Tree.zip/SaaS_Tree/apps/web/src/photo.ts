import { t } from './i18n';

const readAsDataUrl = (blob: Blob) => new Promise<string>((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result));
  reader.onerror = () => reject(reader.error);
  reader.readAsDataURL(blob);
});

function render(bitmap: ImageBitmap, side: number, quality: number): Promise<string> {
  const canvas = document.createElement('canvas');
  canvas.width = side;
  canvas.height = side;
  const context = canvas.getContext('2d')!;
  const crop = Math.min(bitmap.width, bitmap.height);
  context.fillStyle = '#fff';
  context.fillRect(0, 0, side, side);
  context.drawImage(bitmap, (bitmap.width - crop) / 2, (bitmap.height - crop) / 2, crop, crop, 0, 0, side, side);
  return new Promise((resolve, reject) => canvas.toBlob((blob) => (blob ? readAsDataUrl(blob).then(resolve, reject) : reject(new Error(t('Could not process that photo.')))), 'image/jpeg', quality));
}

/** Centre-crops to a square and re-encodes as JPEG, which also removes EXIF and GPS data. */
export async function preparePhoto(file: File): Promise<{ medium: string; thumb: string }> {
  if (!file.type.startsWith('image/')) throw new Error(t('Please choose an image file.'));
  if (file.size > 25 * 1024 * 1024) throw new Error(t('That image is too large.'));
  const bitmap = await createImageBitmap(file);
  try {
    const [medium, thumb] = await Promise.all([render(bitmap, 640, 0.86), render(bitmap, 160, 0.82)]);
    return { medium, thumb };
  } finally {
    bitmap.close();
  }
}

function renderFit(bitmap: ImageBitmap, longest: number, quality: number): Promise<{ data: string; width: number; height: number }> {
  const scale = Math.min(1, longest / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d')!;
  context.fillStyle = '#fff';
  context.fillRect(0, 0, width, height);
  context.drawImage(bitmap, 0, 0, width, height);
  return new Promise((resolve, reject) => canvas.toBlob(
    (blob) => (blob ? readAsDataUrl(blob).then((data) => resolve({ data, width, height }), reject) : reject(new Error(t('Could not process that photo.')))),
    'image/jpeg', quality,
  ));
}

/** Keeps the whole picture (no crop), at most 1600px for viewing and 360px for the grid. Re-encoding removes EXIF/GPS. */
export async function prepareGalleryPhoto(file: File): Promise<{ medium: string; thumb: string; width: number; height: number }> {
  if (!file.type.startsWith('image/')) throw new Error(t('{name} is not an image.', { name: file.name }));
  if (file.size > 40 * 1024 * 1024) throw new Error(t('{name} is too large.', { name: file.name }));
  const bitmap = await createImageBitmap(file);
  try {
    let medium = await renderFit(bitmap, 1600, 0.82);
    if (medium.data.length > 2_400_000) medium = await renderFit(bitmap, 1400, 0.68);
    const thumb = await renderFit(bitmap, 360, 0.78);
    return { medium: medium.data, thumb: thumb.data, width: medium.width, height: medium.height };
  } finally {
    bitmap.close();
  }
}
