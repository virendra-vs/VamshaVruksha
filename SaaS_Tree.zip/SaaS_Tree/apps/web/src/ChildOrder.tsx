import { ChevronDown, ChevronUp } from 'lucide-react';
import { orderedChildren } from '@vamsha/shared';
import { givenL, ordinalL, useT } from './i18n';
import { useFamily } from './store';
import { Avatar } from './Avatar';

/** Eldest-first list of one marriage's children, with arrows to correct the order. */
export function ChildOrder({ unionId, title, currentId }: { unionId: string; title: string; currentId?: string }) {
  const t = useT();
  const family = useFamily((s) => s.family)!;
  const busy = useFamily((s) => s.busy);
  const run = useFamily((s) => s.run);
  const union = family.unions.find((u) => u.id === unionId);
  if (!union || union.children.length < 2) return null;

  const people = orderedChildren(union).flatMap((link) => family.people.find((p) => p.id === link.personId) ?? []);
  const move = (index: number, delta: -1 | 1) => {
    const ids = people.map((p) => p.id);
    [ids[index], ids[index + delta]] = [ids[index + delta], ids[index]];
    void run({ type: 'reorderChildren', unionId, personIds: ids });
  };

  return (
    <div className="order">
      <b>{title}</b>
      <ol>
        {people.map((p, i) => (
          <li key={p.id} className={p.id === currentId ? 'me' : ''}>
            <span className="ord">{ordinalL(i + 1)}</span>
            <Avatar person={p} size="sm" />
            <span className="chip-name">{givenL(p)}</span>
            <button type="button" className="icon-btn" aria-label={t('Move {name} earlier', { name: p.name.given })} disabled={i === 0 || busy} onClick={() => move(i, -1)}><ChevronUp size={16} /></button>
            <button type="button" className="icon-btn" aria-label={t('Move {name} later', { name: p.name.given })} disabled={i === people.length - 1 || busy} onClick={() => move(i, 1)}><ChevronDown size={16} /></button>
          </li>
        ))}
      </ol>
    </div>
  );
}
