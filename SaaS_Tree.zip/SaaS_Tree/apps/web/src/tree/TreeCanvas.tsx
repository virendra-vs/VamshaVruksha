import { useEffect, useMemo } from 'react';
import { Background, BackgroundVariant, Controls, MiniMap, ReactFlow, ViewportPortal, useReactFlow, useViewport, type Node, type ReactFlowInstance } from '@xyflow/react';
import { defaultLayoutOptions, layoutFamily, type LayoutEdge, type LayoutRow } from '@vamsha/shared';
import { useFamily, useTheme, useUi } from '../store';
import { num, useT } from '../i18n';
import { branchColor, branchHex } from '../theme';
import { nodeTypes, type TreeNodeData } from './nodes';

function Lines({ edges }: { edges: LayoutEdge[] }) {
  const selectedId = useUi((state) => state.selectedId);
  return (
    <ViewportPortal>
      <svg className="lines" width="1" height="1">
        {edges.map((edge) => {
          const state = !selectedId ? 'idle' : edge.involves.includes(selectedId) ? 'active' : 'dim';
          return (
            <path
              key={edge.id}
              d={edge.path}
              className={`line ${edge.kind} ${state}`}
              strokeDasharray={edge.dashed ? '6 5' : undefined}
              style={{ stroke: edge.kind === 'marriage' ? 'var(--gold)' : branchColor(edge.branch), '--line': edge.kind === 'marriage' ? 'var(--gold)' : branchColor(edge.branch) } as React.CSSProperties}
            />
          );
        })}
      </svg>
    </ViewportPortal>
  );
}

function GenerationLabels({ rows }: { rows: LayoutRow[] }) {
  useT();
  const { y, zoom } = useViewport();
  return (
    <div className="gen-labels" aria-hidden="true">
      {rows.map((row, index) => (
        <span key={row.row} style={{ top: y + (row.y + defaultLayoutOptions.cardH / 2) * zoom }}>{num(index + 1)}</span>
      ))}
    </div>
  );
}

export function TreeCanvas() {
  const t = useT();
  const family = useFamily((state) => state.family)!;
  const centerTick = useUi((state) => state.centerTick);
  const { setCenter, getZoom } = useReactFlow();
  const layout = useMemo(() => layoutFamily(family), [family]);
  const theme = useTheme((state) => state.theme);

  const openingView = (instance: ReactFlowInstance<Node<TreeNodeData>>) => {
    const rows = new Set(layout.rows.slice(0, 3).map((row) => row.row));
    const ids = layout.nodes.filter((node) => rows.has(node.row)).map((node) => ({ id: node.id }));
    void instance.fitView({ nodes: ids, padding: 0.12, minZoom: 0.55, maxZoom: 1, duration: 0 });
  };

  const nodes = useMemo(() => {
    const people = new Map(family.people.map((person) => [person.id, person]));
    const bands: Node<TreeNodeData>[] = layout.rows.map((row, index) => ({
      id: `band:${row.row}`, type: 'band', position: { x: layout.bounds.minX - 120, y: row.y - 38 },
      width: layout.bounds.maxX - layout.bounds.minX + 240, height: defaultLayoutOptions.cardH + 76,
      zIndex: -1, selectable: false, draggable: false, focusable: false, data: { layout: layout.nodes[0], even: index % 2 === 0 },
    }));
    const cards: Node<TreeNodeData>[] = layout.nodes.map((node) => ({
      id: node.id, type: node.kind, position: { x: node.x, y: node.y }, width: node.w, height: node.h,
      draggable: false, selectable: false, focusable: node.kind === 'person' || node.kind === 'ref',
      data: { layout: node, person: node.personId ? people.get(node.personId) : undefined },
    }));
    return [...bands, ...cards];
  }, [layout, family.people]);

  useEffect(() => {
    if (!centerTick) return;
    const { selectedId } = useUi.getState();
    const target = layout.nodes.find((node) => node.kind === 'person' && node.personId === selectedId);
    if (!target) return;
    const zoom = Math.max(getZoom(), 0.85);
    const panelShift = window.innerWidth > 900 ? 200 / zoom : 0;
    void setCenter(target.x + target.w / 2 + panelShift, target.y + target.h / 2, { zoom, duration: 600 });
  }, [centerTick, layout, setCenter, getZoom]);

  return (
    <div className="canvas">
      <ReactFlow
        nodes={nodes}
        edges={[]}
        nodeTypes={nodeTypes}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable={false}
        onlyRenderVisibleElements
        onInit={openingView}
        minZoom={0.06}
        maxZoom={2.2}
        zoomOnDoubleClick={false}
        ariaLabelConfig={{ 'controls.ariaLabel': t('Zoom controls'), 'controls.zoomIn.ariaLabel': t('Zoom in'), 'controls.zoomOut.ariaLabel': t('Zoom out'), 'controls.fitView.ariaLabel': t('Fit view') }}
        onNodeClick={(_, node) => {
          const { layout: item } = node.data as TreeNodeData;
          if (node.type === 'ghost' && item.unionId) useUi.getState().selectGhost(item.unionId);
          else if (item.personId) useUi.getState().select(item.personId, node.type === 'ref');
        }}
        onPaneClick={() => useUi.getState().select(null)}
      >
        <Background variant={BackgroundVariant.Dots} gap={32} size={1} color={theme === 'dark' ? 'rgba(212,175,92,0.10)' : 'rgba(80,60,20,0.12)'} />
        <Lines edges={layout.edges} />
        <GenerationLabels rows={layout.rows} />
        <Controls showInteractive={false} position="bottom-left" />
        <MiniMap
          position="bottom-right"
          pannable
          zoomable
          nodeColor={(node) => (node.type === 'band' || node.type === 'union' ? 'transparent' : branchHex((node.data as TreeNodeData).layout.branch, theme))}
          maskColor={theme === 'dark' ? 'rgba(8,9,22,0.72)' : 'rgba(244,240,232,0.72)'}
        />
      </ReactFlow>
    </div>
  );
}
