import { memo, type CSSProperties } from 'react';
import { useStore, type Node, type NodeProps } from '@xyflow/react';
import { Flower2, Gem, Heart, HeartCrack, CornerUpRight } from 'lucide-react';
import type { LayoutNode, Person } from '@vamsha/shared';
import { fullName } from '@vamsha/shared';
import { useFamily, useUi } from '../store';
import { birthLabel, fullNameL, givenL, t, useT } from '../i18n';
import { GenderMark } from '../GenderMark';
import { Avatar } from '../Avatar';
import { branchColor, isLate, isPlaceholder, lifeSpan } from '../theme';

export interface TreeNodeData extends Record<string, unknown> {
  layout: LayoutNode;
  person?: Person;
  even?: boolean;
}

type TreeNode = Node<TreeNodeData>;

const RELATION_LABEL: Record<string, string> = { adopted: 'Adopted', step: 'Step', foster: 'Foster', guardian: 'Ward' };

function useCardState(personId: string | undefined) {
  const selected = useUi((state) => state.selectedId === personId);
  const dimmed = useUi((state) => state.focus !== null && !!personId && !state.focus.has(personId));
  const far = useStore((state) => state.transform[2] < 0.5);
  return { selected, dimmed, far };
}

function PersonCardView({ data }: NodeProps<TreeNode>) {
  useT();
  const { layout, person } = data;
  const { selected, dimmed, far } = useCardState(layout.personId);
  if (!person) return null;
  const late = isLate(person);
  const placeholder = isPlaceholder(person);
  const years = lifeSpan(person);
  const marriedIn = layout.role === 'spouse' && layout.kind !== 'ref' && !placeholder;
  const isRef = layout.kind === 'ref';
  const relation = layout.relation && layout.relation !== 'biological' ? t(RELATION_LABEL[layout.relation]) : null;
  const order = layout.birthRank && layout.siblingCount ? birthLabel({ rank: layout.birthRank, of: layout.siblingCount }) : null;
  const classes = ['card', `g-${person.gender}`, selected && 'is-selected', dimmed && 'is-dim', late && 'is-late', placeholder && 'is-placeholder', isRef && 'is-ref', far && 'is-far', fullName(person).split(' ').some((word) => word.length > 12) && 'is-long']
    .filter(Boolean).join(' ');
  const name = placeholder ? t('Unknown') : fullNameL(person);

  return (
    <div className={classes} style={{ '--branch': branchColor(layout.branch) } as CSSProperties} title={placeholder ? t('Unknown') : fullNameL(person)} aria-label={`${placeholder ? t('Unknown') : fullNameL(person)}${late ? `, ${t('late')}` : ''}`}>
      {far ? <span className="far-name">{placeholder ? t('Unknown') : givenL(person)}</span> : (
        <>
          <Avatar person={person} size="md">
            {marriedIn && <i className="badge-ring" title={t('Married into the family')}><Gem size={9} /></i>}
          </Avatar>
          <span className="who">
            <b>{isRef ? <><CornerUpRight size={11} /> {name}</> : name}</b>
            {(years || relation || order) && <small>{[order, relation, years].filter(Boolean).join(' · ')}</small>}
          </span>
          <span className="marks">
            {late && <Flower2 size={12} className="mark-late" />}
            <GenderMark gender={person.gender} className="mark-gender" />
          </span>
        </>
      )}
    </div>
  );
}

function GhostView({ data }: NodeProps<TreeNode>) {
  useT();
  const admin = useFamily((state) => state.admin);
  const selected = useUi((state) => state.ghostUnionId === data.layout.unionId);
  return (
    <div className={`card is-ghost ${selected ? 'is-selected' : ''}`} title={t('Unknown partner')}>
      <span className="pic md"><span className="initial">?</span></span>
      <span className="who"><b>{t('Unknown')}</b>{admin && <small>{t('Click to fill in')}</small>}</span>
    </div>
  );
}

function UnionView({ data }: NodeProps<TreeNode>) {
  useT();
  const status = data.layout.unionStatus ?? 'active';
  const label = t(status === 'active' ? 'Married' : status === 'widowed' ? 'Widowed' : status === 'divorced' ? 'Divorced' : status === 'separated' ? 'Separated' : 'Annulled');
  const Icon = status === 'divorced' || status === 'separated' || status === 'annulled' ? HeartCrack : Heart;
  return <div className={`union is-${status}`} title={label}><Icon size={12} fill={status === 'active' ? 'currentColor' : 'none'} /></div>;
}

function BandView({ data }: NodeProps<TreeNode>) {
  return <div className={`band ${data.even ? 'even' : 'odd'}`} />;
}

export const nodeTypes = {
  person: memo(PersonCardView),
  ref: memo(PersonCardView),
  ghost: memo(GhostView),
  union: memo(UnionView),
  band: memo(BandView),
};
